"""Provider-adaptive advisor capability."""

from __future__ import annotations

import inspect
import warnings
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from typing import Any, ClassVar, Literal, Self, TypeVar

from typing_extensions import TypeIs, deprecated

from pydantic_ai import Agent
from pydantic_ai._utils import replace_no_init
from pydantic_ai.capabilities import AbstractCapability, ModelSelection, NativeOrLocalTool, durable_operation
from pydantic_ai.exceptions import UnexpectedModelBehavior, UserError
from pydantic_ai.messages import ModelMessage, ModelResponse
from pydantic_ai.models import AbstractModel, KnownModelName, Model, ModelRequestContext, parse_model_id
from pydantic_ai.native_tools import AdvisorTool
from pydantic_ai.output import OutputSpec
from pydantic_ai.settings import ModelSettings
from pydantic_ai.tools import AgentDepsT, RunContext, Tool, ToolDefinition
from pydantic_ai.toolsets import AbstractToolset
from pydantic_ai_harness._durable import RetryRequest, raise_retry
from pydantic_ai_harness._usage import run_with_count_tokens_fallback
from pydantic_ai_harness._warn import HarnessDeprecationWarning

_LIMIT_REACHED = 'Advisor consultation limit reached for this model request. Continue without further advice.'


def _caller_stacklevel() -> int:
    """The `warnings.warn` stacklevel, from a function in this module, of the nearest frame in the user's code.

    Skips this module, Pydantic AI, Pydantic Graph, and the `asyncio`, `contextlib` and `typing`
    frames a call goes through, so the warning points at the caller whether they construct
    `Advisor[None](...)`, call `combine` directly, build an `Agent`, or pass capabilities to a run.
    """
    frame = inspect.currentframe()
    stacklevel = 0
    while frame is not None and (
        (module := frame.f_globals.get('__name__', '')) == __name__
        or module.partition('.')[0] in {'pydantic_ai', 'pydantic_graph', 'asyncio', 'contextlib', 'typing'}
    ):
        frame = frame.f_back
        stacklevel += 1
    return stacklevel


@dataclass
class _Advice:
    """A consultation's output, wrapped so a journaled output can't be read back as a `RetryRequest`."""

    output: object


def _is_request_response_model(model: AbstractModel) -> TypeIs[Model]:
    """Narrow a run's model without losing its provider client type."""
    return isinstance(model, Model)


def _executor_service(model: AbstractModel) -> str:
    """The service the executor reaches, which decides the native advisor's model-ID namespace.

    The provider's canonical system rather than its name, so a provider subclass that only renames
    itself, such as a `claude-code` `AnthropicProvider`, still gets the Anthropic advisor. Not the
    model's, which `BedrockConverseModel` reports as `'anthropic'` for Claude's thinking signatures.
    """
    provider = model.provider if _is_request_response_model(model) else None
    return provider.canonical_system if provider is not None else model.system


# TODO(harness 1.0, #12997): remove `_Mode` along with the deprecated `Advisor.mode`.
_Mode = Literal['auto', 'native', 'local']
"""The deprecated `Advisor.mode` values."""

_T = TypeVar('_T')


@dataclass(init=False)
class Advisor(NativeOrLocalTool[AgentDepsT]):
    """Let an agent consult another model through a provider-native tool or local fallback.

    By default, `Advisor` uses Pydantic AI's native `AdvisorTool` when an explicit
    provider-qualified model name matches a compatible Anthropic or OpenRouter
    executor. On every other model, it exposes an `advisor` function tool backed
    by a separate Pydantic AI agent. Pass `local=False` to require the native
    advisor, or `native=False` to always consult locally.

    ```python
    from pydantic_ai import Agent
    from pydantic_ai_harness.advisor import Advisor

    agent = Agent(
        'openai:gpt-5.4',
        capabilities=[Advisor('anthropic:claude-opus-4-8')],
    )
    ```
    """

    model: ModelSelection
    """The model to consult.

    Accepts the same model names and model instances as `Agent`. A model
    instance is consulted locally so its provider configuration is preserved;
    only an explicit `'anthropic:<model>'` or `'openrouter:<model>'` name can
    select the native advisor.
    """

    output_type: OutputSpec[object]
    """Output specification for local consultations, defaulting to text.

    Provider-native advisors return text, so a non-default specification
    consults locally and cannot be combined with `local=False`. Successful
    consultations return the validated output directly to the executor.
    """

    max_uses: int | Callable[[RunContext[AgentDepsT]], int] | None
    """Maximum consultations in one executor model request.

    The limit resets on the next executor request. A callable is called with the
    run context for each request and returns that request's limit, for example
    what is left of a budget shared by several runs. Below 1, the native advisor
    is omitted and the local tool returns its limit message. OpenRouter's native
    advisor does not honor this option, so setting it consults locally there.
    """

    max_tokens: int | None
    """Maximum output tokens for each advisor consultation.

    Values below 1024 are rejected so the setting remains valid on every native
    and local execution path.
    """

    caching: Literal['5m', '1h'] | None
    """Prompt-cache TTL for the advisor's transcript. Native-only; ignored by local tools.

    Supported by: Anthropic.
    """

    forward_history: bool
    """Whether local consultations receive the executor's completed message history.

    Local-only: native execution keeps the provider's transcript behavior unchanged.
    """

    id: str | None = 'advisor'
    """The capability id, `'advisor'` by default.

    Two `Advisor` capabilities with the same id resolve to one via
    [`combine`][pydantic_ai.capabilities.AbstractCapability.combine]. With different ids, their
    built tools conflict, since both are named `advisor`.
    """

    _local_uses: int = field(init=False, repr=False, compare=False, default=0)
    _local_max_uses: int | None = field(init=False, repr=False, compare=False, default=None)

    # TODO(harness 1.0, #12997): remove `_MODE_DECLARATIONS` and `_MODE_REPLACEMENTS` along with `mode`.
    _MODE_DECLARATIONS: ClassVar[dict[_Mode, tuple[bool, bool]]] = {
        'auto': (True, True),
        'native': (True, False),
        'local': (False, True),
    }
    """The `(native, local)` pair each deprecated `mode` stands for."""

    _MODE_REPLACEMENTS: ClassVar[dict[_Mode, str]] = {
        'auto': 'omit `mode`; the defaults use the native advisor where it applies and the local tool otherwise',
        'native': 'pass `local=False`',
        'local': 'pass `native=False`',
    }

    def __init__(
        self,
        model: ModelSelection,
        *,
        native: AdvisorTool
        | Callable[[RunContext[AgentDepsT]], Awaitable[AdvisorTool | None] | AdvisorTool | None]
        | bool = True,
        local: Tool[AgentDepsT] | Callable[..., Any] | bool | None = True,
        output_type: OutputSpec[object] = str,
        max_uses: int | Callable[[RunContext[AgentDepsT]], int] | None = None,
        max_tokens: int | None = None,
        caching: Literal['5m', '1h'] | None = None,
        forward_history: bool = False,
        id: str | None = None,
        defer_loading: bool = False,
        description: str | None = None,
        # TODO(harness 1.0, #12997): remove the deprecated `mode` parameter, its docstring entry and the block
        # that maps it below, and drop the `mode='auto'` comparison from the `local` docstring.
        mode: _Mode | None = None,
    ) -> None:
        """Create an advisor capability.

        Args:
            model: The model to consult.
            native: The provider-native advisor: `True` builds it from the fields, `False` disables
                it, and an `AdvisorTool` or a function returning one replaces it. A replacement
                carries its own configuration, so `max_uses`, `max_tokens` and `caching` don't
                apply to it, and a later default `Advisor` in a merge restores the built one.
            local: The local fallback: `True` (the default) or `None` builds the `advisor` tool from
                the fields, `False` disables it, and a `Tool` or function replaces it. Like the built
                tool, a replacement is left out of requests where the native advisor applies, and it
                keeps its own tool name. `output_type` and `forward_history` apply only to the
                built tool, so they are rejected with a replacement, as is `max_uses` on OpenRouter,
                where it would leave only the unlimited replacement. Otherwise `max_uses`,
                `max_tokens` and `caching` still shape the native advisor. `None` is stored as
                `True`, so that, as with the earlier `mode='auto'`, a later default `Advisor` in a
                merge restores the built local fallback, replacing an earlier `False` or replacement
                tool.
            output_type: Output specification for local consultations.
            max_uses: Maximum consultations in one executor model request.
            max_tokens: Maximum output tokens for each consultation.
            caching: Prompt-cache TTL for the native advisor's transcript.
            forward_history: Whether local consultations receive the executor's message history.
            id: The capability id. Defaults to the class-level `id`: `'advisor'`, or a subclass's own.
            defer_loading: Whether to make this an on-demand capability, whose tools the model loads by `id`.
            description: The capability description.
            mode: Deprecated: use `native` and `local`. Combined with a non-default `native` or
                `local`, it raises `UserError`; a default value is overridden by `mode`.
        """
        if local is None:
            # `None` and `True` build the same tool; stating `True` makes them merge the same way too.
            local = True
        if id is None:
            # A subclass that sets its own class-level `id` kept it before `id` was a parameter.
            id = type(self).id
        # TODO(harness 1.0, #12997): remove this deprecated `mode` mapping.
        if mode is not None:
            self._check_mode(mode)
            if native is not True or local is not True:
                raise UserError('`Advisor`: pass either the deprecated `mode` or `native`/`local`, not both')
            warnings.warn(
                f'`Advisor(mode={mode!r})` is deprecated: {self._MODE_REPLACEMENTS[mode]}. '
                '`mode` will be removed in pydantic-ai-harness 1.0.',
                HarnessDeprecationWarning,
                stacklevel=_caller_stacklevel(),
            )
            native, local = self._MODE_DECLARATIONS[mode]
        self.model = model
        self.output_type = output_type
        self.max_uses = max_uses
        self.max_tokens = max_tokens
        self.caching = caching
        self.forward_history = forward_history
        self._local_uses = 0
        super().__init__(native=native, local=local, id=id, defer_loading=defer_loading, description=description)

    # TODO(harness 1.0, #12997): remove the deprecated `mode` property, its setter and `_check_mode`.
    # `category=None` only marks it for type checkers; the body warns at runtime, naming the exact replacement.
    @property
    @deprecated('`Advisor.mode` is deprecated; use `native` and `local` instead.', category=None)
    def mode(self) -> _Mode:
        """Deprecated: read the `native` and `local` declarations instead.

        `'native'` when the local fallback is disabled, `'local'` when the native advisor is, and
        `'auto'` otherwise.
        """
        warnings.warn(
            '`Advisor.mode` is deprecated: `native=False` means local only, and `local=False` means native only. '
            '`mode` will be removed in pydantic-ai-harness 1.0.',
            HarnessDeprecationWarning,
            stacklevel=2,
        )
        if self._declared_native is False:
            return 'local'
        return 'native' if self._declared_local is False else 'auto'

    @mode.setter
    @deprecated('`Advisor.mode` is deprecated; use `native` and `local` instead.', category=None)
    def mode(self, mode: _Mode) -> None:
        self._check_mode(mode)
        warnings.warn(
            f'`Advisor.mode` is deprecated: {self._MODE_REPLACEMENTS[mode]}. '
            '`mode` will be removed in pydantic-ai-harness 1.0.',
            HarnessDeprecationWarning,
            stacklevel=2,
        )
        previous = self.native, self.local
        self.native, self.local = self._MODE_DECLARATIONS[mode]
        try:
            self.__post_init__()
        except Exception:
            self.native, self.local = previous
            raise

    @classmethod
    def _check_mode(cls, mode: str) -> None:
        if mode not in cls._MODE_DECLARATIONS:
            raise ValueError("Advisor.mode must be 'auto', 'native', or 'local'")

    @classmethod
    def from_spec(
        cls,
        model: KnownModelName | str,
        *,
        native: bool = True,
        local: bool = True,
        max_uses: int | None = None,
        max_tokens: int | None = None,
        caching: Literal['5m', '1h'] | None = None,
        forward_history: bool = False,
        id: str | None = None,
        defer_loading: bool = False,
        description: str | None = None,
        # TODO(harness 1.0, #12997): remove the deprecated `mode` spec field, its docstring mention
        # and `mode=mode` below.
        mode: _Mode | None = None,
        **kwargs: Any,
    ) -> Advisor[Any]:
        """Build from an agent spec, covering the fields a spec can express.

        Every JSON-expressible parameter is named because that signature is what core reads to
        generate the spec's JSON schema. A spec names the model by string and can only switch the
        native and local halves on or off. `output_type` has no JSON form, so it is passed through
        `**kwargs`, which the schema omits. `mode` is deprecated, as on the constructor.
        """
        return cls(
            model,
            native=native,
            local=local,
            max_uses=max_uses,
            max_tokens=max_tokens,
            caching=caching,
            forward_history=forward_history,
            id=id,
            defer_loading=defer_loading,
            description=description,
            mode=mode,
            **kwargs,
        )

    def __post_init__(self) -> None:
        """Validate the declared configuration, then resolve `native` and `local`.

        Runs on construction and again on every merged or per-run copy, so a merge can't reach a
        combination no constructor accepts.
        """
        if isinstance(self.max_uses, int) and self.max_uses < 1:
            raise ValueError('Advisor.max_uses must be at least 1')
        if self.max_tokens is not None and self.max_tokens < 1024:
            raise ValueError('Advisor.max_tokens must be at least 1024')
        if self.output_type is not str:
            self._check_typed_output()
        if self.native is True and self.local is False:
            self._check_built_native_only()
        elif self.local is not True and self.local is not False:
            self._check_local_replacement()
        super().__post_init__()
        if self.output_type is not str and self._declared_native is True:
            # The native advisor returns text, so a typed advisor consults locally. Resolving it off
            # rather than declaring it off keeps merges and `mode` reading the stated default.
            self.native = False

    def _check_typed_output(self) -> None:
        """Reject a typed advisor that could only consult the native advisor, which returns text."""
        if self.local is False and self.native is not False:
            raise ValueError('`Advisor.output_type` is not supported with `local=False`')
        if self.native is not True and self.native is not False:
            raise UserError(
                '`Advisor.output_type` is not supported by a native advisor tool, which returns text: '
                'pass `native=False`, or drop `output_type`'
            )

    def _check_local_replacement(self) -> None:
        """Reject options that only the built `advisor` tool applies, which a `local=` replacement would drop."""
        if self.output_type is not str or self.forward_history:
            raise UserError(
                '`Advisor.output_type` and `Advisor.forward_history` apply only to the built `advisor` tool, '
                'not to a `local=` replacement'
            )
        if self.max_uses is not None and self._parse_native_model(self.model)[0] == 'openrouter':
            raise UserError(
                '`Advisor.max_uses` with a `local=` replacement is not supported on OpenRouter, whose native '
                'advisor `max_uses` turns off, leaving only the replacement, which it does not limit'
            )

    def _check_built_native_only(self) -> None:
        """Reject a `local=False` advisor whose built native advisor could never apply."""
        native_provider, _ = self._parse_native_model(self.model)
        if native_provider is None:
            raise ValueError(
                "`Advisor(local=False)` requires an 'anthropic:<model>' or 'openrouter:<model>' model name"
            )
        if native_provider == 'openrouter' and self.max_uses is not None:
            raise ValueError('`Advisor.max_uses` is not supported by OpenRouter with `local=False`')

    def _default_native(self) -> Callable[[RunContext[AgentDepsT]], AdvisorTool | None]:
        """Build the native advisor per run, since whether it applies depends on the executor."""
        return self._required_native_advisor if self.local is False else self._native_advisor

    def _default_local(self) -> Tool[AgentDepsT]:
        """Build the `advisor` tool, which consults `model` through a separate agent."""
        output_type, forward_history = self.output_type, self.forward_history

        async def advisor(ctx: RunContext[AgentDepsT], prompt: str) -> object:
            if self._local_max_uses is not None:
                if self._local_uses >= self._local_max_uses:
                    return _LIMIT_REACHED
                self._local_uses += 1

            history = ctx.messages[:-1] if forward_history else None
            return raise_retry(await self._consult(ctx, prompt, history)).output

        return Tool(
            advisor,
            prepare=self._prepare_local,
            description=(
                'Consult a stronger model about a difficult or high-impact decision. '
                + ('' if output_type is str else 'Returns a validated answer in the configured output format. ')
                + 'Include the complete question and all relevant context in `prompt` '
                'because conversation history may not be available to the advisor.'
            ),
        )

    def _resolve_local_strategy(self, name: str | bool) -> Tool[AgentDepsT] | AbstractToolset[AgentDepsT]:
        if name is True:
            return self._default_local()
        return super()._resolve_local_strategy(name)

    @durable_operation('consult')
    async def _consult(
        self, ctx: RunContext[AgentDepsT], prompt: str, message_history: list[ModelMessage] | None
    ) -> _Advice | RetryRequest:
        output_type = self.output_type
        advisor_agent = Agent(
            self.model,
            name='advisor',
            output_type=output_type,
            instructions=(
                'You are an expert advisor. '
                + (
                    'Give concise, actionable advice to the executor model about the question it sends you. '
                    if output_type is str
                    else "Answer the executor model's question using the configured output format. "
                )
                + 'Do not address the end user.'
            ),
            model_settings=ModelSettings(max_tokens=self.max_tokens) if self.max_tokens is not None else None,
        )
        try:
            result = await run_with_count_tokens_fallback(
                lambda limits: advisor_agent.run(
                    prompt,
                    message_history=message_history,
                    conversation_id=ctx.conversation_id,
                    usage=ctx.usage,
                    usage_limits=limits,
                ),
                ctx.usage_limits,
                ctx.usage,
            )
        except UnexpectedModelBehavior as exc:
            return RetryRequest(str(exc))
        return _Advice(result.output)

    @classmethod
    def combine(cls, capabilities: Sequence[AbstractCapability[AgentDepsT]]) -> AbstractCapability[AgentDepsT]:
        """Merge like any native-or-local capability, keeping one combination that used to merge.

        No single `Advisor` accepts the built native advisor with `local=False` and `max_uses` on
        OpenRouter, but merging used to send the native tool without `max_uses`. That merge keeps
        working, with a warning, so an agent composed from two packaged advisors keeps building.
        """
        advisors = [capability for capability in capabilities if isinstance(capability, Advisor)]
        assert len(advisors) == len(capabilities)
        max_uses = cls._last_stated([advisor.max_uses for advisor in advisors])
        if (
            max_uses is not None
            and cls._last_stated([advisor._declared_local for advisor in advisors]) is False
            and cls._last_stated([advisor._declared_native for advisor in advisors]) is True
            and cls._parse_native_model(advisors[-1].model)[0] == 'openrouter'
        ):
            warnings.warn(
                f'Merged `Advisor` capabilities combine `local=False` on OpenRouter with `max_uses={max_uses}`, '
                "which OpenRouter's native advisor does not support, so `max_uses` is ignored. "
                'Remove `max_uses` or `local=False` to silence this warning.',
                UserWarning,
                stacklevel=_caller_stacklevel(),
            )
            capabilities = [replace_no_init(advisor, max_uses=None) for advisor in advisors]
        return super().combine(capabilities)

    @staticmethod
    def _last_stated(values: Sequence[_T | None]) -> _T | None:
        """The value a merge keeps: the last one stated, where `None` means not stated."""
        stated = [value for value in values if value is not None]
        return stated[-1] if stated else None

    async def for_run(self, ctx: RunContext[AgentDepsT]) -> Self:
        """Return a fresh capability with local usage isolated to this run.

        The `advisor` tool counts consultations on the capability it was built from, so the copy
        builds its own.
        """
        if self.max_uses is None or self._declared_local is not True:
            return self
        fresh = replace_no_init(self, native=self._declared_native, local=self._declared_local)
        fresh._local_uses = 0
        fresh.__post_init__()
        return fresh

    async def after_model_request(
        self,
        ctx: RunContext[AgentDepsT],
        *,
        request_context: ModelRequestContext,
        response: ModelResponse,
    ) -> ModelResponse:
        """Reset the local consultation allowance for each executor response."""
        self._local_uses = 0
        return response

    def _native_unique_id(self) -> str:
        """Identify the native tool paired with the local fallback."""
        return AdvisorTool.kind

    def _max_uses_for(self, ctx: RunContext[AgentDepsT]) -> int | None:
        """The consultation limit for the executor request `ctx` belongs to."""
        return self.max_uses(ctx) if callable(self.max_uses) else self.max_uses

    async def _prepare_local(self, ctx: RunContext[AgentDepsT], tool_def: ToolDefinition) -> ToolDefinition:
        """Fix the local limit once per request, so parallel calls share it."""
        self._local_max_uses = self._max_uses_for(ctx)
        return tool_def

    def _native_advisor(self, ctx: RunContext[AgentDepsT]) -> AdvisorTool | None:
        """Build a native tool only when an explicit advisor model name is lossless."""
        native_provider, native_model_name = self._parse_native_model(self.model)
        provider = _executor_service(ctx.model)
        if provider != native_provider or native_model_name is None:
            return None
        # OpenRouter's native advisor ignores `max_uses`, so the local tool enforces it there. Core has
        # no `restricting_settings` for `AdvisorTool` yet, which is where this check belongs.
        if provider == 'openrouter' and self.max_uses is not None:
            return None
        return self._advisor_tool(ctx, native_model_name)

    def _required_native_advisor(self, ctx: RunContext[AgentDepsT]) -> AdvisorTool | None:
        """Build the native tool for `local=False`, rejecting a cross-provider executor.

        With no local fallback, a cross-provider executor would be left without an advisor.
        """
        native_provider, native_model_name = self._parse_native_model(self.model)
        if _executor_service(ctx.model) != native_provider:
            raise UserError(f'`Advisor(local=False)` requires a {native_provider} executor, not {ctx.model.system}')
        assert native_model_name is not None
        return self._advisor_tool(ctx, native_model_name)

    def _advisor_tool(self, ctx: RunContext[AgentDepsT], model_name: str) -> AdvisorTool | None:
        max_uses = self._max_uses_for(ctx)
        if max_uses is not None and max_uses < 1:
            return None
        return AdvisorTool(
            model=model_name,
            max_uses=max_uses,
            max_tokens=self.max_tokens,
            provider_settings={'anthropic': {'caching': self.caching}} if self.caching is not None else None,
        )

    @staticmethod
    def _parse_native_model(
        model: ModelSelection,
    ) -> tuple[Literal['anthropic', 'openrouter'] | None, str | None]:
        """Extract a native model ID only from an explicit provider-qualified name."""
        if not isinstance(model, str):
            return None, None
        provider, model_name = parse_model_id(model)
        if model_name and (provider == 'anthropic' or provider == 'openrouter'):
            return provider, model_name
        return None, None
