# Step Persistence

`StepPersistence` saves a snapshot of an agent run at every settled step and
when the run fails, so you can resume the run, or fork it from an earlier step,
in the same process or another one, from memory, files, SQLite, MongoDB, or your
own store. Alongside the snapshots it keeps an append-only trail of step events
and a ledger of tool side effects, so after a crash you can tell which tool
calls completed and which may or may not have run. It is also the persistence
layer for orchestrators that delegate to sub-agents, for example continuing a
delegate's investigation with a follow-up question.

A snapshot holds the run's message history, not everything around it:
capability state outside the messages, workspace files, and resuming from the
middle of a step are tracked separately (see `pydantic-ai-harness` issues #149
and #196). For recovery inside a step, run the agent on
[durable execution](https://pydantic.dev/docs/ai/capabilities/durable_execution/overview/),
which `StepPersistence` works alongside.

> [!NOTE]
> **Storing sessions.** To store a chat session or any other conversation you
> pick up later, use core's
> [`ConversationStore`](https://pydantic.dev/docs/ai/core-concepts/persistence/#using-a-conversation-store):
> it keeps the conversation's usage and deferred tool requests along with its
> messages, stores each message once, and catches conflicting saves.
> `StepPersistence` remains supported for recovering runs: the step-event trail,
> the tool-effect ledger, and continuing or forking a run from a settled step. To
> move sessions you already stored with it, see
> [Moving sessions to a `ConversationStore`](#moving-sessions-to-a-conversationstore).

[Source](https://github.com/pydantic/pydantic-ai/tree/main/src/pydantic_ai_harness/pydantic_ai_harness/step_persistence/)

> While Pydantic AI Harness is on 0.x releases, the API may change between minor releases; when it does, deprecation warnings and release-note migration guidance tell you (or your agent) exactly how to upgrade. See the [version policy](https://pydantic.dev/docs/ai/harness/#version-policy).

```mermaid
sequenceDiagram
    accTitle: Step Persistence: save a run so you can continue or fork it later
    accDescr: StepPersistence hooks write an agent run to the step store: before_run a RunRecord, after_model_request an event, after_tool_execute a completed tool effect, after_node_run a complete snapshot, and before_tool_execute the next tool effect as started. The worker then crashes. Later, your code calls list_runs and continue_run, gets the latest complete snapshot and starts a new Agent.run from it.
    participant agent as Agent run
    participant store as Step store
    participant code as Your code, later
    Note over agent,store: StepPersistence() hooks
    agent->>store: before_run<br/>RunRecord
    agent->>store: after_model_request<br/>event appended
    agent->>store: after_tool_execute<br/>tool effect completed
    agent->>store: after_node_run<br/>complete snapshot
    agent->>store: before_tool_execute<br/>next tool effect started
    agent->>agent: worker crashes
    code->>store: list_runs
    code->>store: continue_run
    store-->>code: latest complete<br/>snapshot
    code->>agent: new Agent.run, message_history=history
```

## What it gives you

1. **Append-only step events** -- every interesting boundary (run start/end,
   model request, tool call, failure) appends a `StepEvent`. A run killed
   mid-tool-call still leaves a usable event trail.
2. **Continuable snapshots** -- a `ContinuableSnapshot` is saved at settled
   node boundaries, and a failing run saves its live at-failure history.
   Each snapshot carries a `state`: `complete` when every `ToolCallPart`
   has a matching result, `interrupted` when the capture holds unsettled
   tool work (e.g. a crash mid-tool-cycle). `latest_snapshot` and
   `continue_run` return only `complete` snapshots unless the caller passes
   `include_interrupted=True`. Pass the snapshot's `messages` back to
   `Agent.run(message_history=...)` to continue or fork.
3. **Tool-effect ledger** -- every tool call's lifecycle (`started`,
   `completed`, `failed`) is recorded against `(run_id, tool_call_id)`.
   A tool that fails, including with `ModelRetry` or `ToolFailed`, is
   recorded `failed`.
   After a crash, a tool with a `started` record and no terminal update
   should be treated as `unknown_after_crash`: the side effect may or may
   not have happened.
4. **Lineage metadata** -- `conversation_id` (sequence) and `parent_run_id`
   (hierarchy) are independent axes. See [Three-level identity](#three-level-identity).

## Quick start

```python
from pydantic_ai import Agent
from pydantic_ai_harness import StepPersistence
from pydantic_ai_harness.step_persistence import InMemoryStepStore

store = InMemoryStepStore()
librarian = Agent(
    'openai:gpt-5',
    capabilities=[StepPersistence(store=store, agent_name='code_librarian')],
)

await librarian.run('Find ThinkingPartDelta and confirm the callable allowance')
```

`run_id` is per-`Agent.run` call, matching pydantic_ai's
`RunContext.run_id`. For multi-turn grouping use `conversation_id=` (see
[Three-level identity](#three-level-identity)).

`run_id` resolution per call:

- **Explicit `run_id='libr-1'`** becomes the id for this one call.
  Single-shot use cases (deterministic id for testing, replay, debugging,
  a one-off scripted run). Reusing one capability instance with the same
  explicit `run_id` across multiple `.run()` calls raises `ValueError`
  in `before_run` -- the tool-effect ledger is keyed by
  `(run_id, tool_call_id)` and providers reuse deterministic tool-call
  ids, so a silent collision would erase the `unknown_after_crash`
  signal. Use `conversation_id=` for multi-turn grouping instead.
- **`agent_name` set, `run_id` unset** derives
  a path-safe base64url encoding of the complete `(agent_name, ctx.run_id)`
  pair. The encoding is injective within `FileStepStore`'s 200-character
  limit, so replay addresses the same stored run without collisions between
  distinct accepted context ids. A longer derived id raises `ValueError`
  before backend selection, including with the memory, SQLite, Mongo, and
  Postgres stores.
- **Neither set** uses `ctx.run_id` unchanged. A missing context run id raises
  `RuntimeError` because inventing one would disconnect replayed writes.

The run record, events, and snapshots carry `agent_name`. When it is unset, they
record the running agent's `name` instead (which Pydantic AI infers from the
variable name when `Agent(name=...)` is not passed). That fallback does not feed
the `run_id` derivation above, so the store key stays `ctx.run_id` and runs can
still be looked up by the id passed to or returned from `Agent.run`.

## Durable execution

`StepPersistence` and a durable execution engine recover from different
failures:

- **`StepPersistence`** saves message-history snapshots, a step-event trail,
  and a tool-effect ledger to a store you choose, with no engine to run. After
  a crash, your code decides what happens next: load the latest complete
  snapshot's messages with `continue_run` or `fork_run` and pass them to a new
  `Agent.run(message_history=...)`, in the same process or another one. A step
  that was in flight is not retried: its tool calls show up as `started`
  effects in the ledger, and you decide whether redoing them is safe.
- **A durable engine** replays the run itself after a restart and retries the
  call that was in flight, as
  [Durable Execution](https://pydantic.dev/docs/ai/capabilities/durable_execution/overview/)
  describes.

Use `StepPersistence` alone when a run can be resumed or forked from its last
settled step, for example by an orchestrator that continues a delegate's
investigation. Use a durable engine when a run must finish without your code
restarting it, including a step interrupted partway through. Use both to have
the engine keep the run alive while the store keeps a history you can inspect,
continue, or fork after the run ends.

`StepPersistence` has the stable capability id `step_persistence`, so it can
be attached alongside a Pydantic AI durability capability without passing
`id=`. Pass an explicit id only when the same agent has more than one
`StepPersistence` instance.

Six store boundaries are durable operations: registration identity, run
registration, event append, snapshot save, tool-effect start, and tool-effect
completion or failure. Every persisted timestamp is read inside one of those
operations, so replay uses the journaled value instead of reading the workflow
wall clock again. The journaled registration identity makes a retried
registration idempotent while a distinct reuse of the same run id still fails.

Events and snapshots written by the capability carry deterministic per-run
idempotency keys. Every built-in store suppresses a key it already applied,
while records created directly with `idempotency_key=None` retain append
behavior. Snapshot keys use a per-run save sequence together with
`step_index` and `state`. Replay produces the same sequence, while distinct
snapshots at the same step and state retain their write order and newer history.

> [!WARNING]
> **Compatibility impact: recorded tool-failure operations.** Recording a tool
> call that raises `ModelRetry` or `ToolFailed` as `failed` adds a tool-effect
> failure and an event append to the recorded operation sequence. Before
> upgrading, let in-flight DBOS or Temporal runs that already made such a call
> finish, or deploy the upgrade as a new DBOS application version or with
> [Temporal worker versioning](https://docs.temporal.io/production-deployment/worker-deployments/worker-versioning).
> Set the DBOS `application_version` explicitly: the computed one does not
> change with a library upgrade. Replaying an older run with the new code
> raises `DBOSUnexpectedStepError` on DBOS and a nondeterminism error on
> Temporal.

The orchestrator pattern -- one logical agent serving many turns -- uses
`conversation_id`, not a shared `run_id`:

```python
orchestrator = Agent(
    'openai:gpt-5',
    capabilities=[StepPersistence(store=store, agent_name='orchestrator')],
)

for turn in turns:
    await orchestrator.run(turn, conversation_id='orch-conv')

# All turns of this orchestrator, chronological:
records = await store.list_runs(conversation_id='orch-conv')
```

## Three-level identity

The capability mirrors pydantic_ai's identity stack:

| Concept | Definition | Granularity |
| --- | --- | --- |
| `conversation_id` | The dialogue. Resolved by pydantic_ai from the `conversation_id=` argument to `Agent.run`, or the most recent `conversation_id` on `message_history`, or a fresh UUID7. | sequence of runs |
| `run_id` | One `Agent.run` invocation. | one step in the sequence |
| `step_index` | Graph-node count *within* a run (`ctx.run_step`). | one node within one run |

`StepEvent.conversation_id` and `RunRecord.conversation_id` are populated
from `ctx.conversation_id`. So three `.run()` calls sharing one
`conversation_id` produce three distinct `run_id`s, all queryable as a
group:

```python
runs = await store.list_runs(conversation_id='conv-abc')  # 3 records, chronological
```

## Continuing a delegate's investigation

pydantic_ai already has `message_history=` for "carry on with this prior
context". `StepPersistence` does not introduce a parallel mechanism -- it
exposes one helper that loads the most recent settled snapshot:

```python
from pydantic_ai_harness.step_persistence import continue_run

# Earlier: tag the first turn with a conversation id so the follow-up can find it.
await librarian.run(
    'Find ThinkingPartDelta and confirm the callable allowance',
    conversation_id='libr-conv',
)

# Later (possibly a different process):
prior_run = (await store.list_runs(conversation_id='libr-conv'))[-1].run_id
history = await continue_run(store, run_id=prior_run)
await librarian.run(
    'Read _apply_provider_details_delta and check the path',
    message_history=history,
    conversation_id='libr-conv',   # keep the conversation grouping
)
```

`fork_run(store, run_id=...)` returns the same shape but is intended when
the caller wants a branched logical run from that snapshot point (the new
run gets a fresh `run_id` and probably a fresh `conversation_id`).

### What "safe to continue from" means

By default `continue_run` returns the messages of the latest `complete`
snapshot for that `run_id` -- a point whose tool work was fully settled
when captured. Snapshots are written at these boundaries:

- after every `CallToolsNode` whose tool calls all returned -- the pending
  tool-return request is folded in, so the point is durable the moment the
  tool completes, before the next model request is even sent,
- at `after_run`, when the run ended past that boundary (a run that reached
  no boundary at all, or an `Agent.run_stream` whose closing response lands
  after the last one), and
- when a run *fails*: the live history at failure time is saved, whatever
  its shape -- a model request that raises after a clean tool cycle
  produces a `complete` snapshot; a crash mid-tool-cycle produces an
  `interrupted` one carrying every completed cycle.

An `interrupted` snapshot is sendable, but not necessarily *safe*: a
pending tool call may be re-executed or closed out with a synthesized
`interrupted` return, and neither says whether the original side effect
happened. That is the tool-effect ledger's job. Which one happens depends on
how you continue. Resuming without a new prompt executes the pending calls.
With a new prompt, calls are closed out if some of their batch already
returned; if none did, the run raises `UserError` rather than abandon calls
that could still be answered, so call `pydantic_ai.messages.repair_messages`
on the history first to close them out yourself. So the default read path skips
`interrupted` snapshots; pass `include_interrupted=True` to
`continue_run` / `fork_run` / `latest_snapshot` after checking
`list_unresolved_tool_effects`. If no matching snapshot exists,
`continue_run` raises `LookupError`.

## Run lineage -- `parent_run_id`

`parent_run_id` is a lineage label, not a functional dependency. It does
two things:

- Every `StepEvent` and `RunRecord` carries it, so you can filter / group.
- `store.list_runs(parent_run_id='orch-1')` returns every delegate run
  pointing at that orchestrator.

It is auto-inferred for in-process delegation: when an orchestrator's
tool synchronously calls a delegate's `Agent.run(...)`, the delegate's
`StepPersistence` picks up the orchestrator's `run_id` via a `ContextVar`
that the orchestrator's `wrap_run` set. No threading required:

```python
orchestrator = Agent(
    'openai:gpt-5',
    capabilities=[StepPersistence(store=store, agent_name='orchestrator')],
)
librarian = Agent(
    'openai:gpt-5',
    capabilities=[StepPersistence(store=store, agent_name='code_librarian')],
)

@orchestrator.tool_plain
async def ask_librarian(question: str) -> str:
    result = await librarian.run(question)   # parent_run_id auto-filled
    return result.output

# Tag the orchestrator turn so the lookup below can find its run_id.
await orchestrator.run(
    'Where is ThinkingPartDelta defined?',
    conversation_id='orch-conv',
)

# All librarian runs now point at the orchestrator's run_id:
orch_run_id = (await store.list_runs(conversation_id='orch-conv'))[-1].run_id
delegates = await store.list_runs(parent_run_id=orch_run_id)
```

Set `parent_run_id=` explicitly to override (e.g. cross-process delegation
where `ContextVar`s do not propagate).

`parent_run_id` is distinct from `conversation_id`. The orchestrator
and delegate usually live in *different* conversations (the orchestrator
talks to a user; the delegate talks to itself). But they share a
parent-child link.

## Inspecting a run tree

`list_runs` returns matches sorted by `started_at` ascending across all
backends -- pick the most recent with `[-1]`.

```python
# Every delegate of one orchestrator run (chronological)
delegates = await store.list_runs(parent_run_id='orch-3f2a')

# Every run in one dialogue (multi-turn conversation across many .run() calls)
turns = await store.list_runs(conversation_id='conv-abc')
latest_turn = turns[-1]

# Filters combine (AND):
focused = await store.list_runs(
    parent_run_id='orch-3f2a',
    conversation_id='libr-conv',
)

# Detail per run:
events = await store.list_events(run_id=delegates[0].run_id)
snapshot = await store.latest_snapshot(run_id=delegates[0].run_id)
unresolved = await store.list_unresolved_tool_effects(run_id=delegates[0].run_id)
```

## Failure recovery

```python
# An earlier delegate run died mid-investigation.
events = await store.list_events(run_id='libr-3f2a')
unresolved = await store.list_unresolved_tool_effects(run_id='libr-3f2a')
for record in unresolved:
    # status == 'started' with no terminal update -- unknown_after_crash.
    print(f'tool {record.tool_name} ({record.tool_call_id}) may or may not have run')
    print(f'  idempotency_key={record.idempotency_key}  '
          f'effect_summary={record.effect_summary}')

# Decide whether to resume or branch:
history = await continue_run(store, run_id='libr-3f2a')
# If the unresolved tools were read-only and safe to redo:
await librarian.run('continue investigating', message_history=history,
                    conversation_id='libr-conv')
# If side effects might have happened and the orchestrator wants a fresh attempt:
history = await fork_run(store, run_id='libr-3f2a')
# ... pass to a new delegate run with a different agent_name / conversation_id.

# To resume from the interrupted frontier itself (the crashed cycle included),
# after checking the unresolved effects above:
history = await continue_run(store, run_id='libr-3f2a', include_interrupted=True)
```

Side-effect deduplication is the orchestrator's responsibility. Tools that
write external state should annotate their in-flight `ToolEffectRecord`
via `annotate_tool_effect`:

```python
from pydantic_ai import RunContext
from pydantic_ai_harness.step_persistence import annotate_tool_effect

@orchestrator.tool
async def set_label(ctx: RunContext[Deps], issue: int, label: str) -> str:
    await annotate_tool_effect(
        store,
        ctx,
        idempotency_key=f'issue-{issue}::label::{label}',
        effect_summary=f'set label {label!r} on issue #{issue}',
    )
    await github.set_label(issue, label)   # the actual side effect
    return 'ok'
```

The helper reads the active `run_id` from the `StepPersistence`
`ContextVar` and `tool_call_id` / `tool_name` from `ctx`, then merges the
metadata into the prior record. It is a no-op when called outside a
step-persistence-wrapped tool call. The terminal `completed` / `failed`
entry preserves both fields.

## Compaction receipt handles

`StepPersistence.compaction_transcript_handle()` exposes the current `run_id` to compaction
receipts. It is an identifier for this store's persisted run history, not a promise that the
pre-compaction transcript remains available: snapshots can already contain compacted history and
configured retention can delete older snapshots.

## Backends

- `InMemoryStepStore` -- process-local; great for tests.
- `FileStepStore(directory)` -- directory layout under `<directory>/<run_id>/`:
    - `run.json` -- `RunRecord` (lineage)
    - `events.jsonl` -- append-only `StepEvent`s
    - `tool_effects.jsonl` -- append-only `ToolEffectRecord`s, scoped to this run
    - `snapshot-keys.jsonl` -- replay-suppression keys retained independently
      of snapshot pruning
    - `snapshots/{seq}.json` -- `ContinuableSnapshot`s, named by a per-run
      monotonic counter (NOT `step_index`, which would collide when the
      same `run_id` is reused across `Agent.run` calls -- `ctx.run_step`
      resets to 0 each call).
- `SqliteStepStore(database='runs.db')` -- single SQLite file with tables
  `runs`, `events`, `snapshots`, `snapshot_idempotency_keys`, `tool_effects`, and a sibling `media`
  table for externalized blobs (see [Persisting media](#persisting-media)
  below), plus `snapshot_messages` and `snapshot_message_refs` (see
  [Storing each message once](#storing-each-message-once)). WAL mode is
  enabled, and a write waits up to 30 seconds for another writer, such as
  another process sharing the file, before raising `database is locked`;
  `tool_effects` upserts per
  `(run_id, tool_call_id)` so the latest state wins; snapshots use
  `AUTOINCREMENT seq` to mirror `FileStepStore._next_snapshot_seq`.
  Databases created before the snapshot `state` column existed gain it
  automatically on open (existing rows read as `complete`).
  Pass `connection=` instead of `database=` to share a `sqlite3.Connection`
  with the rest of your application; the connection must be opened with
  `check_same_thread=False` because hook calls are dispatched onto a
  worker thread; the store leaves its busy timeout and journal mode as the
  caller set them.
- `MongoStepStore(client= or db_url=, database=...)` -- MongoDB collections
  `runs`, `events`, `snapshots`, `snapshot_messages`, `snapshot_idempotency_keys`,
  `tool_effects`, and `counters` (atomic `$inc` for monotonic `seq`). Run registration uses an
  atomic insert by `runs._id = run_id`; duplicate ids raise `ValueError`.
  Needs the `mongodb` extra
  (which installs `pymongo>=4.17.0`); pass a shared `AsyncMongoClient` as `client=`, or a
  connection string as `db_url=` (the store then owns the client -- call
  `await store.aclose()` to release it). A store-owned client adds `pydantic-ai-harness`
  and its version to the driver metadata of the MongoDB connection handshake, which server
  logs show; a `client=` you pass is left as you configured it.
  Externalizes individual parts at or above `media_threshold_bytes` by
  default to a `MongoMediaStore` on the same client. That is a per-value
  offload, not an aggregate cap: a message of many below-threshold parts can
  still exceed MongoDB's 16 MiB document limit and fail on insert -- lower the
  threshold if that is a risk for your workload.
- `PostgresStepStore(pool, table='step_persistence')` -- PostgreSQL tables
  `{table}_runs`, `{table}_events`, `{table}_snapshots`,
  `{table}_snapshot_keys`, `{table}_messages`, and `{table}_tool_effects`, plus `{table}_media`
  for externalized blobs (see [Persisting media](#persisting-media) below).
  `table` is a prefix, not a table name. `pool` is a caller-owned
  asyncpg-compatible pool: the harness imports no driver and defines no extra
  for it, and the store does not close the pool. Run registration inserts by
  the `run_id` primary key of `{table}_runs`; duplicate ids raise
  `ValueError`. Events and snapshots are ordered by a
  `BIGINT GENERATED ALWAYS AS IDENTITY` `seq`, which keeps counting when
  `ctx.run_step` resets to 0; `{table}_snapshot_keys` holds the
  replay-suppression keys independently of snapshot pruning;
  `{table}_tool_effects` upserts per `(run_id, tool_call_id)` so the latest
  state wins. Timestamps and JSON are stored as `TEXT`.

All implement the same async `StepStore` protocol, so capability hooks never
block the event loop on the file/sqlite backends (I/O is dispatched via
`anyio.to_thread`); the Mongo and Postgres backends are natively async.

`FileStepStore` validates `run_id` against `[A-Za-z0-9_.-]{1,200}` (and
rejects `..`) to prevent path traversal -- callers passing user-controlled
IDs should still sanitise first.

### What `MongoStepStore` creates on first write

The store issues `createIndex` on its first write, for ten indexes:
`conversation_id` and `parent_run_id` (both sparse) plus `started_at` on
`runs`; `(run_id, seq)` and unique keyed `(run_id, idempotency_key)` on
`events`; `(run_id, seq)`, unique keyed `(run_id, idempotency_key)`, and
`(run_id, state, seq)` on `snapshots`; and a unique `(run_id, tool_call_id)`
plus `(run_id, status)` on `tool_effects`. The idempotency indexes include only
documents whose key is a string, so `None` retains append behavior. Its default
`MongoMediaStore` adds one more (see the [media docs](../media/)). Three
consequences worth knowing before pointing the store at an existing
deployment:

- The connecting user needs the privilege to create indexes. A restricted
  Atlas role without it fails on the first write, not at construction.
- The unique index build fails if an existing `tool_effects` collection
  already holds duplicate `(run_id, tool_call_id)` pairs.
- Index builds against already-populated collections cost time and I/O on
  that first call.

`RunRecord.metadata` and `StepEvent.metadata` are stored as nested documents,
so their keys become BSON field names: keys containing `.` or starting with
`$` need [MongoDB 5.0 or later](https://www.mongodb.com/docs/manual/core/dot-dollar-considerations/),
and a key containing a NULL byte is rejected by the BSON encoder before it
reaches the server. CI exercises both Mongo backends against MongoDB 9.0.

Install MongoDB support:

uv:

```bash
uv add "pydantic-ai-harness[mongodb]"
```

pip:

```bash
pip install "pydantic-ai-harness[mongodb]"
```

### What `PostgresStepStore` creates on first use

The store creates its schema on the first operation of each store instance,
reads included: the six tables listed under [Backends](#backends), indexes on
`conversation_id` and `parent_run_id` on `{table}_runs`, `(run_id, seq)`
indexes on `{table}_events` and `{table}_snapshots`, and a unique index on
`(run_id, idempotency_key)` on `{table}_events` that covers only rows whose
key is not `NULL`, so `None` retains append behavior. Every statement is
`CREATE ... IF NOT EXISTS`, and they run in one transaction that first takes
`pg_advisory_xact_lock` on a hash of `table`. Its default `PostgresMediaStore`
creates `{table}_media` the same way on its own first use (see the
[media docs](../media/)). Four consequences worth knowing before pointing the
store at an existing database:

- The statements are skipped when all of the store's tables already exist, so
  only the call that creates them needs `CREATE` on the schema. After that, a
  role granted `SELECT`, `INSERT`, `UPDATE` and `DELETE` on the tables is
  enough, plus `SELECT` and `INSERT` on `{table}_media` unless you pass
  `media_store=None`. A role without `CREATE` on a database missing a table fails on the
  first operation, not at construction.
- Processes that start together wait on the advisory lock instead of colliding
  in the catalog, which `CREATE TABLE IF NOT EXISTS` alone does not rule out.
  The lock is released when the transaction ends.
- `table` must match `[a-z_][a-z0-9_]*` and is limited to 40 characters, so
  that every derived table, index, and constraint name fits PostgreSQL's
  63-byte identifier limit. Lowercase only, because PostgreSQL folds unquoted
  identifiers and `'Orders'` would share tables with `'orders'`. Anything else
  raises `ValueError` at construction.
- There is no migration step. An existing table with one of these names and a
  different layout is left as it is, and the mismatch surfaces on the first
  statement that uses a missing column.

`PostgresStepStore` accepts the driver-neutral `PostgresPool` protocol
(exported from `pydantic_ai_harness.media`), so the harness does not require a
particular PostgreSQL driver. Install and manage the driver in your
application, for example:

uv:

```bash
uv add asyncpg
```

pip:

```bash
pip install asyncpg
```

```python
import asyncpg

from pydantic_ai_harness import StepPersistence
from pydantic_ai_harness.step_persistence import PostgresStepStore


async def build_persistence() -> tuple[StepPersistence, asyncpg.Pool]:
    pool = await asyncpg.create_pool('postgres://localhost/app')
    persistence = StepPersistence(store=PostgresStepStore(pool), agent_name='code_librarian')
    return persistence, pool
```

Call `build_persistence` during application startup and close the returned
pool during shutdown. The store does not manage it. CI exercises both Postgres
backends against `postgres:17`.

## Bounding snapshot growth

Each step writes a new full-history snapshot keyed by an incrementing `seq`,
and nothing is pruned by default. Within one long `Agent.run` the snapshot
count equals the number of settled tool-call steps, so a long single run pays a
growing storage cost.

All five stores -- `InMemoryStepStore`, `FileStepStore`, `SqliteStepStore`,
`MongoStepStore`, and `PostgresStepStore` -- accept an opt-in
`max_snapshots_per_run: int | None` (default `None`, unbounded). When set to `N >= 1`, each `save_snapshot` prunes the run
down to a retain set:

- the newest `N` snapshots by `seq`,
- the newest snapshot overall (serves `latest_snapshot(include_interrupted=True)`),
- the newest `complete` snapshot (serves the default read path).

The last two keep both read modes correct even when the newest `N` snapshots
are all `interrupted` and the newest resumable `complete` sits below that
window, so the retain set can exceed `N`. `from_spec(..., max_snapshots_per_run=N)`
forwards the bound to the store it constructs (`backend='memory'`, `'file'`, or
`'sqlite'`; a Mongo or Postgres store takes a live client or pool, so it is
built directly, not from a spec).

```python
from pydantic_ai_harness.step_persistence import FileStepStore

store = FileStepStore('runs', max_snapshots_per_run=8)
```

Pruning a snapshot never deletes its externalized media: blobs are
content-addressed and may be shared across snapshots and runs, so orphaned-blob
GC is out of scope (see the non-goals below). Age-based (TTL) expiry is out of
scope too -- it belongs at whole-run granularity, not per snapshot.

Bounded retention discards older per-step snapshots, including pre-compaction
ones. Any downstream that reconstructs history by unioning a run's retained
snapshots -- snapshot search or a compaction receipt keyed on `run_id` -- can
only see what is retained. With a tight bound (for example
`max_snapshots_per_run=1`) the older, pre-compaction states are gone, so treat
the bound as a hard limit on how far back such recovery can reach. Leave the
bound at `None`, or set it high enough to cover the history you need to recover,
when historical reconstruction matters.

### Storing each message once

`max_snapshots_per_run` bounds the snapshots within a run, but every snapshot
repeats the history before it, so storing each one in full grows with the number
of snapshots times the history length. `SqliteStepStore` stores each message's
content once instead: `snapshot_messages` holds each message's JSON keyed by its
SHA-256, and `snapshot_message_refs` lists each snapshot's messages in order, as
a short row per message. Reads rebuild the full history, so `latest_snapshot`
and `list_snapshots` return the same messages either way.

Deleting a snapshot, by pruning or by deleting its conversation with
`SqliteConversationStore.delete`, also deletes the messages no remaining
snapshot references.

A database written by an earlier release keeps working: its rows hold the
history inline and still read, and new snapshots in the same database store
their messages once. Earlier releases can't read snapshots written this way, so
don't downgrade a store that a newer release has written to. An existing
database doesn't shrink right away: its earlier rows keep their history until
pruning or deleting their conversation removes them, and SQLite keeps the freed
space in the file until you run `VACUUM`.

`PostgresStepStore` and `MongoStepStore` store each message once too, in a
`{table}_messages` table and a `snapshot_messages` collection, with each
snapshot holding the keys of its messages in order. Unlike `SqliteStepStore`,
they keep a stored message when the snapshots referencing it are pruned, as they
do externalized media: with several writers at once, deleting a message along
with its last snapshot could race with a save that is about to reference it. So
messages that only pruned snapshots referenced, such as those compaction
replaced, stay stored, and pruning doesn't bound these stores' size or remove
that content. `FileStepStore` keeps writing each snapshot as a complete JSON
file, so a run's directory stays readable and greppable on its own.

## Persisting media

`BinaryContent` payloads (images, audio, documents, video) inline as
base64 inside a snapshot would balloon every file/row containing the
message; a large text part (e.g. a big tool-return string) does the same and
can push a `MongoStepStore` message past MongoDB's 16 MiB document cap
([#440](https://github.com/pydantic/pydantic-ai-harness/issues/440)). The
file/sqlite/mongo/postgres backends externalize any `BinaryContent.data`, and any
part whose string `content` is at or above 64 KiB, through a configured
`MediaStore`, leaving a URI reference in the snapshot. The same
`media_threshold_bytes` governs both binary and text; there is no separate
text knob. Round-trip is transparent -- `latest_snapshot(...).messages[*]`
returns the original `BinaryContent` bytes and text.

Text externalization applies to every store with a media store, not only
Mongo; the only opt-out is `media_store=None`.

The marker format is versioned, and compatibility is upgrade-only. A current
reader restores snapshots written by earlier releases, but an earlier release
can misread or fail to validate markers a newer one wrote, so keep a current
reader for persisted snapshots. An escaped-keys marker or a literal wrapper
stamped with a format version this reader does not know is rejected:
`restore_media` raises `ValueError`, which `latest_snapshot` surfaces for the
file, sqlite, mongo, and postgres stores, while `list_snapshots` skips that
snapshot and logs the error.

| StepStore           | Default `media_store`                  | Where blobs live                      |
| ------------------- | --------------------------------------- | ------------------------------------- |
| `InMemoryStepStore` | _(not applicable)_                     | bytes stay in the in-memory snapshot  |
| `FileStepStore`     | `FileMediaStore(<root>/media/)`        | `<root>/media/<sha256>.bin`           |
| `SqliteStepStore`   | `SqliteMediaStore(database=<same db>)` | sibling `media` table in the same DB  |
| `MongoStepStore`    | `MongoMediaStore(client=<same client>)` | sibling `media` + `media_chunks` collections |
| `PostgresStepStore` | `PostgresMediaStore(<same pool>)`      | `{table}_media` table on the same pool |

Override the destination by passing your own `MediaStore`:

```python
from pydantic_ai_harness.media import S3MediaStore
from pydantic_ai_harness.step_persistence import FileStepStore

store = FileStepStore(
    'runs',
    media_store=S3MediaStore(
        bucket='my-bucket',
        endpoint='https://<account>.r2.cloudflarestorage.com',
        region='auto',
        access_key_id=...,
        secret_access_key=...,
    ),
    media_threshold_bytes=64 * 1024,  # raise/lower if you want
)
```

Opt out entirely (keep bytes inline in the snapshot JSON/row):

```python
FileStepStore('runs', media_store=None)
SqliteStepStore(database='runs.db', media_store=None)
```

URIs are `media+sha256://<hex>`, content-addressed. The same blob written
through any `MediaStore` resolves the same way -- dedup is automatic and
moving the underlying storage is a one-line swap. The shipped
implementations are:

- `FileMediaStore(directory)` -- one file per blob at
  `<directory>/<sha256>.bin`.
- `SqliteMediaStore(database=...)` or `SqliteMediaStore(connection=...)` --
  one row per blob (`INSERT OR IGNORE` for content-addressed dedup).
- `S3MediaStore(bucket=, endpoint=, region=, access_key_id=, secret_access_key=)`
  -- path-style URLs + handrolled SigV4. Compatible with AWS S3, Cloudflare
  R2 (`region='auto'`), MinIO, and other S3-compatible providers. PUT/GET/HEAD
  only -- no multipart, lifecycle, or listing.
- `MongoMediaStore(client= or db_url=, database=...)` -- MongoDB, needs the
  `mongodb` extra. Stores each blob as sha256-addressed chunks across a
  `media` manifest document and a sibling `media_chunks` collection (manual
  chunking, not GridFS -- see the [media docs](../media/) for why), so a blob
  larger than one BSON document still stores and reads back. Chunking bounds
  the document, not memory: there is no streaming API, so each blob is held
  whole in process memory on both `put` and `get`. The manifest holds
  `MediaContext.metadata` inline and is not chunked, so keep per-blob metadata
  small. `collection=` renames both collections and `chunk_size_bytes=`
  (default 8 MiB) sets the split size.
- `PostgresMediaStore(pool, table='media')` -- PostgreSQL over a
  caller-owned asyncpg-compatible pool; no extra is needed. One row per
  blob keyed by the sha256 digest (`ON CONFLICT (sha256) DO NOTHING` for
  content-addressed dedup). The bytes are one `BYTEA` value, which
  PostgreSQL caps at 1 GB. There is no streaming API, so each blob is held
  whole in process memory on both `put` and `get`.

### Exposing externalized bytes as URLs

Each store accepts a `public_url=` callable that turns the canonical
`media+sha256://<hex>` URI into a URL the model can fetch directly.

Static base URL (public R2 bucket, CDN):

```python
from pydantic_ai_harness.media import S3MediaStore, make_static_public_url

store = S3MediaStore(
    bucket='my-bucket',
    endpoint='https://<acc>.r2.cloudflarestorage.com',
    region='auto',
    access_key_id=..., secret_access_key=...,
    key_prefix='media/',
    public_url=make_static_public_url('https://pub-abc.r2.dev', key_prefix='media/'),
)
```

Presigned / rotating-signature URL -- pass any async callable that takes
`(uri, MediaContext)`:

```python
from pydantic_ai_harness.media import MediaContext, S3MediaStore

async def presign(uri: str, ctx: MediaContext) -> str:
    key = 'media/' + uri.removeprefix('media+sha256://') + '.bin'
    return await my_signer.generate(key, ttl=3600, content_type=ctx.media_type)

store = S3MediaStore(..., public_url=presign)
```

### `MediaContext`, extensible per-operation bag

Every `MediaStore` method (`put`, `get`, `exists`, `public_url`,
`get_metadata`) and both user-supplied callables (`PublicUrlResolver`,
`KeyStrategy`) accept a `MediaContext`:

```python
@dataclass(frozen=True, kw_only=True)
class MediaContext:
    media_type: str | None = None      # e.g. 'image/png'
    filename: str | None = None        # original filename, when known
    metadata: Mapping[str, str] = {}   # user-supplied tags
```

All fields have defaults; pass what you have.

**Persistence by store.** `get_metadata(uri)` returns the stored
`metadata` mapping and raises `FileNotFoundError` for a blob that was
never stored. A repeated `put` keeps the first metadata on the SQLite,
MongoDB, and PostgreSQL stores. On `FileMediaStore` a later `put` with
metadata replaces it; on `S3MediaStore` every `put` replaces it, and one
without metadata clears it. On Disk and S3 this holds for puts that
resolve to the same key, which a custom `key_strategy` may not.
`get_metadata` does not return `media_type`: S3 sends it as
`Content-Type`, the database stores keep it in a column, and
`FileMediaStore` does not persist it.

- `SqliteMediaStore` writes `metadata` to a JSON column and `media_type`
  to a dedicated column
- `S3MediaStore` sends `metadata` as signed `x-amz-meta-*` headers and
  `media_type` as `Content-Type`; `get_metadata` reads the `x-amz-meta-*`
  values back from the HEAD response. Keys must match `[A-Za-z0-9-]+` and
  come back lowercased
- `FileMediaStore` writes a sidecar JSON file (`<resolved>.meta.json`)
  alongside each blob, atomically through a uniquely named temporary file
- `MongoMediaStore` writes `metadata` as a JSON string and `media_type`
  as a dedicated field on the blob's manifest document (the `media`
  collection by default); `get_metadata` decodes the JSON string back.
  Because the mapping is one JSON string rather than nested fields,
  metadata keys are not subject to BSON field-name rules here
- `PostgresMediaStore` writes `metadata` as a JSON string to a `TEXT`
  column and `media_type` to a dedicated column

### `key_strategy` -- controlling the backend storage path

Default is `<sha256>.bin`. `FileMediaStore` and `S3MediaStore` accept
overrides to fit existing layouts; `SqliteMediaStore`, `MongoMediaStore`, and
`PostgresMediaStore` do not (the digest is their primary key, so a user-chosen key would either
break dedup or be a no-op -- use `table=` / `collection=` to move the rows
or documents):

```python
from pydantic_ai_harness.media import FileMediaStore, MediaContext

def by_media_type(uri: str, ctx: MediaContext) -> str:
    digest = uri.removeprefix('media+sha256://')
    ext = {'image/png': '.png', 'image/jpeg': '.jpg'}.get(ctx.media_type or '', '.bin')
    return f'images/{digest}{ext}'

store = FileMediaStore('runs', key_strategy=by_media_type)
```

**Caveat**: if your strategy depends on `context.media_type` (e.g. to
pick an extension), `get(uri)` and `exists(uri)` won't find the blob
unless the same context is supplied at read time. For pure
path-organisation strategies (no context dependency) the constraint
doesn't apply.

`FileMediaStore` rejects strategies that produce absolute paths or paths
containing `..` segments, to prevent escaping the store directory.

Separately, all five stores accept a `public_url=` resolver, useful
when a CDN, local HTTP server, or signed-URL service fronts the bytes.
Without it `public_url(...)` returns `None` (the model never sees a URL
unless a resolver is configured and it returns a string).

Pydantic AI providers download the bytes from a URL when the target model
doesn't accept that URL type, so a URL costs a download rather than a failed
request.

### Persisting unsupported backends

DynamoDB, Redis, GCS, and other backends are not built in. Write your own
`StepStore` (about ten methods on a Protocol) or your own `MediaStore` (five
methods: `put`, `get`, `exists`, `public_url`, `get_metadata`) and pass it via
`store=` / `media_store=`.

## Moving sessions to a `ConversationStore`

Save each session to a `ConversationStore` once, then load and save around each
run as
[Using a conversation store](https://pydantic.dev/docs/ai/core-concepts/persistence/#using-a-conversation-store)
shows. Where a session's history lives decides what to copy:

- If you saved [conversation heads](#conversation-heads-and-background-names)
  with `SqliteConversationStore`, each head is the conversation, including
  edits between runs such as compaction. `move_heads` copies every head.
- Otherwise, a run's latest `complete` snapshot holds the history it continued
  plus what the run added, so the newest run of a conversation that has one
  holds the conversation up to that point. Call `move_conversation` for each ID
  your application passed as `conversation_id=` for a session. `list_runs()`
  lists every run, but core gives each run a fresh conversation ID when none is
  passed, so one-shot runs and delegates each have one of their own.

Run `move_heads` while nothing else writes to the store: `listing` pages by last
activity, so a head saved during the move can shift the pages and be skipped.

```python
from pydantic_ai import Conversation
from pydantic_ai.conversation_store import ConversationConflict, ConversationStore
from pydantic_ai_harness.step_persistence import StepStore
from pydantic_ai_harness.step_persistence.conversations import SqliteConversationStore


async def save_once(conversations: ConversationStore, conversation: Conversation, scope: str | None) -> None:
    try:
        await conversations.save(conversation, scope=scope)
    except ConversationConflict:
        pass  # moved by an earlier pass


async def move_conversation(
    steps: StepStore, conversations: ConversationStore, conversation_id: str, *, scope: str | None = None
) -> None:
    runs = [run for run in await steps.list_runs(conversation_id=conversation_id) if run.parent_run_id is None]
    if not runs:
        return
    snapshot = await steps.latest_snapshot(run_id=runs[-1].run_id)
    events = await steps.list_events(run_id=runs[-1].run_id)
    responses = [event.timestamp for event in events if event.kind == 'model_request_completed']
    if snapshot is None or (responses and snapshot.timestamp < max(responses)):
        raise ValueError(f'{conversation_id!r} has a turn no complete snapshot holds: settle its tool calls first')
    conversation = Conversation(messages=snapshot.messages, conversation_id=conversation_id)
    await save_once(conversations, conversation, scope)


async def move_heads(
    heads: SqliteConversationStore, conversations: ConversationStore, *, scope: str | None = None
) -> None:
    offset = 0
    while page := await heads.listing(offset=offset):
        for summary in page:
            saved = await heads.get(conversation_id=summary.id)
            await save_once(conversations, Conversation(messages=saved.messages, conversation_id=summary.id), scope)
        offset += len(page)
```

- The moved conversation starts with empty `usage` and no
  `deferred_tool_requests`, since neither source records them.
- `move_conversation` raises for a session whose newest run got a model
  response after its latest `complete` snapshot, such as a run waiting on an
  approval or a deferred result, or one stopped mid-tool. No `complete` snapshot
  holds that turn, so settle the calls first by continuing the run, then move
  the session.
- `save_once` skips a conversation the store already has, so a pass that stops
  partway can be run again to move the rest, and leaves conversations already
  moved, or saved since, unchanged. Pass `scope=` to record whose conversation
  it is, and the same `scope=` on every pass: a conversation the store has
  under another scope is skipped too.
- `move_heads` moves archived heads too, and saves each head as a conversation
  of its own, so the `forked_from` link a head records isn't kept.
- Keep `StepPersistence` on the agent if you still need the step-event trail,
  the tool-effect ledger, or
  [Conversation Search](https://pydantic.dev/docs/ai/harness/conversation-search/),
  which reads its store.

## Conversation heads and background names

`pydantic_ai_harness.step_persistence.conversations` provides
`SqliteConversationStore`, `ConversationSummary`, and `SavedConversation`, the
local session store behind CLAI's resume browser: alongside the messages it keeps
CLAI's workspace, title, naming, and busy-process metadata. For conversations in
an application, use core's `ConversationStore` instead, and see
[Moving sessions to a `ConversationStore`](#moving-sessions-to-a-conversationstore)
to copy heads already saved here. A conversation head is separate from per-run checkpoints:
it includes accepted prompts and between-run edits such as compaction. Do not
reconstruct it by concatenating overlapping run snapshots.

`save(summary=..., messages=...)` compares the supplied content revision and
returns the committed summary. A stale writer or a deleted session raises
`ConversationConflict`. `get(conversation_id=...)` restores messages through the
same media format used by step snapshots. `listing(query=..., limit=..., offset=...)`
returns summaries without loading messages; search matches saved user/assistant
text and metadata using Unicode case folding, including text entries within
multimodal prompts. Search does not include tool output, reasoning, or discarded
pre-compaction history. Unknown metadata schema versions are rejected.
An application may set `ConversationSummary.checkout` to a `GitCheckout` (repository,
name, checkout root, branch) for the workspace, so a browser can still group the
conversation by repository after that folder is removed; the store saves it as given.

`ConversationSummary.created_at` records when the conversation was first saved;
later saves keep it, so a browser can list conversations in a stable order:
`listing(order_by='created_at')` pages by it, so using an old conversation again
does not move it onto the first page. A conversation saved before the field
existed reads `None` until its next save, which sets it to the conversation's
previous `updated_at`.

Metadata naming uses a separate version. `name(source=..., title=..., ...)` cannot
overwrite a newer content revision, newer name, or a manual title. Naming does not
change the activity timestamp. `delete(source=...)` removes the conversation and
associated run records from the same SQLite database atomically, retaining shared
media. It is not secure erasure. A local live PID marks an unfinished conversation
as busy; this is not a distributed lease and the database must not be shared
between hosts. On Linux, a process that started after the conversation was last
saved has reused the recorded PID, so the conversation is not busy; elsewhere PID
reuse is conservatively treated as busy. Linux times a process's start from the
current wall clock, so if the clock jumps forward by more than the owner's age at
its last save, a running conversation reads as not busy.

`set_archived(conversation_id=..., archived=...)` archives or unarchives a
conversation through `ConversationSummary.archived_at`, a metadata-only change that
keeps its messages, content revision, and activity timestamp. Saving new content
unarchives it, since the conversation is in use again. Archiving deletes nothing.
`listing(archived=False)` leaves archived conversations out, `archived=True` lists
only those, and the default `None` lists both, as before archiving existed.

An application that copies a conversation may set `ConversationSummary.forked_from`
to the `id` of the conversation it copied; later saves keep it. It names the source
conversation, not a message in it, and the application decides which copies record it.
`listing(forked_from=...)` lists only the conversations recording that ID.

The database is created owner-only where supported. Contents are not encrypted.
There is no automatic conversation TTL or media garbage collection.

`pydantic_ai_harness.step_persistence.naming` is deprecated and emits a
`HarnessDeprecationWarning` on import. Its naming prompt, queue bounds, and
failure policy are CLAI's resume-browser policy rather than a Harness primitive,
so CLAI now owns its own copy. Copy the helpers you use into your application;
the module will be removed in a future release. The conversation store above is
unaffected. Until then, applications using its `SessionNamer` must join the worker
before closing its model clients or storage, and failed or timed-out naming
requests may still incur provider usage.

## Earlier checkpoints and notifications

Set `capture_frontier=True` to save accepted request histories before model
requests and the model response frontier before tool execution. The default is
`False` to preserve existing checkpoint frequency. CLAI enables it. A first model
request failure can then retain its prompt, and a process killed mid-tool-cycle
can retain the proposed calls and arguments even before a cycle settles.

`inspect_recovery(store=..., run_id=...)` in
`pydantic_ai_harness.step_persistence.recovery` returns the newest and settled
snapshots, unresolved effects, and names of recorded completed/failed tools.
It does not infer that an effect is safe to replay.

These are still message checkpoints, not graph-state checkpoints. Snapshots at
unsettled frontiers are `interrupted` and remain off the default read path.
`after_run` compares final content, not only message count, to catch same-length
or shortened history rewrites. Put the recorder before capabilities whose
`after_run` transforms history: core runs after-hooks in reverse order. Snapshot
message values are copied before storage so later mutations cannot alter a saved
in-memory checkpoint through shared references.

`SnapshotSavedEvent` is a typed capability event emitted after a checkpoint write
completes. It carries `persistence_run_id`, `conversation_id`, `step_index`, and
`state`. Subscribe using core's `hooks.on.event(SnapshotSavedEvent)`, which a CLAI plugin
returns from `get_capabilities`. Store writes are the source of truth; notifications may
repeat during durable replay and observer failures cannot undo committed writes.
`STEP_PERSISTENCE_EVENTS` is the namespace of that event (`step_persistence`), not of the
persisted `StepEvent` log.

Automatic execution recovery is not implemented. Snapshots are saved per settled
batch, not per tool, so a hard kill during a parallel batch can leave a completed
effect with no persisted result. A `started` effect is unknown after a crash, and
a `failed` tool may have made partial external changes. Returning to an older
`complete` checkpoint does not undo those changes, so tools with external effects
need their own idempotency or reconciliation strategy.

## What this capability does not do

- It does not restore capability per-run state, graph-node state, retry
  counters, or in-flight streaming responses.
- It does not deduplicate replayed side effects automatically. Tools that
  write artifacts, labels, PRs, or external state should call
  `annotate_tool_effect(store, ctx, ...)` (see [Failure recovery](#failure-recovery))
  so the orchestrator can decide whether replay is safe.
- It does not prune events, and by default does not prune snapshots.
  Retention is the caller's responsibility; snapshot growth can be bounded
  opt-in with `max_snapshots_per_run` (see [Bounding snapshot growth](#bounding-snapshot-growth)).
- It does not garbage-collect externalized media. Pruning a snapshot leaves
  its content-addressed blobs in place, since they may be shared across
  snapshots and runs.
- It does not emit OpenTelemetry spans. pydantic_ai's `Instrumentation`
  capability already spans `agent run` / `chat` / `running tool` and
  populates `gen_ai.agent.name`, `gen_ai.agent.call.id`,
  `gen_ai.conversation.id` via baggage.
