"""The question schema the model fills in, the payloads an answerer sees, and the `Answerer` protocol."""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field
from typing import Annotated, Protocol, TypeAlias
from urllib.parse import urlparse
from uuid import uuid4

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, TypeAdapter, field_validator, model_validator
from typing_extensions import TypedDict

from pydantic_ai._utils import is_google_files_api_url
from pydantic_ai.messages import (
    CachePoint,
    FileUrl,
    TextContent,
    ToolCallPart,
    ToolReturn,
    UploadedFile,
    UserContent,
    UserPromptPart,
)
from pydantic_ai.tools import AgentDepsT, RunContext

TOOL_NAME = 'ask_user_question'

MAX_QUESTIONS = 10
"""Most questions one `ask_user_question` call may carry."""

MIN_OPTIONS = 2
MAX_OPTIONS = 6
MAX_HEADER_LENGTH = 25
MAX_LABEL_LENGTH = 50
MAX_DESCRIPTION_LENGTH = 200
MAX_QUESTION_LENGTH = 500


def _printable(value: str, *, newlines: bool) -> str:
    """Reject control and format characters: these strings are drawn on terminals, and an escape sequence is an attack.

    Space separators, such as the no-break and ideographic spaces, are ordinary text. Format characters, such as
    zero-width spaces, joiners and bidirectional overrides, are not: they make two strings that differ look the same.
    """
    if not all(
        char.isprintable() or unicodedata.category(char) == 'Zs' or (newlines and char == '\n') for char in value
    ):
        raise ValueError('must not contain control characters or invisible formatting')
    return value


_SCHEMA_CONFIG = ConfigDict(str_strip_whitespace=True, extra='forbid', frozen=True)
"""Strict on the way in (a field the schema lacks is a retry, not a silent drop) and immutable after.

The request is validated once and the response is checked against it later, so nothing between,
an event listener or the answerer, may change what was asked.
"""


class QuestionOption(BaseModel):
    """One choice the user can pick."""

    model_config = _SCHEMA_CONFIG

    label: str = Field(min_length=1, max_length=MAX_LABEL_LENGTH, description='Short option name, one to five words.')
    description: str | None = Field(
        default=None, max_length=MAX_DESCRIPTION_LENGTH, description='What choosing this option means.'
    )

    @field_validator('label')
    @classmethod
    def _label_is_one_line(cls, value: str) -> str:
        return _printable(value, newlines=False)

    @field_validator('description')
    @classmethod
    def _description_is_printable(cls, value: str | None) -> str | None:
        return None if value is None else _printable(value, newlines=True)


class Question(BaseModel):
    """One multiple-choice question."""

    model_config = _SCHEMA_CONFIG

    header: str = Field(
        min_length=1,
        max_length=MAX_HEADER_LENGTH,
        description='Short label naming the question, unique within the call; the answer is keyed by it.',
    )
    question: str = Field(min_length=1, max_length=MAX_QUESTION_LENGTH, description='The full question text.')
    options: tuple[QuestionOption, ...] = Field(
        min_length=MIN_OPTIONS, max_length=MAX_OPTIONS, description='The choices to offer.'
    )
    multi_select: bool = Field(default=False, description='Whether the user may pick more than one option.')

    @field_validator('header')
    @classmethod
    def _header_is_one_line(cls, value: str) -> str:
        return _printable(value, newlines=False)

    @field_validator('question')
    @classmethod
    def _question_is_printable(cls, value: str) -> str:
        return _printable(value, newlines=True)

    @model_validator(mode='after')
    def _unique_labels(self) -> Question:
        _require_unique([option.label for option in self.options], what='option labels')
        return self


def _require_unique(values: list[str], *, what: str) -> None:
    # NFKC folds compatibility forms (full-width letters, ligatures), so look-alikes count as duplicates.
    # It leaves the Ogham space mark (U+1680) alone, so every space separator is made a plain space first.
    spaced = [''.join(' ' if unicodedata.category(char) == 'Zs' else char for char in value) for value in values]
    folded = [unicodedata.normalize('NFKC', value).casefold() for value in spaced]
    if len(folded) != len(set(folded)):
        raise ValueError(f'{what} must be unique')


def require_unique_headers(questions: list[Question]) -> list[Question]:
    """Reject a call whose questions share a header, since answers are keyed by it."""
    _require_unique([question.header for question in questions], what='question headers')
    return questions


Questions = Annotated[
    list[Question],
    Field(min_length=1, max_length=MAX_QUESTIONS),
    AfterValidator(require_unique_headers),
]
"""The `questions` argument of `ask_user_question`."""


class _ToolArgs(TypedDict):
    questions: Questions


_TOOL_ARGUMENTS = TypeAdapter(_ToolArgs)


@dataclass(frozen=True, kw_only=True)
class AskUserRequest:
    """One `ask_user_question` call, handed to the `Answerer` and carried by `AskUserRequestedEvent`."""

    questions: tuple[Question, ...]
    id: str = field(default_factory=lambda: uuid4().hex)
    """Distinguishes concurrent or repeated calls; a UI matches its reply to it.

    A deferred request uses the tool call ID, so `from_tool_call` rebuilds the same request.
    """

    @classmethod
    def from_tool_call(cls, call: ToolCallPart) -> AskUserRequest:
        """Rebuild the request behind a deferred `ask_user_question` call, to put it to the user.

        Raises `ValueError` when `call` is for another tool.
        """
        if call.tool_name != TOOL_NAME:
            raise ValueError(f'expected an {TOOL_NAME!r} call, got {call.tool_name!r}')
        return rebuild_request(call)


def rebuild_request(call: ToolCallPart, *, questions: object = None, request_id: object = None) -> AskUserRequest:
    """The request behind an `ask_user_question` call, whatever name a toolset wrapper such as `PrefixTools` gave it.

    `questions`, when given, are the ones the tool received, after hooks such as `before_tool_execute`
    rewrote the call's arguments; otherwise the call's own arguments are used. `request_id`, when given,
    is the ID the tool asked under; otherwise it is the call's ID.
    """
    arguments = _TOOL_ARGUMENTS.validate_python(call.args_as_dict() if questions is None else {'questions': questions})
    return AskUserRequest(
        questions=tuple(arguments['questions']),
        id=request_id if isinstance(request_id, str) else call.tool_call_id,
    )


@dataclass(frozen=True, kw_only=True)
class AskUserAnswer:
    """Picked labels, or a custom answer instead, with optional user notes for one question."""

    header: str
    selected: tuple[str, ...] = ()
    custom_answer: str | None = None
    note: tuple[UserContent, ...] = ()
    """User text and attachments, in order, accompanying either selected labels or a custom answer.

    Text follows the custom-answer character rules. A nonempty note must contain nonblank text
    or an attachment, not only whitespace or cache markers. Notes do not replace the answer.
    File URLs must use HTTP(S) with `force_download=False`; provider-uploaded file references
    are not accepted. Text metadata is not forwarded to message history.
    """


@dataclass(frozen=True, kw_only=True)
class AskUserResponse:
    """What the `Answerer` returns: one answer per question, or `cancelled` when the user declined."""

    answers: tuple[AskUserAnswer, ...] = ()
    cancelled: bool = False


AskUserResult: TypeAlias = ToolReturn[dict[str, list[str]]] | dict[str, list[str]] | str
"""The answer dictionary or decline text, wrapped in `ToolReturn` when user notes accompany the answers."""


class Answerer(Protocol):
    """Whatever puts the questions in front of a person: a terminal menu, a web form, a scripted test.

    A plain `async def` with this signature satisfies it. Return a cancelled response when the user
    declines; raise only for failures that should fail the run.
    """

    async def __call__(self, request: AskUserRequest, /) -> AskUserResponse:
        """Put `request` to the user and return what they picked."""
        ...  # pragma: no cover


def _check_note(note: tuple[UserContent, ...]) -> None:
    if not isinstance(note, tuple):
        raise ValueError('must be a tuple of `UserContent` items')
    if not note:
        return
    # Reuse core's content-type guard before notes reach a model adapter.
    try:
        UserPromptPart(content=note)
    except ValueError as exc:
        raise ValueError('must contain only `UserContent` items') from exc
    has_content = False
    for item in note:
        _check_note_file(item)
        if isinstance(item, str | TextContent):
            text = item if isinstance(item, str) else item.content
            _printable(text, newlines=True)
            has_content |= bool(text.strip())
        elif not isinstance(item, CachePoint):
            has_content = True
    if not has_content:
        raise ValueError('must not be blank')


def _check_note_file(item: UserContent) -> None:
    if isinstance(item, FileUrl):
        if urlparse(item.url).scheme not in {'http', 'https'}:
            raise ValueError('file URLs must use http or https')
        if item.force_download is not False:
            raise ValueError('file URLs must use `force_download=False`')
        # Google treats these URLs as authenticated Files API references, not public downloads.
        if is_google_files_api_url(item.url):
            raise ValueError('must not contain provider-uploaded file references')
    elif isinstance(item, UploadedFile):
        raise ValueError('must not contain provider-uploaded file references')


class ContextAnswerer(Protocol[AgentDepsT]):
    """An answerer that also receives the context of the run that asked the question.

    Two required positional parameters select this form. If a callable also accepts just one,
    annotate the first parameter as `RunContext[DepsT]` to disambiguate. The request and response
    follow the same contract as `Answerer`; the context is passed separately, not serialized
    into `AskUserRequest` or its events. Durable execution can restrict context fields; see
    [Temporal's run-context rules](https://pydantic.dev/docs/ai/capabilities/durable_execution/temporal/#agent-run-context-and-dependencies).
    """

    async def __call__(self, ctx: RunContext[AgentDepsT], request: AskUserRequest, /) -> AskUserResponse:
        """Put `request` to the user with access to the asking run's context."""
        ...  # pragma: no cover


class TokenAnswerer(Protocol[AgentDepsT]):
    """An answerer that may hand the question on and let the answer arrive later, through a resume token.

    Three required positional parameters select this form. Return the response to answer right away,
    as the other forms do, or `None` after delivering `token` to whoever will answer, such as in a
    Slack message. The run then waits until the token is resolved with the JSON form of an
    `AskUserResponse`: with `pydantic_ai.external_events.resolve_external_event` in process, or
    through the durable engine's API, such as AWS Lambda's `SendDurableExecutionCallbackSuccess`.
    """

    async def __call__(
        self, ctx: RunContext[AgentDepsT], request: AskUserRequest, token: str, /
    ) -> AskUserResponse | None:
        """Answer `request`, or deliver `token` and return `None`."""
        ...  # pragma: no cover


AnyAnswerer: TypeAlias = Answerer | ContextAnswerer[AgentDepsT] | TokenAnswerer[AgentDepsT]
"""Any answerer signature, for hosts storing a callback to pass to `AskUser`.

`Answerer` remains the request-only protocol; `ContextAnswerer` also receives the asking run's context,
and `TokenAnswerer` also a resume token, so it can let the answer arrive later.
"""


def check_response(request: AskUserRequest, response: AskUserResponse) -> None:
    """Raise `ValueError` when a response does not fit its request.

    A cancelled response carries no answers. A completed one answers every question with distinct
    labels that question offered, one of them unless `multi_select`, or a nonblank custom answer.
    Notes must be `UserContent` tuples; a nonempty note needs nonblank text or an attachment.
    Note text follows the custom-answer character rules. File references cannot claim provider
    uploads, non-HTTP(S) URLs or privileged download modes.
    """
    if response.cancelled:
        if response.answers:
            raise ValueError('a cancelled response carries no answers')
        return
    questions = {question.header: question for question in request.questions}
    for answer in response.answers:
        question = questions.pop(answer.header, None)
        if question is None:
            raise ValueError(f'answer for unknown or repeated question {answer.header!r}')
        _check_answer(question, answer)
    if questions:
        raise ValueError(f'unanswered questions: {sorted(questions)}')


def _check_answer(question: Question, answer: AskUserAnswer) -> None:
    try:
        _check_note(answer.note)
    except ValueError as exc:
        raise ValueError(f'answer note for {answer.header!r} {exc}') from exc
    if answer.custom_answer is not None:
        if answer.selected:
            raise ValueError('a custom answer cannot also select options')
        if not answer.custom_answer.strip():
            raise ValueError('a custom answer must not be blank')
        _printable(answer.custom_answer, newlines=True)
        return
    labels = {option.label for option in question.options}
    if unknown := [label for label in answer.selected if label not in labels]:
        raise ValueError(f'answer for {answer.header!r} picked options it does not offer: {unknown}')
    if not answer.selected:
        raise ValueError(f'answer for {answer.header!r} picked nothing')
    if len(set(answer.selected)) != len(answer.selected):
        raise ValueError(f'answer for {answer.header!r} picked the same option twice')
    if len(answer.selected) > 1 and not question.multi_select:
        raise ValueError(f'answer for {answer.header!r} picked several options but it is single-select')
