"""Ready-made checks to plug into a guard.

These are plain functions returning a
[`GuardrailResult`][pydantic_ai_harness.GuardrailResult], not capabilities. That is the
difference that makes them compose: several go into one `InputGuardrail` or
`OutputGuardrail` and run as a chain, next to whatever you write yourself, sharing
one place in the capability list and one set of spans.

```python
from pydantic_ai import Agent
from pydantic_ai_harness import InputGuardrail
from pydantic_ai_harness.guardrails.detectors import blocked_keywords, redact_secrets

agent = Agent(
    'openai:gpt-5.4',
    capabilities=[InputGuardrail(guard=[redact_secrets, blocked_keywords(['internal-only'])])],
)
```

They read text, so they suit a prompt directly. A structured agent output is
not text, and replacing one with a scrubbed string would change its type, so
reach for [`for_text`][pydantic_ai_harness.guardrails.detectors.for_text] to
say what should happen there.

A regex finds a credential because credentials have a shape; it does not find a
prompt injection, which is ordinary language, and it does not understand context,
so `email` also matches `git@github.com` in a clone URL. See the guardrails docs
for narrowing the defaults.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable, Mapping
from dataclasses import replace
from typing import Literal

from pydantic_ai.exceptions import UserError
from pydantic_ai.messages import ToolReturn
from pydantic_ai_harness.guardrails._shared import GuardrailResult, TextDetector as TextDetector
from pydantic_ai_harness.guardrails._tool_guardrail import ToolResultInfo
from pydantic_ai_harness.guardrails._tool_return_text import (
    detect_tool_return_content as _detect_tool_return_content,
    is_text_tool_return as _is_text_tool_return,
)

_NEWLINE = r'(?:\r?\n|\\+n)'
"""A line break as it reaches a detector.

A key pasted from a JSON service-account file or a `.env` line carries the two characters
a backslash and an `n` where the file had a newline. Requiring a real one left the most common way a
private key arrives in a support chat unredacted.
"""

_PEM_BODY = (
    rf'(?:[A-Za-z0-9+/=\s\\]*?-----END[^-\n]*PRIVATE KEY(?: BLOCK)?-----'
    rf'|(?:\s|\\+n)*(?:[A-Za-z0-9+/=]+(?:{_NEWLINE})?)+)'
)
"""What follows a PEM block's BEGIN line and any header lines: its body when it runs straight to an END marker, or else its body lines alone."""

DEFAULT_SECRET_PATTERNS: Mapping[str, str] = {
    # Vendor key bodies are base64url, whose alphabet includes `_`. A class that
    # stops at `_` redacts half a key and leaves the rest under a label saying it
    # is gone, which is worse than not matching at all.
    'anthropic_key': r'\bsk-ant-[A-Za-z0-9_-]{20,}',
    # Declared after the Anthropic shape it must not claim, and excluding it
    # explicitly so the label does not depend on declaration order.
    'openai_key': r'\bsk-(?!ant-)[A-Za-z0-9_-]{20,}',
    'aws_access_key': r'\b(?:AKIA|ASIA)[0-9A-Z]{16}\b',
    'github_token': r'\b(?:ghp|gho|ghu|ghs|ghr|github_pat)_[A-Za-z0-9_]{20,}',
    'slack_token': r'\bxox[bporas]-[A-Za-z0-9-]{10,}',
    'slack_app_token': r'\bxapp-\d-[A-Za-z0-9-]{10,}',
    'stripe_key': r'\b(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{20,}',
    'stripe_webhook_secret': r'\bwhsec_[A-Za-z0-9]{20,}',
    'google_api_key': r'\bAIza[A-Za-z0-9_-]{35}',
    'google_oauth_secret': r'\bGOCSPX-[A-Za-z0-9_-]{20,}',
    # A `-` directly before `eyJ` ends the header segment, so a failed match does
    # not rescan the rest of the token from each `eyJ` in it. A header segment
    # that contains `-eyJ` is not matched.
    'jwt': r'\beyJ(?:[A-Za-z0-9_]|-(?!eyJ)){10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}',
    # A PEM block, terminated or not. The newline after the BEGIN line is
    # required so prose naming both markers in one sentence is not swallowed as
    # a key.
    # The optional header lines are RFC 1421 fields (`Proc-Type`, `DEK-Info`),
    # which an encrypted key carries and whose `:` and `,` the body class stops
    # at.
    #
    # The two tails share one name rather than sitting under two, because
    # `only` selects by name: a caller narrowing to private keys would pick the
    # terminated shape, and a key pasted without its END marker -- the usual way
    # one reaches a chat window -- would then pass through unredacted under a
    # setting that says it is covered. Alternation is ordered, so a body that
    # runs straight to an END marker is claimed by the first tail, and the
    # second takes the body alone otherwise. That tail stops at the first
    # character that is not body, since running to the end of the input would
    # delete whatever the user wrote after the key; it starts past any blank
    # lines, as the terminated tail does.
    #
    # The lines after BEGIN are read one of three ways, in order:
    #
    # - With real line breaks and a header line first, the header section --
    #   every line up to the first blank one -- is taken whole, so a line in it
    #   that is not a header, or a value quoting an END marker or holding the
    #   two characters `\n` as a path does, does not end the block. A section
    #   with no blank line after it, a line in it that starts with an END
    #   marker, or a BEGIN marker anywhere in it, sends the block to the next
    #   reading instead.
    # - Otherwise, each header line runs to the end of its line, or, when no
    #   real line break follows, to the last escaped one: a key pasted with
    #   escaped newlines is a single line, so its header lines take everything
    #   up to that last escaped line break, END marker included. The body after
    #   them may be empty.
    # - With no header line, the body follows the BEGIN line.
    #
    # A header section stops at every BEGIN marker, so sections read from
    # different markers never overlap; a header value is read in runs, a
    # backslash run in one step; and a header line is never split again once
    # read. So the pattern runs in time linear in its input.
    'private_key': (
        rf'-----BEGIN[^-\n]*PRIVATE KEY(?: BLOCK)?-----[ \t]*'
        rf'(?:\r?\n(?=[A-Za-z-]+: )'
        rf'(?:(?!-----(?:BEGIN|END))(?:(?!-----BEGIN)[^\r\n]|\r(?!\n))+\r?\n)++(?=\r?\n){_PEM_BODY}'
        rf'|{_NEWLINE}(?:[A-Za-z-]+: (?>(?:[^\n\\]|\\++(?!n)|\\++n)*(?:\r?\n|(?<=\\n))))+(?:{_PEM_BODY})?'
        rf'|{_NEWLINE}{_PEM_BODY})'
    ),
}
"""Credential shapes worth redacting, in the order they are applied.

Prefixed and left-anchored on a word boundary, so false positives are rare: a
prefix is also a substring of ordinary text, and `sk-` without the boundary
takes the rest of `task-management-and-deployment` with it.

An AWS *secret* access key is deliberately absent. It is 40 characters of
base64 with no prefix, so nothing in the value marks it as a key; matching one
means anchoring on the name written beside it, which finds the key only where
it appears as an assignment. That narrower pattern is left to `extra` rather
than shipped as a default.
"""

DEFAULT_PII_PATTERNS: Mapping[str, str] = {
    # Before `credit_card`, whose digit groups would otherwise claim the middle
    # of a spaced IBAN and label it as a card number. The country code is drawn
    # from the IBAN registry rather than any two letters: the set is closed, and
    # anchoring on it is what keeps a build id or a patent number from reading
    # as an account. Case-insensitive, since the printed form is uppercase but
    # the standard is not. Spaces are allowed only where the printed form puts
    # them -- every fourth character -- and the whole match is checked against
    # the ISO 7064 mod-97 digit. Allowing a space before any character let the
    # pattern run across word boundaries and eat whole sentences.
    #
    # External assumption. The 89 codes below are the IBAN-adopting countries
    # and territories in the ISO 13616 IBAN Registry, which SWIFT maintains as
    # registration authority and republishes as members join. Verified
    # 2026-07-29 against
    # <https://www.swift.com/standards/data-standards/iban-international-bank-account-number>.
    # To re-check: download the registry (PDF or .txt) from that page, take its
    # `IBAN prefix country code (ISO 3166)` column, and diff it against this
    # list. A missing code means real IBANs from a new member pass through
    # unredacted, so add it and bump the date; if nothing changed, bump the date
    # alone.
    #
    # The lookahead is a cheap shape check ahead of the 89-way alternation, which the regex
    # engine otherwise tries at every word boundary. It leaves the matches unchanged and makes
    # the pattern about twenty times faster on text with many short words.
    'iban': (
        r'\b(?=[A-Za-z]{2}\d{2})(?i:AD|AE|AL|AT|AZ|BA|BE|BG|BH|BI|BR|BY|CH|CR|CY|CZ|DE|DJ|DK|DO|EE|EG|ES|FI|FK|FO|FR|GB|GE|GI|GL|GR'  # codespell:ignore fo
        r'|GT|HN|HR|HU|IE|IL|IQ|IS|IT|JO|KW|KZ|LB|LC|LI|LT|LU|LV|LY|MA|MC|MD|ME|MK|MN|MR|MT|MU|NI|NL|NO|OM|PK|PL'
        r'|PS|PT|QA|RO|RS|RU|SA|SC|SD|SE|SI|SK|SM|SO|ST|SV|TL|TN|TR|UA|VA|VG|XK)'
        r'\d{2}(?:[A-Za-z0-9]{10,30}|(?: [A-Za-z0-9]{4}){2,7}(?: [A-Za-z0-9]{1,3})?)\b'
    ),
    # 13 to 19 digits, the range ISO/IEC 7812 allows, in any grouping: fixing
    # the groups to 4-4-4-4 and Amex's 4-6-5 left a 13-digit Visa, a 14-digit
    # Diners and a 19-digit PAN unmatched, so a real card passed through.
    # Length alone would then take a millisecond timestamp with it, hence the
    # leading digit: the major industry identifier of a payment card is 2 to 6,
    # which is the same trick the IBAN country code plays above. Every match is
    # checked against the Luhn algorithm, which discards most runs of digits
    # that are not card numbers. Not all of them: roughly one in ten runs of
    # four consecutive years satisfies the checksum by chance.
    'credit_card': r'\b(?=[2-6])(?:\d[ -]?){12,18}\d\b',
    'us_ssn': r'\b\d{3}[- ]\d{2}[- ]\d{4}\b',
    # The local part is bounded and preceded by a negative lookbehind: an
    # unbounded `+` lets a failed match restart at every interior offset, which
    # makes a pasted log quadratic and blocks the event loop for seconds.
    'email': (
        r'(?<![A-Za-z0-9._%+-])[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]{1,63}(?:\.[A-Za-z0-9-]{1,63})*\.[A-Za-z]{2,24}\b'
    ),
}
"""Personal data shapes, in the order they are applied.

Narrower than the secret set, because these overlap ordinary text. `email`
matches anything shaped like an address, which includes `git@github.com` in a
shell command -- see the module docstring on where that matters.
"""

_REDACTED = '[redacted:{name}]'


def _luhn(digits: str) -> bool:
    """Whether a run of digits satisfies the Luhn checksum every card number does."""
    values = [int(character) for character in digits if character.isdigit()][::-1]
    total = sum(value if index % 2 == 0 else sum(divmod(value * 2, 10)) for index, value in enumerate(values))
    return len(values) >= 12 and total % 10 == 0


def _iban_mod97(candidate: str) -> bool:
    """Whether a candidate satisfies the ISO 7064 mod-97 check every IBAN carries.

    The country code narrows the prefix; nothing narrowed the body, so any `XX##` token
    followed by ten more letters or digits read as an account number -- `RS232 serial cable
    adapter and reboot` among them. A shape this loose needs the checksum the standard
    defines, the same way `credit_card` needs Luhn.
    """
    compact = ''.join(candidate.split()).upper()
    if not 15 <= len(compact) <= 34:
        return False
    rotated = compact[4:] + compact[:4]
    return int(''.join(str(int(character, 36)) for character in rotated)) % 97 == 1


_VALIDATORS: Mapping[str, Callable[[str], bool]] = {'credit_card': _luhn, 'iban': _iban_mod97}
"""Semantic checks that a shape alone cannot make. A name absent here is taken on its shape."""


def _compile(
    patterns: Mapping[str, str], only: Iterable[str] | None, extra: Mapping[str, str] | None
) -> tuple[tuple[str, re.Pattern[str], Callable[[str], bool] | None], ...]:
    """The patterns a detector will run, as `(name, compiled, validator)` triples.

    A validator belongs to the built-in pattern it was written for, not to its
    name. A custom pattern supplied under a built-in name -- possible once
    `only` has dropped that built-in -- would otherwise be judged by a check
    written for different text and silently never match.
    """
    selected = dict(patterns) if only is None else _select_only(patterns, only)
    if extra:
        clashes = sorted(set(extra) & set(selected))
        if clashes:
            raise UserError(
                f'`extra` would replace the built-in pattern(s) {clashes} rather than add to them. '
                'Rename them, or pass `only` to drop the built-in first.'
            )
        selected.update(extra)
    if not selected:
        raise UserError('This detector was given no patterns, so it would never match anything.')
    overridden = set(extra or ())
    return tuple(
        (name, re.compile(pattern), None if name in overridden else _VALIDATORS.get(name))
        for name, pattern in selected.items()
    )


def _select_only(patterns: Mapping[str, str], only: Iterable[str]) -> dict[str, str]:
    """The `patterns` named in `only`, in the order of `patterns`; raises on a name it does not have."""
    # `only` filters, it does not reorder. Both mappings document an application order
    # that other patterns depend on -- `iban` before `credit_card` is what stops a spaced
    # account number being labelled a card -- and building the dict by iterating `only`
    # handed that order to the caller's argument order instead.
    requested = set(only)
    for name in requested:
        if name not in patterns:
            raise UserError(f'Unknown pattern {name!r}; available: {sorted(patterns)}.')
    return {name: pattern for name, pattern in patterns.items() if name in requested}


def _require_text(value: object) -> str:
    """Return `value` as text, naming the mistake when it is not.

    Every detector takes `object` rather than `str`, because one plugged
    straight into an `OutputGuardrail` is handed the agent output unchanged.
    Checking here says which knob answers that, instead of letting `re` raise a
    TypeError from three frames down.
    """
    if not isinstance(value, str):
        raise UserError(
            f'A text detector received {type(value).__name__}, which it cannot scan. An OutputGuardrail '
            'hands the guard the agent output unchanged, so wrap the detector in for_text() to say '
            'what should happen when that output is not text.'
        )
    return value


def _redactor(
    compiled: tuple[tuple[str, re.Pattern[str], Callable[[str], bool] | None], ...], placeholder: str
) -> TextDetector:
    """A detector that rewrites every match and allows text with none."""

    def detect(text: object) -> GuardrailResult:
        text = _require_text(text)
        cleaned = text
        for name, pattern, valid in compiled:
            substitution = placeholder.replace('{name}', name)

            def replace(match: re.Match[str], valid: Callable[[str], bool] | None = valid, out: str = substitution):
                # A function rather than a template string: `re.sub` reads
                # backreferences in a replacement, so a placeholder containing
                # `\g<0>` would re-emit the very text being redacted.
                return out if valid is None or valid(match.group()) else match.group()

            cleaned = pattern.sub(replace, cleaned)
        return GuardrailResult.replace(cleaned) if cleaned != text else GuardrailResult.allow()

    return detect


def secret_data(
    *,
    only: Iterable[str] | None = None,
    extra: Mapping[str, str] | None = None,
    placeholder: str = _REDACTED,
) -> TextDetector:
    """Build a detector that rewrites credentials out of text.

    It redacts rather than refuses: an agent that quotes a key back has still
    done the work, and blocking the answer would lose it while leaving the key
    in the message history.

    Args:
        only: Restrict to these names from `DEFAULT_SECRET_PATTERNS`.
        extra: Additional `name -> regex` patterns to include.
        placeholder: What each match is replaced with. `{name}` in it becomes
            the pattern that matched, so a redaction says what it removed.
    """
    return _redactor(_compile(DEFAULT_SECRET_PATTERNS, only, extra), placeholder)


def personal_data(
    *,
    only: Iterable[str] | None = None,
    extra: Mapping[str, str] | None = None,
    placeholder: str = _REDACTED,
) -> TextDetector:
    """Build a detector that rewrites personal data out of text.

    Redaction, not refusal. An email address in a prompt is usually the user
    telling the agent something it needs, so blocking the turn would break
    ordinary use; removing it before it reaches the model does not.

    Args and behaviour match
    [`secret_data`][pydantic_ai_harness.guardrails.detectors.secret_data],
    over `DEFAULT_PII_PATTERNS`.
    """
    return _redactor(_compile(DEFAULT_PII_PATTERNS, only, extra), placeholder)


redact_secrets = secret_data()
"""`secret_data()` with every default pattern, for the common case."""

redact_personal_data = personal_data()
"""`personal_data()` with every default pattern, for the common case."""


def blocked_keywords(
    keywords: Iterable[str],
    *,
    case_sensitive: bool = False,
    whole_words: bool = False,
    message: str | None = None,
) -> TextDetector:
    """Build a detector that refuses text containing any of `keywords`.

    Args:
        keywords: Literal strings to look for. They are escaped, so a keyword
            with regex punctuation matches itself.
        case_sensitive: Match case exactly. Off by default.
        whole_words: Require word boundaries, so `class` stops matching inside
            `classification`.
        message: The refusal text. The default names the keyword that matched,
            which is useful to an operator and visible to the model, so pass
            something neutral when the list itself is sensitive.
    """
    if isinstance(keywords, str):
        raise UserError(
            'blocked_keywords() was given a single string, which would be one keyword per character and '
            f'block nearly every input. Pass a sequence: blocked_keywords([{keywords!r}]).'
        )
    flags = 0 if case_sensitive else re.IGNORECASE
    terms = tuple(keywords)
    if any(not keyword for keyword in terms):
        raise UserError('blocked_keywords() was given an empty keyword, which would match every input.')
    compiled = tuple(
        # `(?<!\w)`/`(?!\w)` rather than `\b`: a boundary needs a word character on
        # one side, so `\bC\+\+\b` never matches `C++` and the keyword would be
        # silently inert.
        re.compile(rf'(?<!\w){re.escape(keyword)}(?!\w)' if whole_words else re.escape(keyword), flags)
        for keyword in terms
    )
    if not compiled:
        raise UserError('blocked_keywords() was given no keywords, so it would never match anything.')

    def detect(text: object) -> GuardrailResult:
        text = _require_text(text)
        for pattern in compiled:
            match = pattern.search(text)
            if match:
                return GuardrailResult.block(message or f'Blocked term: {match.group()!r}.')
        return GuardrailResult.allow()

    return detect


def for_text(
    detector: TextDetector, *, on_other: Literal['raise', 'allow'] = 'raise'
) -> Callable[[object], GuardrailResult]:
    """Adapt a text detector to a guard over a value that may not be text.

    An `OutputGuardrail` receives the agent output unchanged, which for a structured
    output is a model instance rather than a string. Substituting a scrubbed
    string for it would change the output's type, so this refuses to guess:
    `'raise'` fails loudly, telling you to apply the detector to a field
    instead, and `'allow'` lets non-text through when you know the other output
    types carry nothing to check.
    """

    def guard(value: object) -> GuardrailResult:
        if isinstance(value, str):
            return detector(value)
        if on_other == 'allow':
            return GuardrailResult.allow()
        raise UserError(
            f'A text detector received {type(value).__name__}, which it cannot rewrite without changing the '
            "output's type. Apply it to a field of the output, or pass on_other='allow' to skip non-text."
        )

    return guard


def for_tool_result_text(
    detector: TextDetector, *, on_other: Literal['raise', 'allow'] = 'raise'
) -> Callable[[ToolResultInfo], GuardrailResult]:
    """Adapt a text detector to the result object `ToolGuardrail` supplies.

    Plain string results are passed to `detector`. For a `ToolReturn` with a
    string `return_value`, the detector also checks the text in its
    model-directed `content`, both part by part and over each stretch of
    adjacent text parts joined, so a secret split across two of them is caught.
    The `ToolReturn` is rebuilt when either channel is redacted, retaining its
    `metadata`, `kind`, and non-text content.

    A non-text result has no safe text replacement. The default raises with the
    adapter name. `on_other='allow'` skips the whole result rather than part of
    it: neither `return_value` nor `content` is scanned, so a `ToolReturn` with a
    structured `return_value` reaches the model with its `content` untouched.
    Leave `on_other` at its default and apply the detector to a field of the
    output when a skipped result may carry sensitive `content`.
    """

    def guard(info: ToolResultInfo) -> GuardrailResult:
        result = info.result
        if isinstance(result, str):
            verdict = detector(result)
            if verdict.action == 'replace' and not isinstance(verdict.replacement, str):
                raise UserError(
                    'A text detector used with for_tool_result_text() must replace a tool result with text.'
                )
            return verdict
        if _is_text_tool_return(result):
            return _tool_return_verdict(detector, result)
        if on_other == 'allow':
            return GuardrailResult.allow()
        raise UserError(
            f'for_tool_result_text() received {type(result).__name__}, which has no text payload to rewrite. '
            "Pass on_other='allow' to skip non-text tool results."
        )

    return guard


def _tool_return_verdict(detector: TextDetector, result: ToolReturn[str]) -> GuardrailResult:
    """Run `detector` over a `ToolReturn`'s string `return_value` and its `content`.

    The `ToolReturn` is rebuilt when either changed.
    """
    # `ToolReturn`'s type parameter does not type `return_value`, so the guard cannot narrow it.
    assert isinstance(result.return_value, str)
    verdict = detector(result.return_value)
    if verdict.action not in ('allow', 'replace'):
        return verdict
    return_value = verdict.replacement if verdict.action == 'replace' else result.return_value
    if not isinstance(return_value, str):
        raise UserError('A text detector used with for_tool_result_text() must replace a tool result with text.')

    content_verdict, content = _detect_tool_return_content(detector, result.content)
    if content_verdict is not None:
        return content_verdict

    if verdict.action == 'replace' or content is not None:
        return GuardrailResult.replace(
            replace(
                result,
                return_value=return_value,
                content=result.content if content is None else content,
            )
        )
    return GuardrailResult.allow()
