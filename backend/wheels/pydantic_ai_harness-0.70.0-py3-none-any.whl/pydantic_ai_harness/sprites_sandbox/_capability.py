"""Capability that supplies a Fly.io Sprite sandbox to an agent run."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from sprites import AsyncSpritesClient

from pydantic_ai.capabilities import AbstractCapability, WrapRunHandler
from pydantic_ai.messages import Authority
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai.workspaces import WorkspaceBackend, WorkspaceRef
from pydantic_ai_harness._workspace import innermost_backend, with_authority
from pydantic_ai_harness._workspace_provider import (
    check_path_authority,
    check_provider,
    check_working_dir,
    reject_defer_loading,
)
from pydantic_ai_harness.sprites_sandbox._backend import SpritesSandboxBackend, destroy_sprite

if TYPE_CHECKING:
    from pydantic_ai.agent import AgentRunResult


class _SuppliedBackend(SpritesSandboxBackend):
    """The backend `SpritesSandbox` built for one run; the capability closes its client when that run ends."""

    def __init__(self, *, run_id: str | None, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.run_id = run_id
        # Until a run claims it, nothing closes this backend: Temporal builds one per activity and
        # drops it, so its own client closes after each operation instead.
        self._close_after_operation = True

    def claim(self, owned: bool) -> None:
        """Keep the client open across operations while the run that closes it is in progress."""
        self._close_after_operation = not owned


@dataclass(kw_only=True)
class SpritesSandbox(AbstractCapability[AgentDepsT]):
    """Run the agent's workspace in a persistent [Fly.io Sprite](https://sprites.dev).

    A run with no reference creates a fresh Sprite on first use; pass a `WorkspaceRef` to attach
    to an existing one. Ending a run does not delete the Sprite: it sleeps when idle and persists
    until you delete it. Commands run under `sh -c` in the Sprite's own shell environment.

    This capability supplies the workspace only. Compose it with capabilities that use it, such
    as `Coder`, `Shell`, and `FileSystem`. See
    [Workspaces](https://pydantic.dev/docs/ai/core-concepts/workspace/) for more.
    """

    client: AsyncSpritesClient | None = None
    """A caller-owned `sprites.AsyncSpritesClient`, which is never closed for you. When omitted,
    each run's backend creates one on first use from `SPRITE_TOKEN` and closes it when the run
    ends; a backend this capability supplies outside a run (under Temporal, one per activity)
    closes its client after each operation. A backend from `backend(ref)` needs `aclose()`. Supply one to share its connections across runs, on one event loop."""

    runtime: str | None = None
    """Runtime for a newly created Sprite; an unknown runtime fails on first use."""

    working_dir: str | None = None
    """Absolute directory commands start in and relative paths resolve against; `None` uses the Sprite's default.
    Created on a new Sprite; an attached Sprite must already have it."""

    env: Mapping[str, str] | None = field(default=None, repr=False)
    """Environment variables every command gets, on top of the Sprite's own; a command's `env` is layered on top."""

    authority: Authority = 'operator'
    """The [authority][pydantic_ai.messages.Authority] of the sandbox's files: `'none'` for files nobody on the
    application's side wrote, such as a cloned third-party repository, and `'user'` for the user's own files.
    Anything below `'operator'` wraps the workspace in an [`AuthorityWorkspace`][pydantic_ai.workspaces.AuthorityWorkspace]."""

    path_authority: Mapping[str, Authority] | None = None
    """Levels for some directories and files, overriding `authority` for the paths under them; the longest matching
    path wins. Paths are sandbox paths: relative ones resolve against the working directory, and `~` isn't expanded.
    See [`Workspace.authority_of`][pydantic_ai.workspaces.Workspace.authority_of]."""

    def __post_init__(self) -> None:
        reject_defer_loading('SpritesSandbox', self.defer_loading)
        # Checked here rather than at the first workspace operation, so a bad value fails where it is written.
        check_working_dir(self.working_dir)
        check_path_authority(self.path_authority)

    @classmethod
    def from_spec(
        cls,
        *,
        id: str | None = None,
        description: str | None = None,
        defer_loading: bool = False,
        runtime: str | None = None,
        working_dir: str | None = None,
        env: Mapping[str, str] | None = None,
        authority: Authority = 'operator',
        path_authority: Mapping[str, Authority] | None = None,
    ) -> SpritesSandbox[Any]:
        """Build from an agent spec, naming the fields a spec can express.

        Core reads this signature to generate the spec's JSON schema. Inherited, core reads `__init__`, and
        `client`'s `AsyncSpritesClient` hint has no JSON schema, so only the bare `'SpritesSandbox'` is published.
        """
        return cls(
            id=id,
            description=description,
            defer_loading=defer_loading,
            runtime=runtime,
            working_dir=working_dir,
            env=env,
            authority=authority,
            path_authority=path_authority,
        )

    def backend(self, ref: WorkspaceRef) -> SpritesSandboxBackend:
        """Construct a lazy backend for an existing Sprite."""
        return SpritesSandboxBackend(
            client=self.client, ref=ref, runtime=self.runtime, working_dir=self.working_dir, env=self.env
        )

    async def destroy(self, ref: WorkspaceRef) -> None:
        """Delete a Sprite by id without attaching or waking it.

        A Sprite that no longer exists is already gone, so destroying it returns quietly.
        """
        check_provider(ref, 'sprites')
        await destroy_sprite(self.client, ref.id)

    def get_workspace(self, ctx: RunContext[AgentDepsT], *, ref: WorkspaceRef | None) -> WorkspaceBackend | None:
        """The backend for this run, in an `AuthorityWorkspace` when `authority` or `path_authority` asks for one."""
        return with_authority(self._run_backend(ctx, ref=ref), self.authority, self.path_authority)

    def _run_backend(self, ctx: RunContext[AgentDepsT], *, ref: WorkspaceRef | None) -> WorkspaceBackend | None:
        """Build the backend for this run. No I/O here: it attaches or creates on first use."""
        if ref is not None and ref.provider != 'sprites':
            return None
        return _SuppliedBackend(
            run_id=ctx.run_id,
            client=self.client,
            ref=ref,
            runtime=self.runtime,
            working_dir=self.working_dir,
            env=self.env,
        )

    async def wrap_run(self, ctx: RunContext[AgentDepsT], *, handler: WrapRunHandler) -> AgentRunResult[Any]:
        # Only the backend this run built: one passed in as `workspace=`, such as a parent run's
        # handed to a subagent, belongs to the run that built it and may still be in use.
        backend = innermost_backend(ctx.workspace)
        owned = backend if isinstance(backend, _SuppliedBackend) and backend.run_id == ctx.run_id else None
        if owned is not None:
            owned.claim(True)
        try:
            return await handler()
        finally:
            if owned is not None:
                # `result.workspace` outlives the run, with no one left to close it.
                owned.claim(False)
                await owned.aclose()
