"""Private helpers for capabilities adopting the run sandbox."""

import errno
import hashlib
import posixpath
import shlex
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import NoReturn

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.exceptions import ToolFailed, UserError
from pydantic_ai.messages import Authority, ModelMessage, ModelResponse
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai.workspaces import (
    AuthorityWorkspace,
    FileEntry,
    SupportsCommands,
    UnavailableWorkspace,
    Workspace,
    WorkspaceBackend,
    WorkspaceError,
    WorkspaceReadOnlyError,
    WorkspaceRef,
    WorkspaceTimeoutError,
    WorkspaceUnavailableError,
    WrapperWorkspace,
)
from pydantic_ai.workspaces.unavailable import NO_WORKSPACE

READ_ONLY_FAILURE = 'The workspace is read-only; the change was refused.'
"""What the model sees when a tool's mutation reaches a read-only workspace."""


def workspace_path(path: Path) -> str:
    """Return the sandbox spelling of a configured path; `~` is not expanded."""
    if path.parts and path.parts[0].startswith('~'):
        raise UserError(
            f'Workspace paths do not expand `~`: {path!s}. '
            'Use an absolute path inside the sandbox or a path relative to its working directory.'
        )
    return path.as_posix()


def raise_tool_failure(error: WorkspaceError) -> NoReturn:
    """Report a deliberate workspace failure to the model as a failed tool call.

    A retry cannot fix a read-only workspace, an expired deadline, or a backend that refused the
    operation, so these become `ToolFailed` rather than `ModelRetry`. `WorkspaceUnavailableError`
    means the environment is gone and is re-raised to end the run.

    Callers catch `WorkspaceError` before any `PermissionError` or `OSError` handler:
    `WorkspaceReadOnlyError` is also a `PermissionError` and `WorkspaceTimeoutError` is also a
    `TimeoutError`, so a broader handler placed first would give them the wrong treatment.
    """
    if isinstance(error, WorkspaceUnavailableError):
        raise error
    if isinstance(error, WorkspaceReadOnlyError):
        raise ToolFailed(READ_ONLY_FAILURE) from error
    if isinstance(error, WorkspaceTimeoutError):
        raise ToolFailed(str(error) or 'The workspace operation timed out.') from error
    raise ToolFailed(str(error) or f'The workspace operation failed ({type(error).__name__}).') from error


async def stat_or_none(workspace: Workspace, path: str) -> FileEntry | None:
    """The entry at `path`, or `None` when nothing is there."""
    try:
        return await workspace.stat(path)
    except (FileNotFoundError, NotADirectoryError):
        return None


def supports_commands(workspace: Workspace) -> bool:
    """Whether `workspace.run` can succeed: a workspace is attached, its innermost backend executes commands, and no policy refuses them."""
    if not workspace.attached or workspace.read_only:
        return False
    return isinstance(innermost_backend(workspace), SupportsCommands)


def innermost_backend(workspace: Workspace) -> WorkspaceBackend:
    """The backend at the bottom of `workspace`'s facades and wrappers.

    Wrappers are unwrapped through `wrapped`, not `backend`: a durable workspace refuses
    `backend` in workflow code, where tool registration runs.
    """
    current: WorkspaceBackend = workspace
    while isinstance(current, Workspace):
        current = current.wrapped if isinstance(current, WrapperWorkspace) else current.backend
    return current


def is_unattached(workspace: Workspace) -> bool:
    """Whether `workspace` is core's placeholder for a run with no workspace.

    Unlike an `UnavailableWorkspace` passed on purpose, it is not a choice, so it gets a setup hint.
    """
    return innermost_backend(workspace) is NO_WORKSPACE


_LOCAL_CAPABILITIES = {'local': 'LocalWorkspace', 'windows': 'WindowsWorkspace'}
"""The capability for a host workspace's ref provider, which takes the ref's directory."""

_PROVIDER_CAPABILITIES = {
    'modal': 'ModalSandbox()',
    'e2b': 'E2BSandbox()',
    'render': 'RenderSandbox()',
    'sprites': 'SpritesSandbox()',
    'daytona': 'DaytonaSandbox()',
    'boxd': 'BoxdSandbox()',
    'kubernetes': 'KubernetesSandbox(warm_pool=...)',
    'opensandbox': 'OpenSandbox()',
}
"""The capability that provides each first-party provider's workspaces, to name in an error."""


def _history_ref(messages: Sequence[ModelMessage]) -> WorkspaceRef | None:
    """The workspace the message history continues in: the last response's ref, as core reads it."""
    response = next((message for message in reversed(messages) if isinstance(message, ModelResponse)), None)
    return None if response is None else response.workspace_ref


def require_workspace(workspace: Workspace, owner: str, messages: Sequence[ModelMessage]) -> None:
    """Raise `UserError` when the run has no workspace, naming `owner` and how to attach one.

    Called from `before_run`, so a missing workspace fails the run at its start rather than on
    the first tool call. When `messages` continue in a workspace, the error names it, since
    attaching another workspace would not reach the files the conversation worked on.
    """
    backend = innermost_backend(workspace)
    # A deliberate refusal carries the caller's reason; an unattached run gets the setup hint.
    if isinstance(backend, UnavailableWorkspace) and not is_unattached(workspace):
        raise UserError(f'`{owner}` cannot use this workspace: {backend.reason}')
    if not workspace.attached and (ref := _history_ref(messages)) is not None:
        if (local := _LOCAL_CAPABILITIES.get(ref.provider)) is not None:
            example = f' (such as `{local}({ref.id!r})`)'
        elif (capability := _PROVIDER_CAPABILITIES.get(ref.provider)) is not None:
            example = f' (such as `{capability}`)'
        else:
            example = ''
        raise UserError(
            f'`{owner}` needs a workspace. The message history continues in workspace '
            f'`{ref.provider}:{ref.id}`; attach the capability that provides `{ref.provider}` workspaces'
            f'{example} to continue there, or pass `workspace=` to the run.'
        )
    if not workspace.attached:
        local = 'WindowsWorkspace' if sys.platform == 'win32' else 'LocalWorkspace'
        raise UserError(
            f'`{owner}` needs a workspace, but none is attached to this run. '
            f"Add `{local}('.')` (this machine; `from pydantic_ai.capabilities import {local}`, "
            f'or `- {local}: .` in an agent spec) or a sandbox capability such as `ModalSandbox()` '
            "to the agent's capabilities, or pass `workspace=` to the run. "
            'See https://pydantic.dev/docs/ai/workspace/'
        )


@dataclass
class RequireWorkspace(AbstractCapability[AgentDepsT]):
    """Fails a run without a workspace at its start, naming `owner`.

    A member of a combined capability, placed first: a combined capability's hooks are flattened
    into the agent's, so this runs before any bundled capability's own check and the message names
    the harness the developer added.
    """

    owner: str

    async def before_run(self, ctx: RunContext[AgentDepsT]) -> None:
        require_workspace(ctx.workspace, self.owner, ctx.messages)


def secondary_workspace(value: WorkspaceBackend | None, owner: str) -> Workspace | None:
    """Validate a capability's own `workspace=` argument, for storage or resources kept outside the run's workspace.

    It takes a backend (or a `Workspace` facade), never a workspace capability: the capability
    supplies a run's workspace, not one to read from on the side.
    """
    if value is None:
        return None
    if isinstance(value, AbstractCapability):
        raise TypeError(
            f'`{owner}(workspace=...)` takes a workspace backend, not the `{type(value).__name__}` capability. '
            "Pass a backend such as `LocalWorkspaceBackend('/app')`."
        )
    return value if isinstance(value, Workspace) else Workspace(value)


def in_working_dir(path: str) -> bool:
    """Whether a configured workspace path stays inside the working directory.

    `FileSystem`'s root contains the working directory, so the run's file tools can reach such a path.
    """
    normalized = posixpath.normpath(path)
    return not posixpath.isabs(normalized) and normalized.split('/', 1)[0] != '..'


METADATA_DIR = '.pydantic-ai-harness'
"""The directory, below a workspace's working directory, that holds files harness capabilities keep for themselves."""


async def metadata_dir(workspace: Workspace, name: str, *, temp_fallback: bool = False) -> str:
    """Return `<working_dir>/.pydantic-ai-harness/<name>`, creating it.

    `.pydantic-ai-harness` gets a `.gitignore` holding `*` whenever it has none, including a
    directory that already existed, so none of it shows up in `git status`. Only filesystem operations are used, so a workspace that
    cannot run commands works too. A path in the way raises `WorkspaceError`: it is no tool
    argument's fault, so a retry cannot fix it. So does a symlink in place of either directory, or a
    dangling `.gitignore`: it could lead outside the working directory.

    With `temp_fallback`, a working directory the workspace user cannot write to on a POSIX workspace
    (a root-owned `/app` in a container that runs as `nobody`, or a read-only mount) gets the directory from
    `_temp_metadata_dir` instead. That runs a command, so only callers that already need commands
    pass it; the directory is outside the working directory, so `FileSystem` tools cannot read it.
    """
    join = workspace.paths.join
    working_dir = await workspace.working_dir()
    root = join(working_dir, METADATA_DIR)
    directory = join(root, name)
    gitignore = join(root, '.gitignore')
    real_root = join(await workspace.realpath(working_dir), METADATA_DIR)
    if await workspace.realpath(directory) != join(real_root, name):
        raise WorkspaceError(f'`{METADATA_DIR}/{name}` in the workspace is a symlink, so it is not used.')
    try:
        await workspace.make_dir(directory)
        if not await workspace.exists(gitignore):
            # A dangling symlink reads as missing; writing it would create its target.
            if await workspace.realpath(gitignore) != join(real_root, '.gitignore'):
                raise WorkspaceError(f'`{METADATA_DIR}/.gitignore` in the workspace is a symlink, so it is not used.')
            await workspace.write_text(gitignore, '*\n')
    except WorkspaceError:
        raise
    except OSError as error:
        # The temp directory is found with a POSIX shell script.
        posix = workspace.platform == 'posix'
        if temp_fallback and posix and (isinstance(error, PermissionError) or error.errno == errno.EROFS):
            return await _temp_metadata_dir(workspace, real_root, name, error)
        raise WorkspaceError(f'Cannot create `{METADATA_DIR}/{name}` in the workspace: {error.strerror}') from error
    return directory


_TEMP_METADATA_DIR_SCRIPT = """umask 077
dir="${{TMPDIR:-/tmp}}/{prefix}-$(id -u)-{tag}"
sub="$dir"/{name}
mkdir -p "$dir" && [ ! -L "$dir" ] && [ -O "$dir" ] && mkdir -p "$sub" && [ ! -L "$sub" ] && [ -O "$sub" ] && printf '%s' "$sub"
"""


async def _temp_metadata_dir(workspace: Workspace, real_root: str, name: str, error: OSError) -> str:
    """Create `<name>` in a directory under the workspace user's temp directory, private to that user.

    The directory is named after the user ID and the working directory, so each run in the same
    workspace finds the same files. Another user on a shared `/tmp` could create that name first, so
    each directory is checked to be no symlink and owned by the workspace user before anything is
    created inside it; `umask 077` keeps a directory created here private.
    """
    tag = hashlib.sha256(real_root.encode()).hexdigest()[:12]
    script = _TEMP_METADATA_DIR_SCRIPT.format(prefix=METADATA_DIR, tag=tag, name=shlex.quote(name))
    result = await workspace.run(script, shell=True)
    if result.exit_code != 0:
        raise WorkspaceError(
            f'Cannot create `{METADATA_DIR}/{name}` in the workspace ({error.strerror}) '
            'or a private directory for it in the temp directory.'
        ) from error
    return result.stdout


def with_authority(
    backend: WorkspaceBackend | None, authority: Authority, path_authority: Mapping[str, Authority] | None
) -> WorkspaceBackend | None:
    """`backend` in an `AuthorityWorkspace` when a workspace capability's `authority` or `path_authority` asks for one."""
    if backend is None or (authority == 'operator' and not path_authority):
        return backend
    workspace = backend if isinstance(backend, Workspace) else Workspace(backend)
    return AuthorityWorkspace(workspace, authority=authority, path_authority=path_authority)
