"""Events emitted by the filesystem capability.

Each event carries two path fields:

- `path`: normalized and relative to the emitting filesystem's root, never an
  absolute path, so it is safe to echo to the model or a UI. A file reached
  through a symlink keeps the name it was reached by.
- `root_dir`: the root the `path` is relative to, as an absolute POSIX path
  inside the run's workspace with its symlinks resolved, so a subscriber can
  locate the file (`posixpath.join(root_dir, path)`) in that workspace without
  assuming it shares the emitter's root.

A diff in an event is a unified diff cut at `MAX_EVENT_DIFF_CHARS` with a
`truncated` flag, so an event stream that is persisted or forwarded to a UI
cannot be flooded by one large write. A change whose text is longer than
`MAX_DIFF_SOURCE_CHARS` on either side is not diffed at all.
"""

from dataclasses import dataclass
from typing import Annotated, Literal

from pydantic import AliasChoices, Field
from typing_extensions import deprecated

from pydantic_ai import CapabilityEvent
from pydantic_ai_harness._warn import HarnessDeprecationWarning

FILE_SYSTEM_EVENTS = 'file_system'

MAX_EVENT_DIFF_CHARS = 8192
"""Characters kept in an event's `diff` before it is cut."""

MAX_DIFF_SOURCE_CHARS = 4 * MAX_EVENT_DIFF_CHARS
"""Longest text on either side of a change that is still diffed; past it the `diff` is the headers alone."""

FileOperation = Literal['write', 'edit', 'create_directory']
"""The change a `FileChangeRequestedEvent` announces."""

SearchKind = Literal['find', 'grep']
"""Whether a `FilesSearchedEvent` matched names (`find_files`, `list_files`) or contents (`search_files`, `grep`)."""


@dataclass(kw_only=True)
class FileReadEvent(CapabilityEvent, namespace=FILE_SYSTEM_EVENTS):
    """A file was read successfully, including an image, PDF or other binary file.

    `content_hash` is the hash of the whole file's bytes, whatever window was
    returned: the hash `write_file` and `edit_file` check `expected_hash` against.
    """

    path: str
    root_dir: str
    content_hash: str


@dataclass(kw_only=True)
class DirectoryListedEvent(CapabilityEvent, namespace=FILE_SYSTEM_EVENTS):
    """A directory was listed successfully."""

    path: str
    root_dir: str
    entry_count: int


@dataclass(kw_only=True)
class FileWrittenEvent(CapabilityEvent, namespace=FILE_SYSTEM_EVENTS):
    """A text file was written or edited successfully."""

    path: str
    root_dir: str
    content_hash: str


@dataclass(kw_only=True)
class FileEditedEvent(FileWrittenEvent):
    """An existing text file was changed in place by `edit_file`.

    A `FileWrittenEvent` with the change itself: `diff` is the unified diff
    from the content before the edit to the content after it. Listeners for
    `FileWrittenEvent` receive edits too, since this is a subclass.
    """

    diff: str
    truncated: bool


@dataclass(kw_only=True)
class DirectoryCreatedEvent(CapabilityEvent, namespace=FILE_SYSTEM_EVENTS):
    """A directory was created, along with any missing parents."""

    path: str
    root_dir: str


@dataclass(kw_only=True)
class FilesSearchedEvent(CapabilityEvent, namespace=FILE_SYSTEM_EVENTS):
    """A search under `path` finished.

    `match_count` is the number of matches the model received; `truncated`
    says the search stopped at the capability's result cap.
    """

    path: str
    root_dir: str
    pattern: str
    search_kind: Annotated[SearchKind, Field(validation_alias=AliasChoices('search_kind', 'search'))]
    match_count: int
    truncated: bool

    @property
    @deprecated('`search` is deprecated, use `search_kind` instead.', category=HarnessDeprecationWarning)
    def search(self) -> SearchKind:
        """Deprecated alias for `search_kind`."""
        return self.search_kind


@dataclass(kw_only=True)
class FileChangeRequestedEvent(
    CapabilityEvent, namespace=FILE_SYSTEM_EVENTS, name='file_change_request', dispatch='immediate'
):
    """A file or directory is about to change; listeners may cancel it first.

    Fires after the path has passed the access checks and, for a write or
    edit, after the conflict check, so a listener only sees changes that
    would otherwise go ahead; a write re-reads the file just before writing,
    so a file changed in the meantime can still fail after it was announced.
    A cancelled change is not applied and the model gets `cancel_reason` as
    the tool result.

    `diff` is the unified diff from the current content to the proposed
    content; a new file diffs from empty, and a `create_directory` has none.
    """

    path: str
    root_dir: str
    operation: FileOperation
    diff: str
    truncated: bool
    cancelled: bool = False
    cancel_reason: str | None = None

    def cancel(self, reason: str | None = None) -> None:
        """Stop the change from being applied; a `reason` given by any listener reaches the model."""
        self.cancelled = True
        if reason is not None or self.cancel_reason is None:
            self.cancel_reason = reason
