# SSH Workspace

Run your agent's commands and file edits on another machine over SSH, using your own `ssh` client and its configuration.

[Source](https://github.com/pydantic/pydantic-ai/tree/main/src/pydantic_ai_harness/pydantic_ai_harness/ssh_workspace/)

> While Pydantic AI Harness is on 0.x releases, the API may change between minor releases; when it does, deprecation warnings and release-note migration guidance tell you (or your agent) exactly how to upgrade. See the [version policy](https://pydantic.dev/docs/ai/harness/#version-policy).

```mermaid
flowchart TB
    accTitle: SSH Workspace: your agent's commands run on another machine over SSH
    accDescr: On your machine, the model calls Coder, Shell or FileSystem tools such as run_command. As their ctx.workspace, SSHWorkspace uses your ssh client with key login only to open a new SSH connection to host dev@build-box for each operation, run as the login user. A WorkspaceRef in the message history for the same host and directory reattaches, and any other ref raises ValueError.
    subgraph machine["Your machine"]
        model(["model"])
        tools["Coder, Shell or<br/>FileSystem tools,<br/>such as run_command"]
        ref["WorkspaceRef<br/>in the message history"]
        ssh["SSHWorkspace()<br/>your ssh client,<br/>key login only"]:::capability
    end
    host["host dev@build-box<br/>runs as the login user"]:::external
    other["ref for any other<br/>host or directory"]:::blocked
    model <-->|"tool call, result"| tools
    tools -->|"ctx.workspace"| ssh
    ref -.->|"same host and<br/>directory: reattaches"| ssh
    ssh <-->|"a new SSH connection<br/>for each operation"| host
    ssh -.-x|"raises ValueError"| other
    classDef capability stroke:#E520E9,stroke-width:2px
    classDef external stroke:#0E9C86,stroke-width:2px
    classDef blocked stroke:#E5533D,stroke-width:2px,stroke-dasharray:4 3
```

## Install

uv:

```bash
uv add "pydantic-ai-harness[coder,anthropic]"
```

pip:

```bash
pip install "pydantic-ai-harness[coder,anthropic]"
```

No extra is needed for SSH itself: the capability runs the `ssh` client already on your machine. The `coder` extra is there because the examples use `Coder`; the workspace itself doesn't need it. The `anthropic` extra is there because the examples use an Anthropic model; swap it for your model provider's extra.

## Quick start

```python {test="skip"}
from pydantic_ai import Agent
from pydantic_ai_harness import Coder, SSHWorkspace

agent = Agent(
    'anthropic:claude-opus-5-5',
    capabilities=[SSHWorkspace('dev@build-box', working_dir='/srv/app', env={'UV_OFFLINE': '1'}), Coder()],
)
result = agent.run_sync('Run the test suite and fix the first failure.')
```

`Coder`'s shell and file tools now run on `build-box`, as the user you log in as, with that user's full authority on the host. To confine the commands, wrap the capability in [`BubblewrappedWorkspace`](https://pydantic.dev/docs/ai/harness/bubblewrap-sandbox/).

`working_dir` defaults to the login directory, and a relative one starts there. The directory must already exist. Commands get the remote login environment plus `env=`. For a single run, pass `workspace=SSHWorkspaceBackend('dev@build-box')` to `agent.run` instead.

## Logging in

Logging in needs a key; passwords aren't supported. `ssh` runs with `BatchMode=yes`, so a host that asks for a password or a key passphrase fails right away instead of hanging the run, and `ssh_args=` can't turn prompts back on. Use a key without a passphrase, such as `ssh_args=['-i', key_path]` or `IdentityFile` in your SSH configuration, or load a key that has one into `ssh-agent` with `ssh-add`. Set the user in the destination (`dev@build-box`), with `User` in your SSH configuration, or with `ssh_args=['-l', 'dev']`. Your SSH configuration (`~/.ssh/config`) also supplies ports and jump hosts.

## How commands run

Every operation opens an SSH connection, and file operations run as shell commands on the host, so the host needs a POSIX `sh` and the usual file utilities. Turn on connection sharing in your SSH configuration (`ControlMaster auto` with a `ControlPersist` time) to make them fast.

The script that runs each command reaches the host's `sh` on the connection's input rather than on its command line, and the command itself reads an empty input, as it would locally. So a command, however many quotes it holds, can be as long as the host allows one program argument to be: 128 KiB on Linux. If `ssh` doesn't forward its input (`-n` or `-f` in `ssh_args`, or `StdinNull` in your SSH configuration), the script goes on the host's command line instead, where a long command full of quotes can be too long to start.

A host that can't be reached, a missing working directory, or a connection lost mid-command raises `WorkspaceUnavailableError`. The exit code is the command's own, even when it is 255, which `ssh` also uses for its own errors.

On a timeout or cancellation, a second connection stops the command's processes on the host; a command that detached into a session of its own, like a [Shell](https://pydantic.dev/docs/ai/harness/shell/) background job, keeps running.

A command that leaves a background process holding its output open, such as `server &` without redirecting the server's output, doesn't return until that process exits, because `sshd` waits for the output to close: redirect it, as in `server > server.log 2>&1 &`.

## Reattach later

The ref is `WorkspaceRef(provider='ssh', id='dev@build-box:/srv/app')`, available from construction. `SSHWorkspace` only accepts a reference to its own host and directory, so a ref in message history can't point it at another machine. `SSHWorkspace(...).backend(ref)` builds the backend for such a ref without connecting, and raises `ValueError` for any other.

## Security

`SSHWorkspace` has the full authority of the remote user. Neither `working_dir` nor a [FileSystem](https://pydantic.dev/docs/ai/harness/filesystem/) root jails shell commands. Do not pass your local environment to the host: choose the variables the command needs with `env=`, which is kept out of the capability's `repr`.

That's what commands can do. What the host's files can *say* is separate: for a checkout the operator didn't write, pass `authority='none'` (or `'user'` for the user's own files), with `path_authority` for single paths on the host (`~` isn't expanded). The workspace reports the level through `authority_of`, and a capability that checks it sends a file's text to the model with no more [authority](https://pydantic.dev/docs/ai/core-concepts/workspace/#workspace-authority) than that. Default: `'operator'`.

`env=` values travel inside the script that `ssh` sends, which this machine passes to a local `sh` as arguments, so while a command runs they are visible in process listings (`ps`) to other users on this machine, and on the host too when `ssh` doesn't forward its input (see above). Don't put secrets in `env=` on a shared machine: keep them in a file only the remote user can read, or in the remote user's login environment.

## Platforms

The machine running the agent must be POSIX (Linux or macOS), like [`LocalWorkspace`](https://pydantic.dev/docs/ai/core-concepts/workspace/#platforms): constructing `SSHWorkspace` on Windows raises `NotImplementedError`. The host needs a POSIX `sh` and the usual file utilities.

## Telemetry

`SSHWorkspace` emits no spans of its own. Core's [instrumentation](https://pydantic.dev/docs/ai/capabilities/instrumentation/) records the workspace on the agent run span as `pydantic_ai.workspace.provider` (`ssh`) and `pydantic_ai.workspace.id` (the host and directory, recorded even without `include_content`, because it identifies the environment rather than content), and each command or file operation a tool makes runs inside that tool call's span.

## API reference

::: pydantic_ai_harness.ssh_workspace.SSHWorkspace

::: pydantic_ai_harness.ssh_workspace.SSHWorkspaceBackend
