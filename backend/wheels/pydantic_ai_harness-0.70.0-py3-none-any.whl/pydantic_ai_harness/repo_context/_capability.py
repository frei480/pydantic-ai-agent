"""RepoContext: discover and load a repo's accumulated context engineering."""

from __future__ import annotations

import warnings
from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass, field
from fnmatch import fnmatchcase
from pathlib import Path
from typing import Any, Literal

from pydantic_ai._instructions import SourcedInstruction, append_on_change_by_default
from pydantic_ai._utils import is_str_dict, replace_no_init
from pydantic_ai.capabilities import AbstractCapability, on_event
from pydantic_ai.exceptions import UserError
from pydantic_ai.messages import (
    CompactionPart,
    DataCapabilityPart,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    TextContent,
    ToolCallPart,
    UserPromptPart,
    WorkspaceSource,
    post_compaction_window,
)
from pydantic_ai.tools import AgentDepsT, RunContext, ToolDefinition
from pydantic_ai.toolsets import AgentToolset
from pydantic_ai.workspaces import SupportsCommands, SupportsRealpath, Workspace
from pydantic_ai_harness._warn import SET_WORKING_DIR_ON_THE_WORKSPACE, HarnessDeprecationWarning, warn_argument_ignored
from pydantic_ai_harness._workspace import in_working_dir, innermost_backend, require_workspace, workspace_path
from pydantic_ai_harness.file_system import DirectoryListedEvent, FileEditedEvent, FileReadEvent, FileWrittenEvent
from pydantic_ai_harness.file_system._tool_kinds import step_aside_for_read_file
from pydantic_ai_harness.repo_context._loader import (
    ContextFile,
    context_file_label,
    context_file_part_content,
    dir_context_file_path,
    directories_up_to,
    discover_instruction_files,
    find_dir_context_file,
    find_root,
    render_context_files,
)
from pydantic_ai_harness.repo_context._toolset import RepoContextToolset

_INVENTORY_HINT = (
    'Call `{tool_name}` to map where this repo keeps its coding-assistant setup '
    '(instruction dirs, skills, sub-agents, and hooks) so you can inspect it.'
)
_ASSET_ROOTS_HINT = (
    'This repo may keep its coding-assistant setup in {roots}: `skills/*/SKILL.md`, '
    '`agents/*.md` (sub-agents), and `settings.json` (hooks). Inspect it with your file tools, '
    'or call `{tool_name}` to map it when that tool is offered.'
)
_POINTER_NOTE = (
    'A directory you just accessed has an instruction file, not loaded here. Its path is in the accompanying '
    '{frame}. Read the file if it is relevant to your task.'
)
_NESTED_PRECEDENCE = (
    'Instruction files ({names}) apply to the directory they are in and everything below it. Where instruction '
    "files conflict, the more deeply nested one takes precedence, and the user's direct instructions take "
    'precedence over all of them.'
)
_NESTED_NOTE_ORIGIN = 'pydantic-ai-harness.repo_context.nested_note.v1'
"""The `origin` in the `metadata` of the user-channel text an earlier version enqueued as a nested note, next to the
surfaced `directory`; still recognized in a saved history, so a note in it isn't surfaced again."""


@dataclass(kw_only=True)
class ContextFilePart(
    DataCapabilityPart[str], namespace='repo_context', name='context_file', tag='context_file', attributes=('path',)
):
    """A nested instruction file's contents, as `RepoContext(nested_inject='contents')` surfaces them.

    Repository data on the user channel, in a `<context_file>` tag naming the file. Find them in history by this type.
    """

    path: str
    """The file's label: its path relative to the working directory."""

    directory: str
    """The directory the file applies to, which the traversal surfaced. Never sent to the model."""


@dataclass(kw_only=True)
class ContextFilePathPart(
    DataCapabilityPart[str],
    namespace='repo_context',
    name='context_file_path',
    tag='context_file_path',
    note=_POINTER_NOTE,
):
    """A pointer to a nested instruction file, as `RepoContext(nested_inject='pointer')` surfaces it.

    Its content is the file's label, with a note in the application's voice asking the model to read the file if it
    is relevant. Find them in history by this type.
    """

    directory: str
    """The directory the file applies to, which the traversal surfaced. Never sent to the model."""


_DEFAULT_TRAVERSAL_TOOL_NAMES = frozenset({'list_directory', 'read_file'})
_DEFAULT_TRAVERSAL_PATH_ARG = 'path'
_TRAVERSAL_DEPRECATION = (
    '`RepoContext.traversal_tool_names` and `RepoContext.traversal_path_arg` are deprecated. '
    'Traversal detection now reacts to `FileReadEvent`, `DirectoryListedEvent` and `FileWrittenEvent`. '
    'Hosts can emit these events by importing them from `pydantic_ai_harness.file_system`. '
    'The customized tool-sniffing fallback remains active for this configuration.'
)


@dataclass
class RepoContext(AbstractCapability[AgentDepsT]):
    """Discover and load a repo's accumulated coding-assistant context engineering.

    Everything is read through the run's workspace, anchored at its working
    directory; a run without a workspace fails at its start.

    Three strategies, each independently toggleable:

    1. Instruction autoload (`autoload_instructions`, on by default): load the
       working directory's instruction file, one per directory: the first of
       `filenames` (`AGENTS.md`, then `CLAUDE.md`) that exists. `walk_up` adds the
       ancestors up to the repository root (`'repo_root'`) or the filesystem root
       (`'all'`); files are deduped by content, broadest first. These are read once at run start
       and injected as system instructions via `get_instructions`, so they stay in
       the cached prefix, stable within a run; a change between runs of a
       conversation is appended rather than rewritten.

    2. Asset inventory (`expose_inventory_tool`, off by default): a tool that
       reports where the repo's coding-assistant assets live (`.claude`/`.agents`/`.codex`/
       `.grok` and their `skills/`, `agents/`, `settings.json`). It locates
       assets; it does not parse them. It steps aside for `FileSystem`'s
       `read_file` when the asset roots are inside the working directory, and
       the instructions then point at the roots instead.

    3. Nested-on-traversal (`nested_traversal`, on by default): when the model
       lists a directory, reads a file in it, or writes or edits a file in it,
       through a filesystem capability event, surface the instruction file of
       that directory and of every directory between it and the working
       directory, shallowest first. The working directory's own files are not
       repeated when Strategy 1 loaded them. The note is enqueued in the message
       tail, not added to system instructions, so it does not invalidate the
       cached prefix. `nested_inject='contents'` (default) inlines the file body;
       `'pointer'` enqueues a one-line pointer. With it on, the instructions also
       gain one static sentence on how instruction files relate: each applies to
       its subtree, the deeper one wins, and the user's direct instructions win
       over all of them.

    ```python
    from pydantic_ai import Agent
    from pydantic_ai.capabilities import LocalWorkspace
    from pydantic_ai_harness.repo_context import RepoContext

    agent = Agent(
        'anthropic:claude-sonnet-4-6',
        capabilities=[LocalWorkspace('.'), RepoContext(walk_up='repo_root')],
    )
    ```
    """

    workspace_dir: Path | None = None
    """Deprecated and ignored: the walk-up and asset scan are anchored at the workspace's working directory.

    Set the working directory on the workspace instead, e.g. `LocalWorkspace('./repo')`.
    """

    home_dir: str | Path | None = None
    """The shallowest workspace directory to stop the walk-up at, inclusive, as a workspace path.

    A relative path resolves against the working directory. Symlinks in it are followed, as they are in the
    working directory, so a linked spelling stops the walk-up at the directory it leads to. Setting it walks
    up to it even with `walk_up=None`, and with `walk_up='all'` it stops the walk there. It cannot be
    combined with `walk_up='repo_root'`.
    """

    filenames: Sequence[str] = ('AGENTS.md', 'CLAUDE.md')
    """Instruction filenames to look for. Each directory contributes only the first one that exists there."""

    autoload_instructions: bool = True
    """Strategy 1: load instruction files into the system prompt."""

    autoload_symlink_roots: Sequence[str | Path] = field(default=(), kw_only=True)
    """Authorize external autoload targets beneath these workspace paths, empty by default.

    Roots and targets are resolved through the workspace. Requires a backend implementing
    `SupportsRealpath` or command execution for workspace symlink resolution. External files
    retain their scanned entry's label. Nested traversal and inventory are unaffected.
    """

    expose_inventory_tool: bool = False
    """Strategy 2: expose the asset-inventory tool."""

    inventory_tool_name: str = 'inventory_agent_context'
    """Name of the inventory tool exposed to the model."""

    nested_traversal: bool = True
    """Strategy 3: surface the instruction files between the working directory and
    a directory the model lists, or reads, writes or edits a file in, through `FileSystem` events (or the
    same events emitted by another file tool). With it on, the instructions also state
    how instruction files relate."""

    nested_inject: Literal['pointer', 'contents'] = 'contents'
    """For Strategy 3: inline the file `contents`, or append a one-line `pointer` the model can follow."""

    traversal_tool_names: frozenset[str] = _DEFAULT_TRAVERSAL_TOOL_NAMES
    """Deprecated tool names used by the compatibility traversal detector."""

    traversal_path_arg: str = _DEFAULT_TRAVERSAL_PATH_ARG
    """Deprecated path argument used by the compatibility traversal detector."""

    asset_roots: Sequence[str] = ('.claude', '.agents', '.codex', '.grok')
    """Root directories the inventory tool scans, relative to the working directory."""

    walk_up: Literal['repo_root', 'all'] | None = None
    """How far above the working directory Strategy 1 looks for instruction files.

    `None` (the default) scans only the working directory, unless `home_dir` is set. `'repo_root'`
    walks up to the nearest directory holding one of `root_markers`, as Codex does, and scans only the
    working directory when there is none. `'all'` walks every ancestor up to the filesystem root (or
    `home_dir`), as Claude Code does.
    """

    root_markers: Sequence[str] = ('.git',)
    """Entry names that mark the repository root for `walk_up='repo_root'`.

    An entry of any kind counts, so a linked worktree's `.git` file marks its root like a `.git` directory.
    """

    nested_exclude: Sequence[str] = field(default=('node_modules', '.venv', 'venv', 'site-packages'), kw_only=True)
    """For Strategy 3: `fnmatch` patterns for directory names whose instruction files are never surfaced.

    A directory is skipped when any component of its path below the working directory matches, either as written
    or after resolving symlinks, so everything beneath a match is skipped too, while the directories above it are
    still surfaced. The default covers directories package managers install into, whose instruction files are
    written for the package's own contributors and would otherwise take precedence over the project's. Matching
    is case-sensitive.
    """

    nested_max_chars: int | None = 32_000
    """For Strategy 3 with `nested_inject='contents'`: the total characters of nested file contents to inline per conversation.

    The total counts every inlined note still in the history the model sees, from earlier runs of the conversation
    too, so it drops when a compaction summarizes earlier notes away. A file that would take the total past it is
    surfaced as a pointer instead. `None` inlines every file. It has no effect with `nested_inject='pointer'`,
    which inlines nothing.
    """

    _context_files: list[ContextFile] | None = field(default=None, init=False, repr=False, compare=False)
    """Walk-up result for this run, loaded once in `before_run` via `ctx.workspace`."""

    _pending_dirs: set[str] = field(default_factory=set[str], init=False, repr=False, compare=False)
    """Directories whose Strategy 3 note is enqueued but not yet in history."""

    _loaded_dirs: set[str] = field(default_factory=set[str], init=False, repr=False, compare=False)
    """Directories whose instruction files Strategy 1 put in the instructions, which Strategy 3 never repeats."""

    _pending_chars: dict[str, int] = field(default_factory=dict[str, int], init=False, repr=False, compare=False)
    """Characters each pending note in `_pending_dirs` inlined, counted against `nested_max_chars` until it's in history."""

    _window_chars: int = field(default=0, init=False, repr=False, compare=False)
    """Characters the inlined notes in the history window hold, as of the latest `_sync_surfaced_dirs`."""

    _latest_compaction: CompactionPart | None = field(default=None, init=False, repr=False, compare=False)
    """The latest compaction in history when `_pending_dirs` was last checked; a new one clears them."""

    _cached_working_dir: Path | None = field(default=None, init=False, repr=False, compare=False)
    """The workspace's working directory for this run."""

    _toolset: RepoContextToolset[AgentDepsT] | None = field(default=None, init=False, repr=False, compare=False)
    """The one inventory toolset, shared with every per-run copy so durable execution sees the leaf it registered."""

    _sniff_traversal_tools: bool = field(default=False, init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        if isinstance(self.root_markers, str):
            raise UserError(f'`RepoContext.root_markers` takes a sequence of names, e.g. `({self.root_markers!r},)`.')
        if isinstance(self.nested_exclude, str):
            raise UserError(
                f'`RepoContext.nested_exclude` takes a sequence of patterns, e.g. `({self.nested_exclude!r},)`.'
            )
        if self.nested_max_chars is not None and self.nested_max_chars < 0:
            raise UserError('`RepoContext.nested_max_chars` must not be negative.')
        if self.home_dir is not None and self.walk_up == 'repo_root':
            raise UserError(
                "`RepoContext` takes either `home_dir` or `walk_up='repo_root'` to stop the walk-up, not both."
            )
        if self.workspace_dir is not None:
            warn_argument_ignored('RepoContext', 'workspace_dir', SET_WORKING_DIR_ON_THE_WORKSPACE)
        self._sniff_traversal_tools = (
            self.traversal_tool_names != _DEFAULT_TRAVERSAL_TOOL_NAMES
            or self.traversal_path_arg != _DEFAULT_TRAVERSAL_PATH_ARG
        )
        if self._sniff_traversal_tools:
            warnings.warn(_TRAVERSAL_DEPRECATION, HarnessDeprecationWarning, stacklevel=2)

    async def for_run(self, ctx: RunContext[AgentDepsT]) -> RepoContext[AgentDepsT]:
        """Return a fresh per-run instance with isolated traversal/cache state.

        The copy skips `__post_init__`, so deprecated arguments warned about at construction are not warned again.
        """
        run = replace_no_init(self)
        run._context_files = None
        run._pending_dirs = set()
        run._loaded_dirs = set()
        run._pending_chars = {}
        run._window_chars = 0
        run._latest_compaction = None
        run._cached_working_dir = None
        return run

    async def before_run(self, ctx: RunContext[AgentDepsT]) -> None:
        """Fail without a workspace, and load walk-up instruction files so `get_instructions` is sync."""
        require_workspace(ctx.workspace, 'RepoContext', ctx.messages)
        if not self.autoload_instructions:
            return
        workspace = ctx.workspace
        working_dir = await self._working_dir(workspace)
        top: Path | None = None
        if self.home_dir is not None:
            # The working directory has its symlinks resolved, so `home_dir` needs them resolved too to contain it.
            top = Path(await workspace.realpath(workspace_path(Path(self.home_dir))))
        elif self.walk_up == 'repo_root':
            top = await find_root(workspace, working_dir, self.root_markers)
        elif self.walk_up == 'all':
            top = Path(working_dir.anchor)
        self._context_files = await discover_instruction_files(
            workspace,
            working_dir,
            top,
            self.filenames,
            autoload_symlink_roots=await self._autoload_symlink_roots(workspace),
        )
        # The walk-up loaded the working directory's instruction files (or an identical ancestor copy), so nested
        # traversal has nothing to add there. A file that appears there later in the run is still surfaced.
        if self.nested_traversal and await dir_context_file_path(workspace, working_dir, self.filenames) is not None:
            self._loaded_dirs.add(str(working_dir))

    def get_instructions(self) -> str | Callable[[RunContext[AgentDepsT]], str | None] | None:
        """Cache-stable instructions resolved after `before_run` loads workspace files."""
        if not self.autoload_instructions:
            # Neither part depends on the run, so they stay static and inside the cached prefix.
            return '\n\n'.join(self._static_instructions()) or None

        def instructions(_ctx: RunContext[AgentDepsT]) -> str | None:
            return self._render_instructions()

        return instructions

    def _collect_instructions(self) -> list[SourcedInstruction[AgentDepsT]]:
        # The context files are read each run, so an edit to one between runs is appended as a change (a
        # diff, when that's shorter) rather than rewriting the cached prompt.
        return append_on_change_by_default(super()._collect_instructions(), key='repo_context')

    def _render_instructions(self) -> str | None:
        parts: list[str] = []
        if self._context_files:
            assert self._cached_working_dir is not None, '`before_run` resolves it before loading files'
            parts.append(render_context_files(self._context_files, relative_to=self._cached_working_dir))
        parts.extend(self._static_instructions())
        return '\n\n'.join(parts) or None

    def _static_instructions(self) -> list[str]:
        parts: list[str] = []
        if self.expose_inventory_tool:
            parts.append(self._inventory_hint())
        if self.nested_traversal:
            parts.append(_NESTED_PRECEDENCE.format(names=', '.join(f'`{name}`' for name in self.filenames)))
        return parts

    def _inventory_hint(self) -> str:
        """Point at the inventory tool, and at the asset roots when a file reader can replace it.

        It names no reader, so it is the same whether or not `FileSystem` is on the agent.
        """
        if self._asset_roots_in_working_dir:
            roots = ', '.join(f'`{root}/`' for root in self.asset_roots)
            return _ASSET_ROOTS_HINT.format(roots=roots, tool_name=self.inventory_tool_name)
        return _INVENTORY_HINT.format(tool_name=self.inventory_tool_name)

    @property
    def _asset_roots_in_working_dir(self) -> bool:
        """Whether every asset root is inside the working directory, which `FileSystem`'s root contains.

        The inventory reads the run's workspace, so this is all it takes for `read_file` to reach the same files.
        """
        return bool(self.asset_roots) and all(in_working_dir(root) for root in self.asset_roots)

    def get_toolset(self) -> AgentToolset[AgentDepsT] | None:
        """The asset-inventory toolset, or `None` when the tool is disabled."""
        if not self.expose_inventory_tool:
            return None
        if self._toolset is None:
            toolset = RepoContextToolset[AgentDepsT](
                self.asset_roots, self.inventory_tool_name, id=self.id or 'repo_context'
            )
            if self._asset_roots_in_working_dir:
                toolset.tools[self.inventory_tool_name].prepare = step_aside_for_read_file
            self._toolset = toolset
        return self._toolset

    async def after_tool_execute(
        self,
        ctx: RunContext[AgentDepsT],
        *,
        call: ToolCallPart,
        tool_def: ToolDefinition,
        args: dict[str, Any],
        result: Any,
    ) -> Any:
        """Support customized legacy traversal tool and argument names."""
        if (
            not self.nested_traversal
            or not self._sniff_traversal_tools
            or call.tool_name not in self.traversal_tool_names
        ):
            return result
        raw_path = args.get(self.traversal_path_arg)
        if not isinstance(raw_path, str):
            return result
        # The deprecated sniffer can name a directory outside the working directory on purpose, so only the
        # directories between it and the working directory are confined.
        await self._enqueue_context(ctx, await self._resolve_directory(ctx.workspace, raw_path), confine_target=False)
        return result

    @on_event(FileReadEvent, DirectoryListedEvent, FileWrittenEvent)
    async def _on_file_traversal(
        self, ctx: RunContext[AgentDepsT], event: FileReadEvent | DirectoryListedEvent | FileWrittenEvent
    ) -> None:
        """Enqueue nested context after an authorized filesystem traversal, write or edit."""
        if not self.nested_traversal:
            return
        working_dir = await self._working_dir(ctx.workspace)
        path = Path(await ctx.workspace.resolve(event.path, base=event.root_dir))
        directory = path if isinstance(event, DirectoryListedEvent) else path.parent
        # Only a full write shows the model a whole file: a read can return a window of it, and an edit changes part.
        full_write = isinstance(event, FileWrittenEvent) and not isinstance(event, FileEditedEvent)
        written_file = path if full_write else None
        try:
            directory.relative_to(working_dir)
        except ValueError:
            return
        await self._enqueue_context(ctx, directory, written_file=written_file)

    async def _enqueue_context(
        self,
        ctx: RunContext[AgentDepsT],
        directory: Path,
        *,
        confine_target: bool = True,
        written_file: Path | None = None,
    ) -> None:
        """Surface the instruction file of `directory` and of each directory between it and the working directory.

        Files are enqueued shallowest first, so the most specific file is the latest one the model reads.
        """
        working_dir = await self._working_dir(ctx.workspace)
        real_working_dir: Path | None = None
        in_history = self._sync_surfaced_dirs(ctx.messages)
        for current in self._chain_until_excluded(directory, working_dir):
            # Already surfaced, so it passed the check below then; skipping it first saves a `realpath`, which is a
            # command round trip on shell-backed sandboxes.
            if self._surfaced(str(current), in_history):
                continue
            # The tool authorized the file or directory it touched, not every directory in its lexical path: a
            # symlinked directory there can take one of them, or the file's own parent, outside the project. So
            # each must resolve inside the working directory too. The deprecated sniffer may name a directory
            # outside the working directory on purpose; only that one is exempt.
            if confine_target or current != directory or current.is_relative_to(working_dir):
                if real_working_dir is None:
                    real_working_dir = Path(await ctx.workspace.realpath(str(working_dir)))
                verdict = await self._resolved_verdict(ctx.workspace, current, real_working_dir)
                if verdict == 'stop':
                    break
                if verdict == 'skip':
                    continue
            # Only the target directory can hold the file just written, so the others skip `_same_file`'s `realpath`s.
            await self._enqueue_directory(
                ctx, current, in_history, written_file=written_file if current == directory else None
            )

    def _chain_until_excluded(self, directory: Path, working_dir: Path) -> list[Path]:
        """The directories from the working directory down to `directory`, up to the first `nested_exclude` match.

        The chain runs shallowest first, so once one directory is excluded, every deeper one is too.
        """
        chain = directories_up_to(directory, working_dir)
        for index, current in enumerate(chain):
            if self._nested_excluded(current, working_dir):
                return chain[:index]
        return chain

    async def _resolved_verdict(
        self, workspace: Workspace, directory: Path, real_working_dir: Path
    ) -> Literal['surface', 'skip', 'stop']:
        """Whether `directory`, after symlinks, is surfaced, skipped as outside the working directory, or excluded.

        Exclusion stops the chain, since every deeper directory is beneath the excluded one.
        """
        real = Path(await workspace.realpath(str(directory)))
        if not real.is_relative_to(real_working_dir):
            return 'skip'
        # A symlink such as `libs/dep -> node_modules/dep` reaches an excluded directory under another name.
        return 'stop' if self._nested_excluded(real, real_working_dir) else 'surface'

    def _nested_excluded(self, directory: Path, working_dir: Path) -> bool:
        try:
            parts = directory.relative_to(working_dir).parts
        except ValueError:
            return False
        return any(fnmatchcase(part, pattern) for part in parts for pattern in self.nested_exclude)

    async def _enqueue_directory(
        self, ctx: RunContext[AgentDepsT], directory: Path, in_history: set[str], *, written_file: Path | None = None
    ) -> None:
        key = str(directory)
        context_file = await find_dir_context_file(ctx.workspace, directory, self.filenames)
        # `_enqueue_context` skipped it if it was already surfaced, but parallel traversals can probe the same
        # directory concurrently, so check again after the await.
        if context_file is None or self._surfaced(key, in_history):
            return
        self._pending_dirs.add(key)
        # The model just wrote the instruction file itself, so a note would repeat what it wrote. The directory stays
        # pending for the rest of this run, or until a compaction summarizes the write away; a later run, which keeps
        # no pending state and finds no stamped note, may surface it once more.
        if written_file is not None and await self._same_file(ctx.workspace, written_file, context_file.path):
            return
        content = context_file_part_content(context_file)
        used = self._window_chars + sum(self._pending_chars.values())
        inline = self.nested_inject == 'contents' and (
            self.nested_max_chars is None or used + len(content) <= self.nested_max_chars
        )
        if inline:
            self._pending_chars[key] = len(content)
        ctx.enqueue(await self._note(ctx.workspace, context_file, key, content=content if inline else None))

    def _surfaced(self, key: str, in_history: set[str]) -> bool:
        return key in self._loaded_dirs or key in self._pending_dirs or key in in_history

    def _sync_surfaced_dirs(self, messages: Sequence[ModelMessage]) -> set[str]:
        """Update the pending notes against history, and return the directories whose note is in the window.

        Call it once per traversal, before any `_surfaced` check.

        A note survives in history until compaction summarizes it away, so this is derived from the window
        rather than remembered, and it covers notes from earlier runs of the conversation. The same goes for the
        characters inlined notes hold, which `nested_max_chars` bounds. Notes enqueued but not yet in history are
        tracked until they appear there, or until a new compaction replaces the history they would have been in.
        """
        latest = _latest_compaction(messages)
        if latest is not self._latest_compaction:
            self._latest_compaction = latest
            self._pending_dirs.clear()
        notes = _notes_in_window(messages)
        in_history = {directory for directory, _ in notes}
        self._window_chars = sum(chars for _, chars in notes)
        self._pending_dirs -= in_history
        self._pending_chars = {key: chars for key, chars in self._pending_chars.items() if key in self._pending_dirs}
        return in_history

    async def _same_file(self, workspace: Workspace, written_file: Path, context_file: Path) -> bool:
        if written_file.name not in self.filenames:
            return False
        return await workspace.realpath(str(written_file)) == await workspace.realpath(str(context_file))

    async def _resolve_directory(self, workspace: Workspace, raw_path: str) -> Path:
        working_dir = await self._working_dir(workspace)
        text = await workspace.resolve(raw_path, base=working_dir.as_posix())
        candidate = Path(text)
        try:
            entry = await workspace.stat(text)
        except (FileNotFoundError, NotADirectoryError):
            return candidate
        return candidate.parent if not entry.is_dir else candidate

    async def _note(
        self, workspace: Workspace, context_file: ContextFile, directory: str, *, content: str | None
    ) -> ContextFilePart | ContextFilePathPart:
        """The file's `content` inlined, or a pointer to it when there's none, as repository data read from `workspace`.

        The contents and the path are the repository's, not the operator's or the framework's, so they are data on
        the user channel. Only the pointer's note, Pydantic AI's rendering of the part's class, speaks in the
        application's voice, followed by who wrote the file when the operator doesn't control the workspace.
        """
        assert self._cached_working_dir is not None, 'a note is only rendered once the directory is resolved'
        label = context_file_label(context_file.path, self._cached_working_dir)
        source = await WorkspaceSource.from_workspace(workspace, context_file.path.as_posix())
        if content is not None:
            return ContextFilePart(content=content, source=source, path=label, directory=directory)
        return ContextFilePathPart(content=label, source=source, directory=directory)

    async def _autoload_symlink_roots(self, workspace: Workspace) -> list[Path]:
        if not self.autoload_symlink_roots:
            return []
        if not isinstance(innermost_backend(workspace), (SupportsRealpath, SupportsCommands)):
            raise UserError(
                '`RepoContext.autoload_symlink_roots` requires a workspace backend implementing '
                '`SupportsRealpath` or `SupportsCommands` to resolve symlinks safely.'
            )
        return [Path(await workspace.realpath(workspace_path(Path(root)))) for root in self.autoload_symlink_roots]

    async def _working_dir(self, workspace: Workspace) -> Path:
        if self._cached_working_dir is None:
            self._cached_working_dir = Path(await workspace.working_dir())
        return self._cached_working_dir

    @classmethod
    def get_serialization_name(cls) -> str | None:
        """Serialization name for agent-spec support."""
        return 'RepoContext'


def _latest_compaction(messages: Sequence[ModelMessage]) -> CompactionPart | None:
    for message in reversed(messages):
        for part in reversed(message.parts):
            if isinstance(part, CompactionPart):
                return part
    return None


def _notes_in_window(messages: Sequence[ModelMessage]) -> list[tuple[str, int]]:
    """The directory and inlined characters of each nested note in the post-compaction window."""
    return [
        note
        for message in post_compaction_window(messages)
        if isinstance(message, ModelRequest)
        for part in message.parts
        for note in _notes(part)
    ]


def _notes(part: ModelRequestPart) -> Iterator[tuple[str, int]]:
    """The directory each nested note in `part` surfaced, with the characters it inlined, if `part` holds one.

    A note is a `ContextFilePart`, which inlines its content, or a `ContextFilePathPart`, or, in a history an earlier
    version saved, user-channel text carrying the nested-note `origin` metadata, counted as inlining nothing.
    """
    if isinstance(part, ContextFilePart):
        yield part.directory, len(part.content)
    elif isinstance(part, ContextFilePathPart):
        yield part.directory, 0
    elif isinstance(part, UserPromptPart) and not isinstance(part.content, str):
        for item in part.content:
            if isinstance(item, TextContent) and (directory := _legacy_note_directory(item.metadata)) is not None:
                yield directory, 0


def _legacy_note_directory(metadata: object) -> str | None:
    if not is_str_dict(metadata) or metadata.get('origin') != _NESTED_NOTE_ORIGIN:
        return None
    directory = metadata.get('directory')
    return directory if isinstance(directory, str) else None
