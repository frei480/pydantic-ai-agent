# System Reminders

> [!NOTE]
> The `Reminder` helper is not re-exported at the top level -- import it from the submodule:
>
> ```python
> from pydantic_ai_harness import SystemReminders
> from pydantic_ai_harness.system_reminders import Reminder
> ```
>
> While Pydantic AI Harness is on 0.x releases, the API may change between minor releases; when it does, deprecation warnings and release-note migration guidance tell you (or your agent) exactly how to upgrade. See the [version policy](https://pydantic.dev/docs/ai/harness/#version-policy).

Re-inject behavioral guidance mid-run to counter instruction fade -- without moving the cached prompt prefix.

[Source](https://github.com/pydantic/pydantic-ai/tree/main/src/pydantic_ai_harness/pydantic_ai_harness/system_reminders/)

```mermaid
flowchart TB
    accTitle: System Reminders: restate guidance late in a long run
    accDescr: The agent loop fills each model request with a cached prefix of tools, instructions and conversation. Before each request, the SystemReminders capability runs in before_model_request, and a Reminder(interval=3) adds a reminder on requests 3 and 6. The reminder sits at the tail of the request, after the cache breakpoint, for that request only, and the request goes to the model.
    loop["agent loop"]
    cap["SystemReminders()<br/>before_model_request"]:::capability
    subgraph request["Model request"]
        prefix["cached prefix<br/>tools, instructions,<br/>conversation"]
        tail["reminder at the tail,<br/>after cache breakpoint,<br/>this request only"]:::capability
    end
    model(["model"])
    loop --> prefix
    loop -->|"before each request"| cap
    cap -.->|"Reminder(interval=3):<br/>on requests 3 and 6"| tail
    request --> model
    classDef capability stroke:#E520E9,stroke-width:2px
```

## The problem

Long multi-turn runs suffer instruction fade: after many tool-use turns the model progressively ignores the guidance it was given at the start. A single start-of-session system prompt is not enough for extended work. The fix is to re-state targeted guidance mid-run -- on a fixed cadence, or reactively when a condition is detected.

## The solution

`SystemReminders` injects reminders on each model request, either statically (`Reminder`, on a cadence) or dynamically (a callable that reads the run context). Each firing enqueues a `ReminderPart`, a [capability part](https://pydantic.dev/docs/ai/capabilities/custom/#capability-parts) in the application's voice, which the model sees as a [request-scoped system prompt](https://pydantic.dev/docs/ai/core-concepts/message-history/#request-scoped-system-prompts) at the **tail** of the request. The model sees a request-scoped prompt only in the model request it's part of: the next request, even the next step of the same run, no longer shows it. It's recorded in the message history like any other part. A static `Reminder` can be a [lasting reminder](#lasting-reminders) instead, kept in front of the model for the rest of the conversation.

- On Anthropic models that take mid-conversation system messages, it's sent as a turn-scoped system message (`clear_at`): every copy stays on the wire, the API stops rendering each one once the next request arrives, and a cleared one costs no tokens. Leaving earlier reminders in place is what keeps the cached prefix and the model's earlier reasoning valid; deleting one would invalidate every thinking block after it on models with preserved thinking.
- Everywhere else, it's sent with its own request only, at the end, rendered like any other [mid-conversation system prompt](https://pydantic.dev/docs/ai/core-concepts/message-history/#mid-conversation-system-prompts), and left out of later ones.
- The cache breakpoints your model's caching settings place (such as `anthropic_cache`) go *before* the reminder, so the cached prefix (tools + system + real conversation) is reused turn over turn and only the small reminder falls outside it.

Injecting into the system prompt or instructions instead would sit at the front of the request, so every reminder would bust the cached prefix. This capability avoids that.

```python
from pydantic_ai import Agent
from pydantic_ai_harness import SystemReminders
from pydantic_ai_harness.system_reminders import Reminder

agent = Agent(
    'anthropic:claude-sonnet-4-6',
    capabilities=[
        SystemReminders(
            reminders=[Reminder('Stay focused on the original request.', interval=5, tag=None)],
        )
    ],
)

result = agent.run_sync('Refactor the auth module and add tests.')
print(result.output)
```

## Static reminders

A `Reminder` fires on a cadence within a run:

| Field | Purpose |
|---|---|
| `content` | The reminder text. |
| `interval` | Fire every N model requests (`interval=3` fires on the 3rd, 6th, ...). |
| `first_after` | Request number of the first fire, then every `interval` after. `None` = first multiple of `interval` (plain modulo). |
| `trigger` | Predicate over `RunContext`. When set, fires only when it returns `True` *and* the cadence matches. |
| `max_fires` | Cap the number of fires per run. `None` = no limit. |
| `tag` | Also wrap the content in `<tag>\ncontent\n</tag>`. `None` sends the raw content. Left unset, it's `None` and warns that the default changed. |
| `scope` | `'request'` (the default) shows each firing for its own request only; `'conversation'` keeps it in front of the model for the rest of the conversation. See [Lasting reminders](#lasting-reminders). |
| `skip_unchanged` | Skip a firing while a copy of the same text is still in the history the model sees. Requires `scope='conversation'`. See [Lasting reminders](#lasting-reminders). |

A request-scoped reminder, the default, adds recency; it doesn't keep a rule in force. The model sees each firing only in the request it fires on, so with `interval>1` it sees the reminder on the requests where it fires and not on the ones in between, and a `trigger` or `max_fires` narrows that further. Text the model must follow at every step belongs in the agent's [instructions](https://pydantic.dev/docs/ai/core-concepts/agent/#instructions), which every request sends. Guidance it must still act on several steps after a firing can be a [lasting reminder](#lasting-reminders).

A reminder is a system prompt, so the model is already shown it as one: as a native system message where the model supports it, and in a `<system>` tag otherwise. It needs no tag of its own, so pass `tag=None`. The default used to be `'system-reminder'`: a `Reminder` that leaves `tag` unset sends the raw content and warns, and `tag='system-reminder'` restores the old wrapping.

The `tag` wrapping applies only to static `Reminder` content. A `str` a dynamic callable returns (including `GoalReanchor`'s) is sent as written, and one that looks like a framework frame, such as a `<system` tag, raises `UserError` and fails the run; an `LLMReminder`'s `GeneratedReminder` is quoted as data, as described under [Dynamic reminders](#dynamic-reminders).

### Lasting reminders

By default a reminder is request-scoped: the model sees it on the request it fires on, and not after. That's what a nudge about the next step needs, and the history doesn't fill up with copies the model keeps re-reading. Some guidance has to outlast that step, such as an obligation the model meets several tool calls later. Set `scope='conversation'` (named as in [`CapabilityPart.scope`](https://pydantic.dev/docs/ai/api/pydantic-ai/messages/#pydantic_ai.messages.CapabilityPart.scope)) to record each firing as a lasting system prompt instead:

```python
from pydantic_ai_harness import SystemReminders
from pydantic_ai_harness.system_reminders import Reminder

SystemReminders(
    reminders=[
        Reminder(
            'Run the tests and report any failures before you finish.',
            interval=10,
            tag=None,
            scope='conversation',
        )
    ],
)
```

Each firing adds a `ReminderPart` to the message history for good, and every later request sends all of them again. So the history grows by one part per firing: with `interval=N`, a run of R requests gains `R // N` copies, and with the default `interval=1`, one on every request. The copies are appended and never moved, so the cached prefix holds, and with caching turned on for your model each earlier copy is read from cache. Use `interval` and `max_fires` to bound the growth: `max_fires=1` records the reminder once per run.

To keep one copy instead of one per firing, set `skip_unchanged=True`. A firing is skipped while a lasting copy of the same text is still in the history the model sees, from the latest native compaction boundary on, so chained runs that pass the history along don't add a copy each. Once compaction drops the copy, or the text changes, the next firing records it again. The check reads the history as `SystemReminders` sees it, so list a `ProcessHistory` or compaction capability that drops messages before `SystemReminders`.

Choose the scope by what the text has to do:

- Text that holds on every step and never changes belongs in the agent's [instructions](https://pydantic.dev/docs/ai/core-concepts/agent/#instructions), not in a reminder: it's sent once per request at the start, cached, and never adds to the history.
- Text that matters for the next step only, or carries a value that changes (a count, a time, a budget), stays request-scoped, so stale copies don't pile up in the history.
- Text that must still apply several steps after it fires is a lasting reminder.

A lasting reminder is operator text, sent in system voice like any other reminder. It's a `ReminderPart` in the application's voice, so `SummarizingCompaction` summarizes it as a system message, never as something the user said, and `keep_user_messages` never keeps it. Recognized by its type, it's never taken for a summary an earlier release stored as a system prompt. Copies that compaction summarized away are recorded again on the reminder's next firing.

## Dynamic reminders

A dynamic reminder is any callable `(RunContext) -> str | None` (sync or async), evaluated on every model request. Return a string to inject, or `None` to skip. This is the general seam for conditions that need run state -- token budget, post-compaction, mode switches -- without hardcoded detectors:

```python
from pydantic_ai_harness import SystemReminders

SystemReminders(
    dynamic_reminders=[
        lambda ctx: 'Wrap up soon.' if ctx.run_step > 20 else None,
    ],
)
```

Every reminder is sent as a system prompt, so the model reads it with the authority of your instructions. Static `Reminder` content and a `str` a dynamic callable returns are operator text, sent in system voice as written: return only text you wrote yourself. Static `Reminder` content that looks like a framework frame, such as a `<system>` tag, raises `UserError` when the `Reminder` is created. The built-in dynamic reminders never put text they didn't write in system voice.

`GoalReanchor` doesn't quote the user at all: it points the model back at the user's first request, which is already in the conversation. `LLMReminder` returns a `GeneratedReminder`, a distinct type rather than a `str`, so string operations can't turn the generated text into operator text; a wrapper that passes it through keeps it as data.

`SystemReminders` sends a `GeneratedReminder` as a `GeneratedReminderPart`: the generated text on the user channel in a `<generated_reminder model="...">` tag, behind a fixed note in the application's voice that ranks the reminder below your instructions and the user's request and says the reminder model wrote it, not the user or the application. The note and the text are one record in the message history, kept and sent together on every later request and seen together by compaction and summaries, so in history kept on the server the generated text doesn't reach the model without the note that says what it is. History that round-trips through a UI client is the one exception: see [UI history](#ui-history). The reminders find their own records in history by that type.

The generated text goes out as the model wrote it: text in it that looks like the `<generated_reminder>` tag or a framework frame such as `<system>` gets a further note naming the reminder model as its author, so it can't end its tag, open another or speak as the system. `LLMReminder` also quotes the transcript it sends the reminder model, in `<summary>`, `<goal>` and `<message role="...">` elements, starting at the latest native compaction boundary.

### `GoalReanchor` -- zero-cost goal anchoring

`GoalReanchor` points the model back at the run's first user request and asks it to check its next action advances it. After native compaction it points at the request as the compaction summary records it, when the request itself is no longer in what the model sees. No model call, no dependencies:

```python
from pydantic_ai_harness import SystemReminders
from pydantic_ai_harness.system_reminders import GoalReanchor

SystemReminders(dynamic_reminders=[GoalReanchor()])
```

### `LLMReminder` -- model-generated nudges

`LLMReminder` has a model summarize a compact transcript (original goal + recent activity) into a short stay-on-task nudge. It requires an explicit `model` -- there is no default model id -- and falls back to `GoalReanchor` text on any error, so a failed generation never blocks the run:

```python
from pydantic_ai_harness import SystemReminders
from pydantic_ai_harness.system_reminders import LLMReminder

SystemReminders(dynamic_reminders=[LLMReminder(model='anthropic:claude-haiku-4-5', interval=10)])
```

`LLMReminder` generates every `interval` model requests: the 10th, 20th, 30th, ... by default, the cadence `TrajectoryJudge` reviews a run on. Each firing issues one extra model call (its usage is threaded onto the parent run via `ctx.usage`, so it shows up in `result.usage`, and the generation run is filed under the parent's `conversation_id`), and adds one `GeneratedReminderPart`, the generated text with its note, to the message history for good, sent again on every later request. So `interval` bounds both: a run of R requests makes `R // interval` extra calls and gains `R // interval` parts. A run shorter than `interval` requests gets no generated reminder, which is the point of the default: instruction fade sets in over long runs. Set `interval` lower for a tighter cadence, and add `GoalReanchor` alongside it for a free check on every request in between:

```python
from pydantic_ai_harness import SystemReminders
from pydantic_ai_harness.system_reminders import GoalReanchor, LLMReminder

SystemReminders(dynamic_reminders=[GoalReanchor(), LLMReminder(model='anthropic:claude-haiku-4-5', interval=5)])
```

`LLMReminder` defaults to `interval=10`. Earlier releases generated on every model request, so an agent with an `LLMReminder` and no cadence of its own grew its history on every step. Leaving `interval` unset warns that the default changed: pass `interval=10` to keep the new cadence without the warning, or `interval=1` to generate on every request as before. A wrapper that gates `LLMReminder` itself should pass `interval=1`, so the wrapper alone decides.

The nested call runs under the parent's `usage_limits` with one request held back for the model request it precedes, so the reminder cannot push a run past its `request_limit`; once the budget is that tight the generation is skipped and `GoalReanchor` text is used instead. Every other generation failure is logged at warning level with its traceback under the `pydantic_ai_harness.system_reminders` logger namespace, once per run, so a misconfigured `model` (bad id, missing key) shows up in the logs once per run rather than on every model request, while the run carries on with the fallback text.

Under a durability engine, a `LLMReminder` listed directly in `dynamic_reminders` is a journaled
capability operation: replay restores the recorded reminder instead of repeating the model call,
and a generation error is recorded as the `GoalReanchor` fallback rather than inheriting the
engine's retry policy, so a best-effort reminder cannot stall the run. `SystemReminders` carries the
stable default `id='system_reminders'`, so durable recovery works without configuration.

Only a direct entry takes that route. Two shapes do not:

- A wrapper of your own that calls `LLMReminder` (to gate it on a condition, say) calls it from
  orchestration context, where engines that forbid I/O can fail the call outright. Called that way,
  it still applies its `interval`, counted in run steps (`ctx.run_step`).
- An `LLMReminder` subclass that overrides `__call__` runs that override directly, so it cannot be
  journaled either.

Without a durability engine, generation runs directly in all three cases, with the same fallback to
`GoalReanchor` on error.

### `LLMReminder` or `TrajectoryJudge`

[Trajectory Judge](../trajectory_judge/) also has a second model read the run and adds its text to the conversation, framed the same way: a fixed note in system voice and the generated text as data on the user channel. They differ in what that model is asked and when its text is added:

- `LLMReminder` restates the goal on every firing, whether or not the run has drifted. It's generated before the request it goes out with, so each firing adds that model call's latency, and it reads a compact transcript of the goal and recent messages. On error it sends `GoalReanchor` text instead.
- `TrajectoryJudge` asks whether the run is on track and adds nothing to the history when it is. Outside durable execution it runs alongside the agent, so it adds no latency, and it reads the opening request and the most recent activity within `window` tokens, tool calls and results included. An evaluation error is raised on the run, so give it an `agent` with a fallback model if it should degrade instead.

Use `LLMReminder` for a regular, model-written refresher of the goal, and `TrajectoryJudge` to correct a run only when it goes off course. For plain goal re-anchoring with no model call, use `GoalReanchor`.

## Observing reminders

Subscribe to `ReminderFiredEvent` to observe reminders after they are appended. Its `text` is what the model is sent: for an `LLMReminder`'s `GeneratedReminder`, the note and the framed text:

```python
from pydantic_ai import Agent
from pydantic_ai_harness import SystemReminders
from pydantic_ai_harness.system_reminders import Reminder, ReminderFiredEvent

agent = Agent(
    'anthropic:claude-sonnet-4-6',
    capabilities=[SystemReminders(reminders=[Reminder('...', interval=5, tag=None)])],
)

@agent.on_event(ReminderFiredEvent)
async def record(ctx, event):
    print(event.text)
```

Migration: `on_fire` remains supported but is deprecated. Move its callback body to this
subscription.

Per-run state (the request counter and per-reminder fire counts) is isolated via `for_run`, so concurrent runs on the same agent never share fire state.

## Caching

Reminders never go into the leading system prompt or instructions, and the history only ever grows by appending, so it stays eligible for a cache hit. Plain reminders, `GoalReanchor` included, are request-scoped system prompts at the tail of the request, and the only added cost is reading each one once. A `Reminder(scope='conversation')` firing stays in the history and is sent again on every later request, so each copy is read from cache when the prefix before it is cached. The records an `LLMReminder` adds to the history, which every later request sends again, are read from cache when the prefix before them is cached, and paid for in full when it isn't, so keep `LLMReminder`'s `interval` as long as the run allows and turn on caching for your model.

`SystemReminders` doesn't place a cache breakpoint of its own. Turn on caching for your model (for example `anthropic_cache` or `anthropic_cache_messages`, `bedrock_cache_messages`, or `openrouter_cache_messages`), and the breakpoint it places lands before the reminder.

If you relied on `SystemReminders` for prompt caching, turn it on for your model. Earlier releases placed a cache breakpoint ahead of every reminder, with a `'5m'` TTL by default, so an agent got caching on Anthropic without configuring any. That breakpoint is gone, and leaving `cache_ttl` unset doesn't warn about it: an agent with no caching configured on its model now pays full price for its prefix on every request. `cache_ttl` is deprecated and has no effect; set to `'5m'` or `'1h'`, it warns that it's ignored, so remove it.

## Composition

- **`Planning`** shows the plan in its plan tools' results, with a note on it in its instructions, and records it in the history only when it isn't visible any more. Both compose in one agent, and neither places a cache breakpoint.
- **Loop detection** (detect-and-interrupt with a nudge that stays in history) is [Detect Loops](../detect_loops/). `SystemReminders` is cadence/condition steering, request-scoped by default or [lasting](#lasting-reminders).

The reminder is only added when the last message in the request is a `ModelRequest` and at least one reminder fires, so a turn where nothing fires adds nothing to the request. Provider-resume turns (where the request tail is a suspended `ModelResponse` that is echoed back verbatim) are skipped and do not consume a cadence slot.

## UI history

With a [UI adapter](https://pydantic.dev/docs/ai/integrations/ui/overview/#trust-model-for-client-submitted-messages) in its default `manage_system_prompt='server'` mode, history that goes through the client doesn't keep an `LLMReminder` record: the dump leaves out capability parts, `GeneratedReminderPart` included, so history the client sends back doesn't have them. Plain reminders, `GoalReanchor` included, are request-scoped and left out of the dump altogether, so they're unaffected. A `Reminder(scope='conversation')` is a lasting system prompt, which the dump leaves out in `'server'` mode like any other system prompt: history the client sends back doesn't have its copies, so keep the history on the server for lasting reminders too.

If you use `LLMReminder` with a UI adapter, keep the [message history on the server](https://pydantic.dev/docs/ai/core-concepts/message-history/) and don't rely on the client's copy. A carrier that lets capability parts go through a client is planned in [#11029](https://github.com/pydantic/pydantic-ai/issues/11029), and a server-held history mode for UI adapters is proposed in [#11031](https://github.com/pydantic/pydantic-ai/issues/11031).

## Not spec-serializable

`SystemReminders.get_serialization_name()` returns `None`: reminders take arbitrary callables, which cannot be serialized to an agent spec.

## Further reading

- [Pydantic AI capabilities](https://ai.pydantic.dev/capabilities/)
- [Request-scoped system prompts](https://pydantic.dev/docs/ai/core-concepts/message-history/#request-scoped-system-prompts) -- the core primitive the reminders are built on
- [Anthropic prompt caching](https://docs.claude.com/en/docs/build-with-claude/prompt-caching)
