"""Compaction capabilities: keep an agent's conversation history within the context window.

Each capability lives in its own module; shared utilities (token estimation, the
`CompactionStrategy` protocol, tool-pair-safe cutoffs, in-place clearing) live in `_shared`.
"""

from pydantic_ai_harness._warn import warn_class_renamed
from pydantic_ai_harness.compaction._clamp_oversized_messages import ClampOversizedMessages
from pydantic_ai_harness.compaction._clear_tool_results import ClearToolResults
from pydantic_ai_harness.compaction._compact_on_request import CompactOnRequest
from pydantic_ai_harness.compaction._context_window import (
    DEFAULT_CONTEXT_WINDOW,
    resolve_context_window,
)
from pydantic_ai_harness.compaction._deduplicate_file_reads import DeduplicateFileReads
from pydantic_ai_harness.compaction._events import REPORT_CONTEXT_USAGE_EVENTS, ContextUsageMeasuredEvent
from pydantic_ai_harness.compaction._fallback_compaction import FallbackCompaction
from pydantic_ai_harness.compaction._manual import compact_now
from pydantic_ai_harness.compaction._pinning import PinSource, is_pinned, pin, reinject_pinned
from pydantic_ai_harness.compaction._prune_tool_results import PruneToolResults
from pydantic_ai_harness.compaction._receipts import TranscriptHandleProvider
from pydantic_ai_harness.compaction._relevance_compaction import RelevanceCompaction
from pydantic_ai_harness.compaction._report_context_usage import ContextUsage, ReportContextUsage
from pydantic_ai_harness.compaction._shared import (
    CompactionStrategy,
    SupportsFocus,
    estimate_context_tokens,
    estimate_message_tokens,
    estimate_token_count,
)
from pydantic_ai_harness.compaction._sliding_window_compaction import SlidingWindowCompaction
from pydantic_ai_harness.compaction._summarizing_compaction import SummarizingCompaction, drain_summary_events
from pydantic_ai_harness.compaction._tiered_compaction import TieredCompaction
from pydantic_ai_harness.compaction._warn_near_limits import LimitWarningPart, WarningKind, WarnNearLimits

__all__ = [
    'DEFAULT_CONTEXT_WINDOW',
    'ClampOversizedMessages',
    'ClearToolResults',
    'CompactOnRequest',
    'CompactionStrategy',
    'ContextUsage',
    'ContextUsageMeasuredEvent',
    'REPORT_CONTEXT_USAGE_EVENTS',
    'RelevanceCompaction',
    'ReportContextUsage',
    'DeduplicateFileReads',
    'FallbackCompaction',
    'LimitWarningPart',
    'PinSource',
    'PruneToolResults',
    'SlidingWindowCompaction',
    'SummarizingCompaction',
    'SupportsFocus',
    'TieredCompaction',
    'TranscriptHandleProvider',
    'WarnNearLimits',
    'WarningKind',
    'compact_now',
    'drain_summary_events',
    'estimate_context_tokens',
    'estimate_message_tokens',
    'estimate_token_count',
    'is_pinned',
    'pin',
    'reinject_pinned',
    'resolve_context_window',
]

_RENAMED = {
    'ContextUsageEvent': ContextUsageMeasuredEvent,
    'LimitWarner': WarnNearLimits,
    'SlidingWindow': SlidingWindowCompaction,
}


def __getattr__(name: str) -> object:
    renamed = _RENAMED.get(name)
    if renamed is not None:
        warn_class_renamed(name, renamed.__name__, 'pydantic_ai_harness.compaction')
        return renamed
    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')
