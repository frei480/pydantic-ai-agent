"""Pin contract: mark message content that every shipped compaction strategy must preserve.

A *pin* is a lightweight, harness-side convention: content marked with model-invisible
`TextContent.metadata` that compaction treats as load-bearing -- it is never summarized away or
dropped, and if a strategy would have discarded it, the strategy re-injects it verbatim.
Planning's plan does not need pinning because it is re-injected ephemerally every request in
`wrap_model_request`; the motivating consumers here are durable task state and a scratchpad the
model wants guaranteed to ride along.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Literal

from pydantic_ai.framing import register_tag, wrap
from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    SystemPromptPart,
    TextContent,
    UserPromptPart,
)
from pydantic_ai_harness._provenance import harness_origin
from pydantic_ai_harness.compaction._summary import is_summary_part

_PIN_METADATA = 'pydantic-ai-harness.compaction.pin.v1'
"""Model-invisible metadata identifying a pinned item: the whole metadata of a user pin, the `origin` of any other."""

_PINNED_TAG = register_tag('pinned')

PinSource = Literal['user', 'tool', 'model']
"""Who wrote pinned content: the user, a tool, or the model."""


def pin(content: str, *, source: PinSource = 'user') -> UserPromptPart:
    """Mark *content* so every shipped compaction strategy preserves it.

    The returned `UserPromptPart` can be placed in a `ModelRequest` in the run's message
    history (e.g. by a capability or by the user); compaction keeps it verbatim. A `'user'` pin
    reaches the model as the user's own words. Any other *source* is framed as
    `<pinned source="...">` data, so the model doesn't read a tool's or its own text as the user's.
    """
    if source == 'user':
        return UserPromptPart(content=[TextContent(content, metadata=_PIN_METADATA)])
    text = wrap(_PINNED_TAG, content, source=source)
    metadata = {'origin': _PIN_METADATA, 'source': source}
    return UserPromptPart(content=[TextContent(text, metadata=metadata)])


def is_pinned(part: object) -> bool:
    """Return True if *part* carries the pin metadata marker."""
    return (
        isinstance(part, UserPromptPart)
        and not isinstance(part.content, str)
        and any(
            isinstance(item, TextContent)
            and (item.metadata == _PIN_METADATA or harness_origin(item.metadata) == _PIN_METADATA)
            for item in part.content
        )
    )


def collect_pinned(messages: Sequence[ModelMessage]) -> list[ModelRequestPart]:
    """Return every pinned part found across *messages*, in order."""
    out: list[ModelRequestPart] = []
    for message in messages:
        if isinstance(message, ModelRequest):
            out.extend(part for part in message.parts if is_pinned(part))
    return out


def _leading_context_len(messages: Sequence[ModelMessage]) -> int:
    """Count the leading run of requests made up only of system prompts and summaries."""
    count = 0
    for message in messages:
        if (
            isinstance(message, ModelRequest)
            and message.parts
            and all(isinstance(p, SystemPromptPart) or is_summary_part(p) for p in message.parts)
        ):
            count += 1
        else:
            break
    return count


def reinject_pinned(
    original: Sequence[ModelMessage],
    compacted: list[ModelMessage],
    *,
    protected_tail: int = 0,
    insert_at: int | None = None,
) -> list[ModelMessage]:
    """Re-inject any pinned parts from *original* that *compacted* dropped.

    Pinned parts already present in *compacted* are left where they are; missing ones are
    gathered into a single `ModelRequest` placed right after any leading system/summary
    messages, so they sit near the top of the surviving history. A no-op when *original* has
    no pins or all pins survived, so it is always safe to call. `protected_tail` bounds
    insertion to the prefix before that many unchanged trailing messages. `insert_at` places the
    recovered pins at that index instead, for a strategy whose leading messages must stay as they were.
    """
    pinned = collect_pinned(original)
    if not pinned:
        return compacted
    surviving = collect_pinned(compacted)
    missing: list[ModelRequestPart] = []
    for part in pinned:
        for index, survivor in enumerate(surviving):
            if part == survivor:
                del surviving[index]
                break
        else:
            missing.append(part)
    if not missing:
        return compacted
    leading = _leading_context_len(compacted) if insert_at is None else insert_at
    index = min(leading, len(compacted) - protected_tail)
    pin_message = ModelRequest(parts=list(missing))
    return [*compacted[:index], pin_message, *compacted[index:]]
