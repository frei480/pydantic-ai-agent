"""`SlidingWindowCompaction` -- zero-cost trimming of the oldest messages."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING

from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.messages import ModelMessage, ModelRequest
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai_harness.compaction._capability_loads import deferred_capability_ids, keep_loaded_state
from pydantic_ai_harness.compaction._context_window import DEFAULT_CONTEXT_WINDOW
from pydantic_ai_harness.compaction._pinning import reinject_pinned
from pydantic_ai_harness.compaction._receipts import (
    ReceiptInfo,
    discover_transcript_handle,
    format_receipt,
    is_receipt_part,
    make_receipt_part,
    record_receipt,
)
from pydantic_ai_harness.compaction._shared import (
    compact_with_span,
    context_for_request,
    estimate_token_count,
    exceeds,
    find_safe_cutoff,
    find_token_cutoff,
    prepend_first_user_message,
    record_compaction_reclaim,
    require_trigger,
    resolve_token_trigger,
    validate_token_trigger,
)

if TYPE_CHECKING:
    from pydantic_ai.models import ModelRequestContext


@dataclass
class SlidingWindowCompaction(AbstractCapability[AgentDepsT]):
    """Zero-cost sliding-window trimmer.

    When the conversation exceeds a configurable threshold (message count or
    estimated token count), the oldest messages are discarded while preserving
    tool-call / tool-return pairs.  No LLM calls are made.

    Trimming happens in `before_model_request` so it is transparent to the
    rest of the agent run.

    Example:
        ```python
        from pydantic_ai import Agent
        from pydantic_ai_harness.compaction import SlidingWindowCompaction

        agent = Agent(
            'openai:gpt-4o',
            capabilities=[SlidingWindowCompaction(max_messages=80, keep_messages=40)],
        )
        ```
    """

    max_messages: int | None = None
    """Trigger trimming when message count exceeds this value. `None` disables."""

    max_tokens: int | None = None
    """Trigger trimming when estimated token count exceeds this value. `None` disables."""

    max_fraction: float | None = field(default=None, kw_only=True)
    """Trigger when estimated tokens exceed this fraction of the model's context window.

    Resolved per request from the request's model, so one setting behaves correctly on any
    model. Mutually exclusive with `max_tokens`."""

    context_window: int | None = field(default=None, kw_only=True)
    """Window override in tokens. `None` resolves it from the request's model.

    Unlike `fallback_context_window`, this applies whether or not resolution succeeds. Reach
    for it when the registry is confidently wrong: a beta- or tier-gated window it records as
    the maximum, or a self-hosted endpoint whose model id describes someone else's
    deployment. Only consulted alongside `max_fraction`."""

    fallback_context_window: int = field(default=DEFAULT_CONTEXT_WINDOW, kw_only=True)
    """Window assumed when the request's model is not in the pricing registry.

    Only consulted alongside `max_fraction`. Supply the real number for a deployment the
    registry cannot resolve."""

    keep_messages: int = 40
    """Number of tail messages to retain after trimming (message-count trigger).

    The newest message is always kept, so `0` keeps one. With `receipts=True`, the receipt
    counts as one of these, but never displaces the newest message.
    """

    keep_tokens: int | None = None
    """Minimum original message-content tokens to retain in an unchanged recent suffix.

    Whole messages and tool dependencies can exceed this floor. Attached instructions do
    not count. When `None`, falls back to `keep_messages`; zero keeps legacy edge behavior.
    """

    tokenizer: Callable[[str], int] | None = None
    """Optional tokenizer for accurate token counting.

    A callable that returns the token count for a given string.
    When `None`, uses the built-in text estimate, which counts dense text such as non-ASCII
    scripts, base64 and compact JSON higher than prose.
    """

    preserve_first_user_message: bool = True
    """When `True`, the first `ModelRequest` containing a `UserPromptPart`
    is always kept after trimming, in addition to system prompts.
    """

    preserve_loaded_capabilities: bool = field(default=True, kw_only=True)
    """When `True`, a deferred capability loaded in the dropped messages stays loaded.

    Core counts a capability as loaded while the record of its load is in the history, so dropping
    the record would unload it. Each such load is recorded again ahead of the kept
    messages instead, and the capability's tools and current instructions are sent again. When
    `False`, those capabilities are unloaded, and a note names them so the model can load the ones
    it still needs.
    """

    receipts: bool = False
    """When `True`, prepend a deterministic compaction receipt recording how much history
    was dropped, with a transcript handle when a `TranscriptHandleProvider` capability is attached.
    """

    def __post_init__(self) -> None:
        if self.max_messages is not None and self.max_messages < 1:
            raise ValueError('max_messages must be positive.')
        validate_token_trigger(self.max_tokens, self.max_fraction, self.fallback_context_window, self.context_window)
        if self.keep_messages < 0:
            raise ValueError('keep_messages must be non-negative.')
        if self.keep_tokens is not None and self.keep_tokens < 0:
            raise ValueError('keep_tokens must be non-negative.')

    async def compact(
        self,
        messages: list[ModelMessage],
        ctx: RunContext[AgentDepsT],
    ) -> list[ModelMessage]:
        """Drop the oldest messages down to the configured tail."""
        if self.keep_tokens is not None:
            cutoff = find_token_cutoff(messages, self.keep_tokens, self.tokenizer)
        else:
            # The receipt takes one of the kept slots, but never the last one: keeping zero
            # messages would drop the newest message, which in a run is the request being answered.
            keep = self.keep_messages - 1 if self.receipts and self.keep_messages > 1 else self.keep_messages
            cutoff = find_safe_cutoff(messages, keep)

        if cutoff <= 0:
            return messages

        trimmed = messages[cutoff:]
        if self.preserve_first_user_message:
            trimmed = prepend_first_user_message(messages, cutoff, trimmed)
        protected_tail = len(messages) - cutoff if self.keep_tokens else 0
        trimmed = reinject_pinned(messages, trimmed, protected_tail=protected_tail)
        if self.receipts:
            trimmed = self._prepend_receipt(messages, trimmed, protected_tail, ctx)
        kept = messages[cutoff:]
        kept_from = next(
            (index for index, message in enumerate(trimmed) if any(message is k for k in kept)), len(trimmed) - 1
        )
        return keep_loaded_state(
            messages,
            trimmed,
            kept_from=kept_from,
            deferred_ids=deferred_capability_ids(ctx),
            preserve=self.preserve_loaded_capabilities,
        )

    def _prepend_receipt(
        self,
        messages: list[ModelMessage],
        trimmed: list[ModelMessage],
        protected_tail: int,
        ctx: RunContext[AgentDepsT],
    ) -> list[ModelMessage]:
        """*trimmed* without earlier receipts outside the protected tail, led by a receipt for what it dropped."""
        if protected_tail:
            trimmed = [*self._without_receipts(trimmed[:-protected_tail]), *trimmed[-protected_tail:]]
        else:
            trimmed = self._without_receipts(trimmed)
        dropped = self._dropped_messages(messages, trimmed)
        return [self._receipt_message(dropped, ctx), *trimmed]

    @staticmethod
    def _without_receipts(messages: list[ModelMessage]) -> list[ModelMessage]:
        """Remove prior receipt-only requests before inserting the current receipt."""
        return [
            message
            for message in messages
            if not (
                isinstance(message, ModelRequest)
                and message.parts
                and all(is_receipt_part(part) for part in message.parts)
            )
        ]

    @staticmethod
    def _dropped_messages(messages: list[ModelMessage], retained: list[ModelMessage]) -> list[ModelMessage]:
        """Return original messages that are absent from the retained history."""
        unmatched = list(retained)
        dropped: list[ModelMessage] = []
        for message in messages:
            for index, survivor in enumerate(unmatched):
                if message is survivor:
                    del unmatched[index]
                    break
            else:
                if not (
                    isinstance(message, ModelRequest)
                    and message.parts
                    and all(is_receipt_part(part) for part in message.parts)
                ):
                    dropped.append(message)
        return dropped

    def _receipt_message(self, dropped: list[ModelMessage], ctx: RunContext[AgentDepsT]) -> ModelRequest:
        """Build (and record for tracing) a receipt for the *dropped* prefix."""
        dropped_tokens = estimate_token_count(dropped, self.tokenizer)
        handle = discover_transcript_handle(ctx)
        record_receipt(
            ReceiptInfo(
                strategy='SlidingWindowCompaction',
                dropped_messages=len(dropped),
                dropped_tokens=dropped_tokens,
                by='the harness',
                handle=handle,
            )
        )
        text = format_receipt(
            dropped_messages=len(dropped),
            dropped_tokens=dropped_tokens,
            by='the harness',
            handle=handle,
            has_summary=False,
        )
        return ModelRequest(parts=[make_receipt_part(text)])

    async def before_run(self, ctx: RunContext[AgentDepsT]) -> None:
        """Reject a registration without a trigger."""
        require_trigger('SlidingWindowCompaction', self.max_messages, self.max_tokens, self.max_fraction)

    async def before_model_request(
        self,
        ctx: RunContext[AgentDepsT],
        request_context: ModelRequestContext,
    ) -> ModelRequestContext:
        """Trim the message list if it exceeds the configured threshold."""
        messages: list[ModelMessage] = list(ctx.messages)
        request_ctx = context_for_request(ctx, request_context)
        token_trigger = resolve_token_trigger(
            self.max_tokens, self.max_fraction, request_ctx.model, self.fallback_context_window, self.context_window
        )
        if not exceeds(
            messages,
            self.max_messages,
            token_trigger,
            self.tokenizer,
            model_request_parameters=request_context.model_request_parameters,
        ):
            return request_context
        compacted = await compact_with_span(
            request_ctx,
            strategy='SlidingWindowCompaction',
            messages=messages,
            compact=lambda: self.compact(messages, request_ctx),
            tokenizer=self.tokenizer,
        )
        ctx.messages[:] = compacted
        record_compaction_reclaim(
            ctx,
            estimate_token_count(messages, self.tokenizer),
            estimate_token_count(compacted, self.tokenizer),
        )
        return replace(request_context, messages=compacted)
