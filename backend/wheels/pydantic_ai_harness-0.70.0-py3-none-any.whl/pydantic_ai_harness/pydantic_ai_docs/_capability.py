"""Docs capability: an on-demand tool that locates Pydantic AI documentation."""

from __future__ import annotations

import os
from collections.abc import Sequence
from dataclasses import KW_ONLY, dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic_ai._utils import replace_no_init
from pydantic_ai.capabilities import AbstractCapability
from pydantic_ai.tools import AgentDepsT, RunContext
from pydantic_ai.toolsets import AgentToolset
from pydantic_ai_harness._combine import one_per_id
from pydantic_ai_harness._workspace import require_workspace
from pydantic_ai_harness.pydantic_ai_docs._toolset import PydanticAIDocsToolset, PydanticAIDocsTopic

if TYPE_CHECKING:
    from pydantic_ai._instructions import AgentInstructions

_DOCS_PATH_ENV = 'PYDANTIC_AI_HARNESS_DOCS_PATH'
"""Env var holding a local pyai docs checkout path, used when `local_docs_path` is unset."""

_INSTRUCTIONS = (
    'You have a `read_pyai_docs` tool that returns Pydantic AI documentation on demand. '
    f'Topics: {", ".join(topic.value for topic in PydanticAIDocsTopic)}. Read the relevant '
    'topic before authoring or modifying a Pydantic AI capability, hook, tool, or toolset, '
    'rather than relying on memory.'
)


@dataclass
class PydanticAIDocs(AbstractCapability[AgentDepsT]):
    """Locate and return Pydantic AI documentation on demand.

    Exposes a single `read_pyai_docs(topic)` tool. Docs are located and returned
    when asked for -- never bundled into context. Each call resolves the topic
    from a configured local checkout first, then falls back to fetching the page
    from GitHub at the installed `pydantic_ai` release's tag, which needs network access.

    The local checkout path comes from `local_docs_path`, or the
    `PYDANTIC_AI_HARNESS_DOCS_PATH` env var when that is unset; with neither set
    every call goes straight to the remote source. The checkout is read through
    the run's workspace, and a run with a local path but no workspace fails at its
    start. The capability never runs git -- keep
    the local checkout current yourself.

    ```python
    from pathlib import Path

    from pydantic_ai import Agent
    from pydantic_ai.capabilities import LocalWorkspace
    from pydantic_ai_harness.pydantic_ai_docs import PydanticAIDocs

    agent = Agent(
        'anthropic:claude-sonnet-4-6',
        capabilities=[LocalWorkspace('.'), PydanticAIDocs(local_docs_path=Path('docs'))],
    )
    ```
    """

    local_docs_path: Path | None = None
    """Pyai docs checkout inside the workspace. Relative paths use the workspace
    working directory. When `None`, falls back to the
    `PYDANTIC_AI_HARNESS_DOCS_PATH` env var, then to the remote source."""

    cache: bool = True
    """If `True`, each returned doc is memoized for one agent run."""

    _: KW_ONLY
    remote_ref: str | None = None
    """Git ref of `pydantic/pydantic-ai` the remote fallback reads, such as `'main'`. When `None`, the
    installed `pydantic_ai` release's tag, so the docs match the installed APIs; a dev build reads `main`."""

    id: str | None = 'pydantic_ai_docs'
    """Stable capability ID, so its instructions are addressable and `defer_loading=True` needs none.

    An agent has one `read_pyai_docs` tool, so two `PydanticAIDocs` sharing this `id` are one docs source
    stated twice when they agree, and an error when they differ. To keep two, give each its own `id` and
    wrap them in `PrefixTools`, since their tool names are the same.
    """

    _cache: dict[PydanticAIDocsTopic, str] = field(
        default_factory=dict[PydanticAIDocsTopic, str], init=False, repr=False, compare=False
    )
    """In-memory doc cache shared with toolsets created during one run."""

    @classmethod
    def combine(cls, capabilities: Sequence[AbstractCapability[AgentDepsT]]) -> AbstractCapability[AgentDepsT]:
        """Two under one `id` are one docs source stated twice; two that disagree raise rather than merge."""
        return one_per_id(capabilities)

    async def for_run(self, ctx: RunContext[AgentDepsT]) -> PydanticAIDocs[AgentDepsT]:
        """Return a fresh per-run cache so workspace-local content cannot cross runs."""
        run = replace_no_init(self)
        run._cache = {}
        return run

    async def before_run(self, ctx: RunContext[AgentDepsT]) -> None:
        """Fail the run at its start when a local checkout is configured but no workspace holds it."""
        if self._resolved_local_path() is not None:
            require_workspace(ctx.workspace, 'PydanticAIDocs', ctx.messages)

    def _resolved_local_path(self) -> Path | None:
        """The local checkout path: `local_docs_path`, else the env var, else `None`.

        Paths identify files inside the run workspace. Relative paths are resolved
        from its working directory.
        """
        if self.local_docs_path is not None:
            return self.local_docs_path
        env_path = os.environ.get(_DOCS_PATH_ENV)
        return Path(env_path) if env_path else None

    def get_instructions(self) -> AgentInstructions[AgentDepsT] | None:
        """Static, cache-stable guidance on using the docs tool."""
        return _INSTRUCTIONS

    def get_toolset(self) -> AgentToolset[AgentDepsT] | None:
        """Toolset providing `read_pyai_docs` over the resolved local path and shared cache."""
        return PydanticAIDocsToolset[AgentDepsT](
            local_docs_path=self._resolved_local_path(),
            cache=self._cache if self.cache else None,
            remote_ref=self.remote_ref,
        )

    @classmethod
    def get_serialization_name(cls) -> str | None:
        """Serialization name for agent-spec support."""
        return 'PydanticAIDocs'
