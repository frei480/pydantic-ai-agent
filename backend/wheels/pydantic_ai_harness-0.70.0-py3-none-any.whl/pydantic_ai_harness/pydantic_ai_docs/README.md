# Pydantic AI Docs

Give an agent a tool that locates and returns Pydantic AI documentation on demand.

[Source](https://github.com/pydantic/pydantic-ai/tree/main/src/pydantic_ai_harness/pydantic_ai_harness/pydantic_ai_docs/)

```mermaid
flowchart TB
    accTitle: Pydantic AI Docs: read the current docs page on demand
    accDescr: The model calls read_pyai_docs(topic) on the PydanticAIDocs capability and gets the full page, with model aliases replaced. The capability first reads the workspace checkout at local_docs_path, when the page exists there, and otherwise GitHub at the installed pydantic-ai release tag. If neither has the page, the capability returns an error naming the path and URL it tried.
    model(["model"])
    docs["PydanticAIDocs()<br/>read_pyai_docs(topic)<br/>replaces model aliases"]:::capability
    checkout["workspace<br/>checkout at<br/>local_docs_path"]
    github["pydantic-ai on GitHub<br/>at the installed<br/>release tag"]:::external
    error["error naming<br/>the path and URL<br/>it tried"]:::blocked
    model <-->|"topic, full page"| docs
    docs -->|"first, when<br/>the page exists"| checkout
    docs -->|"otherwise"| github
    docs -.-x|"neither has the page"| error
    classDef capability stroke:#E520E9,stroke-width:2px
    classDef external stroke:#0E9C86,stroke-width:2px
    classDef blocked stroke:#E5533D,stroke-width:2px,stroke-dasharray:4 3
```

## The problem

An agent that authors Pydantic AI capabilities, hooks, tools, or toolsets needs the
current docs for those APIs. Preloading the docs into the system prompt spends context
the agent rarely needs in full and pins a snapshot that drifts from the installed version.

## The solution

`PydanticAIDocs` exposes one tool, `read_pyai_docs(topic)`, that locates the requested page and
returns it in full, with its model aliases resolved -- nothing is bundled into context up front.
Each call resolves the topic from a configured local checkout first, then falls back to fetching
the page from GitHub at the installed `pydantic_ai` release tag (the remote fallback needs network access).

Topics: `capabilities`, `hooks`, `tools`, `tools-advanced`, `toolsets`, `agent`.

```python
from pathlib import Path

from pydantic_ai import Agent
from pydantic_ai.capabilities import LocalWorkspace
from pydantic_ai_harness import PydanticAIDocs

agent = Agent(
    'anthropic:claude-sonnet-5',
    capabilities=[LocalWorkspace('.'), PydanticAIDocs(local_docs_path=Path('docs'))],
)

result = agent.run_sync('Read the toolsets docs, then explain how to build a FunctionToolset.')
print(result.output)
```

A configured local checkout is read through the run's [workspace](https://pydantic.dev/docs/ai/core-concepts/workspace/), so a run with a local path and no workspace fails at its start. With no local path configured, no workspace is needed.

## Resolution order

Each call resolves in this order:

1. **Workspace checkout** -- when `local_docs_path` (or the `PYDANTIC_AI_HARNESS_DOCS_PATH`
   environment variable) is set and the topic's page exists under it inside the run workspace
   (`{path}/{topic}.md`, or `{path}/capabilities/overview.md` for `capabilities`), that file is
   read and returned.
2. **Remote fetch** -- otherwise the page is fetched from the same path under
   `https://raw.githubusercontent.com/pydantic/pydantic-ai/{remote_ref}/docs/`. `remote_ref` defaults to the installed `pydantic_ai` release tag, such as `v2.69.0`, so the page describes the APIs you have; a dev build without a release tag reads `main`. Pass `remote_ref='main'` to read the latest docs instead.
3. **Neither resolves** -- a descriptive error naming the local path tried and the URL.

Docs pages name models through aliases, which the docs site replaces with current models. Before
returning a page that uses one, the tool reads the alias file, `model_aliases/aliases.json`, in the
same order and replaces each alias with the model it names. An alias the file does not define is
left as written, and so is every alias when neither source can provide the file. A page without
aliases reads nothing else, so a checkout from before the alias file existed keeps working.

The capability never runs git. Keep the local checkout current yourself.

`local_docs_path` takes precedence over the `PYDANTIC_AI_HARNESS_DOCS_PATH` environment variable.
`~` is not expanded -- use an absolute workspace path or a path relative to its working
directory.

## Configuration

| Option | Default | Purpose |
| --- | --- | --- |
| `local_docs_path` | `None` | Pyai docs checkout inside the run workspace. Relative paths use the workspace working directory. Falls back to the `PYDANTIC_AI_HARNESS_DOCS_PATH` environment variable, then to the remote source. |
| `cache` | `True` | Memoize each returned doc for one agent run, so repeated reads within that run do not repeat workspace or network I/O. |
| `remote_ref` | `None` | Git ref of `pydantic/pydantic-ai` the remote fetch reads. `None` uses the installed `pydantic_ai` release tag, or `main` for a dev build. Keyword-only. |

Caching is isolated per run so content read from one workspace is not reused in another. Set
`cache=False` to re-read or re-fetch on every call within a run.

## Two of them

`PydanticAIDocs` declares the default `id` `'pydantic_ai_docs'`. The `id` keys the capability's instructions, so they
can be addressed, and lets `defer_loading=True` work without one. Two `PydanticAIDocs`s on one agent that
share it are one docs source stated twice: they become one when they agree, and the agent raises a
`UserError` when it's built if they differ. To keep two, give each its own `id` and wrap them
in [PrefixTools](https://pydantic.dev/docs/ai/capabilities/prefix-tools/), since both register `read_pyai_docs`.

Earlier releases declared no default `id`, so two always failed on the tool name when the run
started. Two identical ones now become one, and two that differ fail when the agent is built.
