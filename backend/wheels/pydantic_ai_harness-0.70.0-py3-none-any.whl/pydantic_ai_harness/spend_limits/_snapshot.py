"""What a window has accumulated, and what one response added to it."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, localcontext
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic_ai.usage import RequestUsage
    from pydantic_ai_harness.spend_limits._budget import Budget

MONEY_PRECISION = 40
"""Significant digits every arithmetic step on `Spent.usd` is pinned to.

`Decimal` reads its precision from the thread's context, so an application that lowered
`getcontext().prec` for its own arithmetic would round money here. A counter Redis holds
exactly as billionths would come back with the application's significant digits, and the
in-process store would write the rounded number back and drift from it on every response.
Wide enough for the signed 64-bit range of billionths a counter can reach.
"""


@contextmanager
def money_precision() -> Generator[None]:
    """Run `Decimal` arithmetic at `MONEY_PRECISION` rather than at whatever the caller set.

    Wraps the operation rather than replacing it, so one guard covers a sum, a difference
    and a product instead of one helper per operator. Copies the caller's context and moves
    only `prec`, so rounding and traps are left as the application chose them.
    """
    with localcontext() as context:
        context.prec = MONEY_PRECISION
        yield


_NANOS_PER_USD = Decimal(10) ** 9


def to_nanos(usd: Decimal) -> int:
    """US dollars as whole billionths, the unit the shared stores hold counters in.

    Counters are integers because floating-point accumulation (Redis `INCRBYFLOAT`)
    gathers binary rounding error over the tens of thousands of requests a busy day
    produces, while integer increments are both exact and atomic.

    Billionths rather than millionths because the residue does not average out:
    an agent repeats requests of near-identical shape, so the same fraction is
    rounded the same way every time. At a cheap model's per-request price,
    rounding to a millionth drifts by tens of percent over a day; a billionth
    keeps that under a part in ten thousand.

    The local context is pinned so an application that lowered `Decimal`
    precision for its own arithmetic cannot truncate money here.
    """
    with money_precision():
        return int((usd * _NANOS_PER_USD).to_integral_value(rounding=ROUND_HALF_UP))


def from_nanos(nanos: int) -> Decimal:
    """Whole billionths back to US dollars."""
    with money_precision():
        return Decimal(nanos) / _NANOS_PER_USD


@dataclass(frozen=True, kw_only=True)
class Spent:
    """Everything one window has accumulated so far."""

    usd: Decimal = Decimal(0)
    """Priced cost. Requests with no resolvable price contribute nothing here."""

    tokens: int = 0
    """Total tokens, counted whether or not the request could be priced."""

    requests: int = 0
    """Model requests recorded against this window.

    Every billed request counts, including a response a `FallbackModel` rejected, so this can be
    higher than the run's `RunUsage.requests`, which counts the responses the agent acted on.
    """

    unpriced_requests: int = 0
    """How many of `requests` had no resolvable price, so `usd` understates them."""


@dataclass(frozen=True, kw_only=True)
class BudgetStatus:
    """A budget and how much of it is left."""

    budget: Budget[Any]
    """The budget this describes, as configured. `usd_limit` and `token_limit` hold its resolved ceilings.

    Unparameterised because this is a reading: the dependency type only types
    the callables of a `Budget`, and nothing calls one through a status.
    """

    key: str
    """The store key it accumulates under. Useful for debugging a scope or window."""

    spent: Spent
    """What the budget's current window has accumulated."""

    usd_limit: Decimal | None = None
    """The USD ceiling this reading is measured against, resolved for the run when `Budget.usd` is a callable."""

    token_limit: int | None = None
    """The token ceiling this reading is measured against, resolved for the run when `Budget.tokens` is a callable."""

    remaining_usd: Decimal | None
    """`None` when no USD ceiling applies to this reading (`usd_limit` is `None`)."""

    remaining_tokens: int | None
    """`None` when no token ceiling applies to this reading (`token_limit` is `None`)."""

    warning: bool
    """Whether spend has crossed `Budget.warn_at`. Always `False` without one."""

    exhausted: bool
    """Whether a further request would be refused."""


@dataclass(frozen=True, kw_only=True)
class SpendSnapshot:
    """What one model response cost, and where every budget stands after it."""

    model: str | None
    """The model that produced the response, or `None` if it reported none."""

    usage: RequestUsage
    """The response's usage verbatim, including cache reads, writes, and audio."""

    usd: Decimal
    """What this response cost. Zero when it could not be priced."""

    priced: bool
    """Whether `usd` is a real price or a stand-in zero."""

    budgets: tuple[BudgetStatus, ...]
    """One entry per configured budget, in the order they were declared."""
