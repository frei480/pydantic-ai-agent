"""Capabilities for Pydantic AI agents."""

from typing import TYPE_CHECKING

from ._warn import HarnessDeprecationWarning, MCPReadOnlyNoToolsWarning

if TYPE_CHECKING:
    from .absurd import AbsurdDurability
    from .advisor import Advisor
    from .approval_reviewer import ApprovalReviewer
    from .artifact_scanning import ArtifactScanner
    from .ask_user import AskUser
    from .azure_durable_task import AzureDurableTaskDurability
    from .background_tools import BackgroundTools
    from .boxd_sandbox import BoxdSandbox, BoxdSandboxBackend
    from .boxlite_sandbox import BoxLiteSandbox, BoxLiteSandboxBackend
    from .browser_use import BrowserUse
    from .bubblewrap_sandbox import BubblewrappedWorkspace, BubblewrapWorkspace
    from .capability_creation import CapabilityCreation
    from .code_mode import CodeMode
    from .coder import BenchmarkInstructions, Coder
    from .compaction import (
        ClampOversizedMessages,
        ClearToolResults,
        CompactOnRequest,
        DeduplicateFileReads,
        FallbackCompaction,
        PruneToolResults,
        RelevanceCompaction,
        ReportContextUsage,
        SlidingWindowCompaction,
        SummarizingCompaction,
        TieredCompaction,
        WarnNearLimits,
    )
    from .conversation_search import ConversationSearch
    from .day_ai import DayAI
    from .daytona_sandbox import DaytonaSandbox, DaytonaSandboxBackend
    from .detect_loops import DetectLoops
    from .docker_container import DockerContainer, DockerContainerBackend

    # Deprecated names: the redundant aliases type them for users; at runtime they resolve lazily, with a warning.
    from .docker_sandbox import DockerSandbox as DockerSandbox, DockerSandboxBackend as DockerSandboxBackend  # pyright: ignore[reportDeprecated]
    from .dynamic_workflow import DynamicWorkflow
    from .e2b_sandbox import E2BSandbox, E2BSandboxBackend
    from .exa import ExaAgent, ExaSearch
    from .file_system import READ_ONLY_TOOL_NAMES, FileSystem
    from .grain import Grain
    from .guardrails import (
        GuardrailError,
        GuardrailResult,
        InputBlocked,
        InputGuardrail,
        InputGuardrailFunc,
        OutputBlocked,
        OutputGuardrail,
        OutputGuardrailFunc,
        StreamGuardrail,
        StreamGuardrailFunc,
        ToolGuardrail,
    )
    from .ipython_code_mode import IPythonCodeMode
    from .keenable import KeenableSearch
    from .kubernetes_sandbox import KubernetesSandbox, KubernetesSandboxBackend
    from .localstack import LocalStack
    from .logfire import ManagedPrompt
    from .macroscope import Macroscope
    from .memory import Memory
    from .modal_sandbox import ModalSandbox, ModalSandboxBackend
    from .opensandbox_sandbox import OpenSandbox, OpenSandboxBackend
    from .ordinal import Ordinal
    from .peers import Peers
    from .permissions import Permissions
    from .pgtask import PGTaskDurability
    from .pixeltable import Pixeltable
    from .planning import Planning
    from .posthog import PostHog
    from .prompt_injection_defender import PromptInjectionDefender
    from .pydantic_ai_docs import PydanticAIDocs
    from .pylon import Pylon
    from .refine_output import DEFAULT_REFINE_OUTPUT_INSTRUCTIONS, RefineOutput
    from .render import RenderWorkflows
    from .render_sandbox import RenderSandbox, RenderSandboxBackend
    from .repo_context import RepoContext
    from .researcher import DEFAULT_RESEARCHER_INSTRUCTIONS, Researcher
    from .shell import LLM_API_KEY_ENV_PATTERNS, Shell
    from .skills import Skills
    from .smart_search import SmartSearch
    from .smol_sandbox import SmolSandbox, SmolSandboxBackend
    from .spend_limits import SpendLimits
    from .sprites_sandbox import SpritesSandbox, SpritesSandboxBackend
    from .ssh_workspace import SSHWorkspace, SSHWorkspaceBackend
    from .stackone import StackOne
    from .step_persistence import StepPersistence
    from .sub_agents import SubAgent, SubAgents
    from .system_reminders import SystemReminders
    from .tool_budgets import ToolBudgets
    from .tool_call_judge import ToolCallJudge
    from .tool_output_limits import ToolOutputLimits
    from .trajectory_judge import TrajectoryJudge
    from .warn_on_cache_busts import WarnOnCacheBusts
    from .youdotcom import YouResearch, YouSearch

__all__ = [
    'AbsurdDurability',
    'Advisor',
    'ApprovalReviewer',
    'ArtifactScanner',
    'AskUser',
    'AzureDurableTaskDurability',
    'BackgroundTools',
    'BenchmarkInstructions',
    'BoxdSandbox',
    'BoxdSandboxBackend',
    'BoxLiteSandbox',
    'BoxLiteSandboxBackend',
    'BrowserUse',
    'BubblewrappedWorkspace',
    'BubblewrapWorkspace',
    'CapabilityCreation',
    'ClampOversizedMessages',
    'ClearToolResults',
    'CodeMode',
    'Coder',
    'CompactOnRequest',
    'ConversationSearch',
    'DEFAULT_REFINE_OUTPUT_INSTRUCTIONS',
    'DEFAULT_RESEARCHER_INSTRUCTIONS',
    'DayAI',
    'DaytonaSandbox',
    'DaytonaSandboxBackend',
    'DeduplicateFileReads',
    'DetectLoops',
    'DockerContainer',
    'DockerContainerBackend',
    'DynamicWorkflow',
    'E2BSandbox',
    'E2BSandboxBackend',
    'ExaAgent',
    'ExaSearch',
    'FallbackCompaction',
    'FileSystem',
    'Grain',
    'GuardrailError',
    'GuardrailResult',
    'HarnessDeprecationWarning',
    'IPythonCodeMode',
    'InputBlocked',
    'InputGuardrail',
    'InputGuardrailFunc',
    'KeenableSearch',
    'KubernetesSandbox',
    'KubernetesSandboxBackend',
    'LLM_API_KEY_ENV_PATTERNS',
    'LocalStack',
    'MCPReadOnlyNoToolsWarning',
    'Macroscope',
    'ManagedPrompt',
    'Memory',
    'ModalSandbox',
    'ModalSandboxBackend',
    'OpenSandbox',
    'OpenSandboxBackend',
    'Ordinal',
    'OutputBlocked',
    'OutputGuardrail',
    'OutputGuardrailFunc',
    'PGTaskDurability',
    'Peers',
    'Permissions',
    'Pixeltable',
    'Planning',
    'PostHog',
    'PromptInjectionDefender',
    'PruneToolResults',
    'PydanticAIDocs',
    'Pylon',
    'READ_ONLY_TOOL_NAMES',
    'RefineOutput',
    'RelevanceCompaction',
    'RenderSandbox',
    'RenderSandboxBackend',
    'RenderWorkflows',
    'ReportContextUsage',
    'RepoContext',
    'Researcher',
    'SSHWorkspace',
    'SSHWorkspaceBackend',
    'Shell',
    'Skills',
    'SlidingWindowCompaction',
    'SmartSearch',
    'SmolSandbox',
    'SmolSandboxBackend',
    'SpendLimits',
    'SpritesSandbox',
    'SpritesSandboxBackend',
    'StackOne',
    'StepPersistence',
    'StreamGuardrail',
    'StreamGuardrailFunc',
    'SubAgent',
    'SubAgents',
    'SummarizingCompaction',
    'SystemReminders',
    'TieredCompaction',
    'ToolBudgets',
    'ToolCallJudge',
    'ToolGuardrail',
    'ToolOutputLimits',
    'TrajectoryJudge',
    'WarnNearLimits',
    'WarnOnCacheBusts',
    'YouResearch',
    'YouSearch',
]

_LAZY_EXPORTS = {
    'AbsurdDurability': 'absurd',
    'Advisor': 'advisor',
    'ApprovalReviewer': 'approval_reviewer',
    'ArtifactScanner': 'artifact_scanning',
    'AskUser': 'ask_user',
    'AzureDurableTaskDurability': 'azure_durable_task',
    'BackgroundTools': 'background_tools',
    'BenchmarkInstructions': 'coder',
    'BoxdSandbox': 'boxd_sandbox',
    'BoxdSandboxBackend': 'boxd_sandbox',
    'BoxLiteSandbox': 'boxlite_sandbox',
    'BoxLiteSandboxBackend': 'boxlite_sandbox',
    'BrowserUse': 'browser_use',
    'BubblewrappedWorkspace': 'bubblewrap_sandbox',
    'BubblewrapWorkspace': 'bubblewrap_sandbox',
    'CapabilityCreation': 'capability_creation',
    'ClampOversizedMessages': 'compaction',
    'ClearToolResults': 'compaction',
    'CodeMode': 'code_mode',
    'Coder': 'coder',
    'CompactOnRequest': 'compaction',
    'ConversationSearch': 'conversation_search',
    'DayAI': 'day_ai',
    'DaytonaSandbox': 'daytona_sandbox',
    'DaytonaSandboxBackend': 'daytona_sandbox',
    'DeduplicateFileReads': 'compaction',
    'DEFAULT_REFINE_OUTPUT_INSTRUCTIONS': 'refine_output',
    'DEFAULT_RESEARCHER_INSTRUCTIONS': 'researcher',
    'DetectLoops': 'detect_loops',
    'DockerContainer': 'docker_container',
    'DockerContainerBackend': 'docker_container',
    'DynamicWorkflow': 'dynamic_workflow',
    'E2BSandbox': 'e2b_sandbox',
    'E2BSandboxBackend': 'e2b_sandbox',
    'ExaAgent': 'exa',
    'ExaSearch': 'exa',
    'FallbackCompaction': 'compaction',
    'FileSystem': 'file_system',
    'Grain': 'grain',
    'GuardrailError': 'guardrails',
    'GuardrailResult': 'guardrails',
    'InputBlocked': 'guardrails',
    'InputGuardrail': 'guardrails',
    'InputGuardrailFunc': 'guardrails',
    'IPythonCodeMode': 'ipython_code_mode',
    'KeenableSearch': 'keenable',
    'KubernetesSandbox': 'kubernetes_sandbox',
    'KubernetesSandboxBackend': 'kubernetes_sandbox',
    'LLM_API_KEY_ENV_PATTERNS': 'shell',
    'LocalStack': 'localstack',
    'Macroscope': 'macroscope',
    'ManagedPrompt': 'logfire',
    'Memory': 'memory',
    'ModalSandbox': 'modal_sandbox',
    'ModalSandboxBackend': 'modal_sandbox',
    'OpenSandbox': 'opensandbox_sandbox',
    'OpenSandboxBackend': 'opensandbox_sandbox',
    'Ordinal': 'ordinal',
    'OutputBlocked': 'guardrails',
    'OutputGuardrail': 'guardrails',
    'OutputGuardrailFunc': 'guardrails',
    'PGTaskDurability': 'pgtask',
    'Peers': 'peers',
    'Permissions': 'permissions',
    'Pixeltable': 'pixeltable',
    'Planning': 'planning',
    'PostHog': 'posthog',
    'PromptInjectionDefender': 'prompt_injection_defender',
    'PruneToolResults': 'compaction',
    'PydanticAIDocs': 'pydantic_ai_docs',
    'Pylon': 'pylon',
    'READ_ONLY_TOOL_NAMES': 'file_system',
    'RefineOutput': 'refine_output',
    'RelevanceCompaction': 'compaction',
    'RenderSandbox': 'render_sandbox',
    'RenderSandboxBackend': 'render_sandbox',
    'RenderWorkflows': 'render',
    'RepoContext': 'repo_context',
    'ReportContextUsage': 'compaction',
    'Researcher': 'researcher',
    'Shell': 'shell',
    'Skills': 'skills',
    'SlidingWindowCompaction': 'compaction',
    'SmartSearch': 'smart_search',
    'SmolSandbox': 'smol_sandbox',
    'SmolSandboxBackend': 'smol_sandbox',
    'SpendLimits': 'spend_limits',
    'SpritesSandbox': 'sprites_sandbox',
    'SpritesSandboxBackend': 'sprites_sandbox',
    'SSHWorkspace': 'ssh_workspace',
    'SSHWorkspaceBackend': 'ssh_workspace',
    'StackOne': 'stackone',
    'StepPersistence': 'step_persistence',
    'StreamGuardrail': 'guardrails',
    'StreamGuardrailFunc': 'guardrails',
    'SubAgent': 'sub_agents',
    'SubAgents': 'sub_agents',
    'SummarizingCompaction': 'compaction',
    'SystemReminders': 'system_reminders',
    'TieredCompaction': 'compaction',
    'ToolBudgets': 'tool_budgets',
    'ToolCallJudge': 'tool_call_judge',
    'ToolGuardrail': 'guardrails',
    'ToolOutputLimits': 'tool_output_limits',
    'TrajectoryJudge': 'trajectory_judge',
    'WarnNearLimits': 'compaction',
    'WarnOnCacheBusts': 'warn_on_cache_busts',
    'YouResearch': 'youdotcom',
    'YouSearch': 'youdotcom',
    # Pre-rename names; the target module's `__getattr__` emits the
    # deprecation warning when these resolve.
    'BubblewrapSandbox': 'bubblewrap_sandbox',
    'GuardResult': 'guardrails',
    'InputGuard': 'guardrails',
    'InputGuardFunc': 'guardrails',
    'OutputGuard': 'guardrails',
    'OutputGuardFunc': 'guardrails',
    # Pre-rename names; importing the `pydantic_ai_harness.docker_sandbox` shim emits
    # the deprecation warning.
    'DockerSandbox': 'docker_sandbox',
    'DockerSandboxBackend': 'docker_sandbox',
}


def __getattr__(name: str) -> object:
    module_name = _LAZY_EXPORTS.get(name)
    if module_name is not None:
        from importlib import import_module

        module = import_module(f'.{module_name}', __name__)
        return getattr(module, name)
    raise AttributeError(f'module {__name__!r} has no attribute {name!r}')
