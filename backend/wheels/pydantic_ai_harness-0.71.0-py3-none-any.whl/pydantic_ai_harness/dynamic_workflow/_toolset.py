"""Toolset for the `DynamicWorkflow` capability.

Exposes a single `run_workflow` tool: the model writes a Python orchestration
script (run in a Monty sandbox) that calls named sub-agents as async functions
and composes their results -- fan-out, chaining, voting, loops -- in one step.
"""

from __future__ import annotations

import asyncio
import contextvars
import copy
import json
import sys
import warnings
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass, field
from functools import partial
from typing import TYPE_CHECKING, Annotated, Any, Generic, Literal, Protocol, Self, cast

from pydantic import Field, TypeAdapter
from pydantic_core import to_jsonable_python
from typing_extensions import TypedDict

from pydantic_ai import AbstractToolset, RunContext, ToolDefinition
from pydantic_ai.agent.abstract import AbstractAgent
from pydantic_ai.capabilities import AbstractCapability, WrapperCapability
from pydantic_ai.durable_exec import BaseDurabilityCapability
from pydantic_ai.exceptions import ModelRetry, UsageLimitExceeded, UserError
from pydantic_ai.function_signature import FunctionSignature, _is_python_identifier  # pyright: ignore[reportPrivateUsage]
from pydantic_ai.messages import (
    InstructionCapabilityPart,
    ModelMessage,
    ModelRequest,
    OperatorSource,
    OperatorText,
    SystemPromptPart,
    post_compaction_window,
)
from pydantic_ai.models import Model
from pydantic_ai.tools import AgentDepsT
from pydantic_ai.toolsets.abstract import SchemaValidatorProt, ToolsetTool
from pydantic_ai.usage import UsageLimits
from pydantic_ai_harness.deny_unanswered._capability import find_deny_unanswered

try:
    from pydantic_monty import (
        MontyCrashedError,
        MontyRuntimeError,
        MontySyntaxError,
        MontyTypingError,
        ResourceLimits,
    )
except ImportError as _import_error:  # pragma: no cover
    raise ImportError(
        'pydantic-monty is required for DynamicWorkflow. '
        'Install it with: uv add "pydantic-ai-harness[dynamic-workflow]"'
    ) from _import_error

from pydantic_ai_harness._monty_exec import (
    DispatchFn,
    MontyExecutor,
    MontyRunState,
    PrintCapture,
    in_temporal_workflow,
)
from pydantic_ai_harness._monty_turns import is_sandbox_panic
from pydantic_ai_harness._sub_agent_output import (
    ServingModelRecorder,
    cancel_pending_output,
    resumable_output_reason,
    without_resumable_outputs,
)
from pydantic_ai_harness._warn import renamed_duration_limit

if TYPE_CHECKING:
    from pydantic_ai_harness.aws_lambda._bridge import StepBridge
    from pydantic_ai_harness.aws_lambda._operation_backend import AWSLambdaOperationConfig

# Set while a workflow script is executing, so `get_tools` hides `run_workflow` from sub-agents
# running inside it -- workflows do not nest. asyncio copies the context into each task `asyncio.gather`
# schedules, so concurrently-dispatched sub-agents inherit this flag (the capability is asyncio-only).
_in_workflow: contextvars.ContextVar[bool] = contextvars.ContextVar(
    'pydantic_ai_harness.dynamic_workflow.in_workflow', default=False
)


class WorkflowResourceLimits(TypedDict, total=False):
    """Caps on the orchestration script's own sandbox resources (not sub-agent latency).

    A harness-owned view of the sandbox limits the capability supports, so the public API does
    not depend on the underlying sandbox's own types. Every field is optional; an omitted field
    keeps its backstop value.
    """

    max_duration_seconds: float
    """Ceiling on the time the script spends executing sandbox code. Monty checks it per bytecode
    step, so time spent awaiting sub-agents does not count against it -- neither a single `await`
    nor a concurrent `asyncio.gather` batch, because during that wait the script is suspended on
    the host, not running sandbox code. There is no default cap. Set one to bound a pure-CPU
    `while True` loop, which would otherwise burn a core in the sandbox worker (and block the
    workflow thread under Temporal) -- the one runaway the sub-agent budgets do not catch.
    Sleeping is not execution time either, so when set, the script may also sleep for up to this
    long in total."""

    max_duration_secs: float
    """Deprecated: renamed to `max_duration_seconds`."""

    max_memory: int
    """Maximum sandbox memory, in bytes."""


def _default_resource_limits() -> ResourceLimits:
    """Backstop sandbox limits; no duration cap -- see `WorkflowResourceLimits.max_duration_seconds`."""
    return {
        'max_memory': 256 * 1024 * 1024,
    }


# The keys `WorkflowResourceLimits` accepts, without the deprecated one `__post_init__` renames.
# A `total=False` TypedDict does not validate keys at runtime, so a typo (e.g. `max_durations_seconds`)
# would otherwise merge through and be silently dropped -- quietly disabling the only guard against
# a pure-CPU `while True`. We reject unknowns.
_RESOURCE_LIMIT_KEYS = frozenset(WorkflowResourceLimits.__annotations__) - {'max_duration_secs'}
_MODEL_SAFE_EXCEPTION_MESSAGE_TYPES = (UsageLimitExceeded,)
_MAX_COMPLETED_DISPATCHES = 20
_MAX_TASK_PREVIEW_CHARS = 120
_MAX_RESULT_PREVIEW_CHARS = 300
_TRUNCATED_MARKER = ' ... [truncated]'
# `SystemPromptPart.metadata` keys marking a reveal announcement an earlier version enqueued, before `AgentRevealPart`.
_REVEAL_TOOL_KEY = 'dynamic_workflow_tool'
_REVEAL_AGENT_KEY = 'dynamic_workflow_revealed_agent'
_STUB_BODY = 'raise NotImplementedError()'


def _resolve_resource_limits(limits: WorkflowResourceLimits | Literal['unlimited'] | None) -> ResourceLimits:
    """Resolve the public `resource_limits` value to the limits handed to the sandbox.

    A partial mapping merges *onto* the backstop rather than replacing it. Full semantics:
    `DynamicWorkflow.resource_limits`.
    """
    if limits is None:
        return _default_resource_limits()
    if limits == 'unlimited':
        return {}
    unknown = set(limits) - _RESOURCE_LIMIT_KEYS
    if unknown:
        raise UserError(
            f'Unknown `resource_limits` key(s): {sorted(unknown)}. Valid keys are {sorted(_RESOURCE_LIMIT_KEYS)}.'
        )
    resolved = _default_resource_limits()
    if 'max_memory' in limits:
        resolved['max_memory'] = limits['max_memory']
    if 'max_duration_seconds' in limits:
        resolved['max_feed_duration_secs'] = limits['max_duration_seconds']
    return resolved


class _WorkflowArgs(TypedDict):
    code: Annotated[str, Field(description='The Python orchestration script to execute in the sandbox.')]


_WORKFLOW_ARGS_ADAPTER = TypeAdapter(_WorkflowArgs)
_WORKFLOW_ARGS_JSON_SCHEMA = _WORKFLOW_ARGS_ADAPTER.json_schema()
_WORKFLOW_ARGS_VALIDATOR: SchemaValidatorProt = _WORKFLOW_ARGS_ADAPTER.validator  # pyright: ignore[reportAssignmentType]


class _BudgetExhaustedError(RuntimeError):
    """The run's `max_agent_calls` budget is spent; no further sub-agent runs are allowed."""

    def __init__(self, max_agent_calls: int) -> None:
        super().__init__(f'sub-agent call budget ({max_agent_calls}) exhausted')


_WORKFLOW_BASE_DESCRIPTION = """\
Write and run a Python orchestration script in a sandbox to coordinate multiple sub-agents.

Use this to break a task across specialized sub-agents and combine their results in a single step --
fan work out in parallel, chain one agent's output into the next, vote across several, or loop until
done -- instead of delegating to one sub-agent at a time.

The sandbox uses Monty, a subset of Python. Key restrictions:
- **No third-party libraries**.
- **Importable standard-library modules**: `sys`, `typing`, `asyncio`, `math`, `json`, `re`,
  `unicodedata`, `datetime`, `time`, and `random`. Import what you use at the top of the script.
  There is no filesystem or environment access.
- **No clock or randomness**: `datetime.datetime.now()`, `datetime.date.today()`, `time.time()`,
  and unseeded `random` fail. `time.sleep` and `asyncio.sleep` really wait.

Each sub-agent below is an async function. Await it and pass `task` by keyword:
`result = await reviewer(task="...")`, not `reviewer("...")`; all parameters are keyword-only. A
sub-agent returns that agent's output: a string by default, or -- if it has a structured
`output_type` -- a dict, whose fields you read by subscript (`r["field"]`), not attribute
(`r.field`). Each sub-agent call is an independent run with no memory of earlier calls; include all
needed context in `task`. Run several at once with `asyncio.gather` rather than awaiting each
sequentially:

```python
import asyncio
reviews = await asyncio.gather(reviewer(task="check auth"), reviewer(task="check parsing"))
```

`asyncio.gather` accepts positional awaitables but no keyword arguments, including
`return_exceptions=True`. Other task creation and wait APIs are unavailable. A sub-agent failure
surfaces as `RuntimeError`: catch it with `try`/`except RuntimeError`, or let it abort the whole
script and retry.

The last expression's value is captured as the result -- you do **not** need to `print()` it, and
printing produces a string representation, not structured data. Use `print()` only for debug logging.
Return shapes: no print returns the last expression value (or `{}` if it is `None`); print plus a
non-`None` value returns `{"output": "<printed text>", "result": <last expression>}`; print plus
`None` returns `{"output": "<printed text>"}`. If a script fails after some sub-agent calls complete,
bounded previews of up to the 20 most recent results are reported so a retry can reuse untruncated
values.\
"""


# Every sub-agent is exposed with the same fixed parameters -- `(*, task: str)` -- and a per-agent
# return schema. Render each catalog entry through core's `FunctionSignature` (the renderer
# code_mode and Pydantic AI already use). This keeps the catalog format consistent across
# capabilities, forces keyword-only `task` to match `dispatch` (which reads `kwargs['task']`), and
# renders docstrings safely -- a hand-rolled f-string breaks on a newline or a quote inside a
# description.
_SUB_AGENT_PARAMS_SCHEMA: dict[str, Any] = {
    'type': 'object',
    'properties': {'task': {'type': 'string'}},
    'required': ['task'],
}


@dataclass(frozen=True)
class WorkflowCall:
    """One sub-agent call a workflow script made, handed to a `WorkflowCallScheduler`."""

    agent_name: str
    """The sandbox function name the script called."""

    start: Callable[[], Awaitable[object]]
    """Runs the sub-agent and returns its output."""


class WorkflowCallScheduler(Protocol):
    """Decides when the sub-agent calls of one workflow script start.

    `DynamicWorkflow(call_scheduler=...)` creates one for each `run_workflow` call.
    """

    async def run(self, call: WorkflowCall) -> object:
        """Run one sub-agent call by awaiting `call.start()`, and return its output."""
        ...

    async def flush(self) -> None:
        """Called each time the script waits on its calls, once every call it made before the wait has reached `run`.

        A call the script is waiting on only completes once `run` awaits its `call.start()`, so a
        scheduler that holds calls back must release them here. A durable engine that batches the
        calls, like `AWSLambdaDurability`, takes its batch right after this returns, so under one a
        released call has to await `call.start()` without suspending first, or it misses the batch
        and the script waits on it indefinitely.
        """
        ...


def _apply_scheduler(
    scheduler: WorkflowCallScheduler, dispatch: DispatchFn, flush: Callable[[], Awaitable[None]] | None
) -> tuple[DispatchFn, Callable[[], Awaitable[None]]]:
    """Route each dispatch through `scheduler`, and run its `flush` before the engine's own."""

    async def scheduled(agent_name: str, kwargs: dict[str, Any]) -> object:
        dispatch_errors: list[Exception] = []

        async def start() -> object:
            try:
                return await dispatch(agent_name, kwargs)
            except Exception as exc:
                dispatch_errors.append(exc)
                raise

        try:
            return await scheduler.run(WorkflowCall(agent_name, start))
        except Exception as exc:
            if exc in dispatch_errors:
                raise
            # Like a sub-agent failure, a scheduler's own error reaches the script without host details.
            raise RuntimeError(f'call scheduler raised {type(exc).__name__}') from exc

    async def flush_scheduler() -> None:
        # Let a call dispatched in the last loop iteration reach `scheduler.run`.
        await asyncio.sleep(0)
        await scheduler.flush()
        if flush is not None:
            await flush()

    return scheduled, flush_scheduler


def _lambda_bridge() -> StepBridge | None:
    """The AWS Lambda step bridge of the durable handler this runs in, if any."""
    # Only `run_durable` publishes a bridge, so a process that never imported it has none.
    if 'pydantic_ai_harness.aws_lambda._bridge' not in sys.modules:
        return None  # pragma: lax no cover - whether a test imported it first depends on test order
    from pydantic_ai_harness.aws_lambda._bridge import current_bridge

    return current_bridge()


@dataclass
class _Branch:
    run: Callable[[], Awaitable[Any]]
    config: AWSLambdaOperationConfig
    future: asyncio.Future[Any]


@dataclass
class _LambdaBranches:
    """Collects sub-agent runs and runs them as the branches of a Lambda `parallel` operation.

    Lambda numbers a context's steps in the order they start, so the steps of concurrent sub-agents
    would interleave by timing, and replay could hand one sub-agent's checkpoints to another. In a
    branch of their own, a sub-agent's steps are numbered within the branch, and a branch's ID derives
    from its position, which is the order the script dispatched the calls.
    """

    bridge: StepBridge
    name: str
    _pending: list[_Branch] = field(default_factory=list[_Branch])

    def submit(
        self, agent: AbstractAgent[Any, object], operation: Callable[[], Awaitable[Any]]
    ) -> asyncio.Future[Any] | None:
        """Add the run to the batch if `agent` runs under `AWSLambdaDurability`, else return `None`."""
        # The bridge is only active in a durable handler, which imported this.
        from pydantic_ai_harness.aws_lambda._capability import AWSLambdaDurability, operation_config

        durability = BaseDurabilityCapability.from_agent(agent)
        if not isinstance(durability, AWSLambdaDurability) or not durability.in_durable_context:
            return None
        branch = _Branch(operation, operation_config(durability), asyncio.get_running_loop().create_future())
        self._pending.append(branch)
        return branch.future

    async def flush(self) -> None:
        """Run the runs collected so far. `MontyExecutor` calls this before it resolves futures."""
        # Let a call dispatched in the last loop iteration reach `submit`.
        await asyncio.sleep(0)
        pending, self._pending = self._pending, []
        # One `parallel` operation per serializer, so each run's result is checkpointed with its agent's.
        groups: dict[int, list[_Branch]] = {}
        for branch in pending:
            groups.setdefault(id(branch.config.serdes), []).append(branch)
        for group in groups.values():
            # If this raises, `MontyExecutor` cancels the dispatches waiting on these futures.
            results = await self.bridge.run_parallel(
                self.name, [branch.run for branch in group], group[0].config.parallel_config
            )
            for branch, result in zip(group, results):
                if not branch.future.done():  # pragma: no branch - only a cancelled dispatch is done early
                    branch.future.set_result(result)


def _runs_under_dbos(agent: AbstractAgent[Any, object]) -> bool:
    """Whether the agent runs under `DBOSDurability` in a workflow.

    DBOS numbers steps in the order they start, so the steps of concurrent sub-agents would
    interleave by timing, and recovery could replay one sub-agent's results into another call.
    """
    durability = BaseDurabilityCapability.from_agent(agent)
    # Only an agent with `DBOSDurability` attached has imported it, so other engines import nothing.
    if durability is None or 'pydantic_ai.durable_exec.dbos' not in sys.modules:
        return False
    from pydantic_ai.durable_exec.dbos import DBOSDurability

    return isinstance(durability, DBOSDurability) and durability.in_durable_context


def _agent_return_schema(agent: AbstractAgent[AgentDepsT, object]) -> dict[str, Any] | None:
    """The sub-agent's output JSON schema, or `None` when it cannot be derived.

    Output types that only the run's own caller can resume from (like `DeferredToolRequests`) are
    left out: the script cannot act on them, and a run that ends with one fails the call instead.
    """
    try:
        return agent.output_json_schema(output_type=without_resumable_outputs(agent.output_type))
    except Exception:
        return None


def _agent_signature(name: str, agent: AbstractAgent[AgentDepsT, object]) -> FunctionSignature:
    """Build the sandbox function signature for one sub-agent."""
    return FunctionSignature.from_schema(
        name=name,
        parameters_schema=_SUB_AGENT_PARAMS_SCHEMA,
        return_schema=_agent_return_schema(agent),
    )


def _signature_blocks(
    catalog: Mapping[str, WorkflowAgent[AgentDepsT]], shown: Sequence[str], *, body: str
) -> list[str]:
    """Render the `shown` sub-agents' type definitions and async functions.

    Type names are disambiguated against every agent in `catalog`, which holds the agents the
    model knew about when `shown` was first presented to it.
    """
    signatures = {name: _agent_signature(name, entry.agent) for name, entry in catalog.items()}
    conflicting = FunctionSignature.get_conflicting_type_names(list(signatures.values()))
    shown_signatures = [signatures[name] for name in shown]
    blocks = FunctionSignature.render_type_definitions(shown_signatures, conflicting)
    blocks.extend(
        signature.render(
            body,
            description=catalog[signature.name].resolved_description,
            is_async=True,
            conflicting_type_names=conflicting,
        )
        for signature in shown_signatures
    )
    return blocks


def _render_catalog(catalog: Mapping[str, WorkflowAgent[AgentDepsT]], *, max_agent_calls: int) -> str:
    """Render the available sub-agents as async function signatures for the tool description."""
    listing = '```python\n' + '\n\n'.join(_signature_blocks(catalog, list(catalog), body='...')) + '\n```'
    budget = (
        f'This run can make at most {max_agent_calls} sub-agent calls in total -- one budget shared across '
        'every `run_workflow` call in the run, not per script; plan fan-out width accordingly.'
    )
    return f'{_WORKFLOW_BASE_DESCRIPTION}\n\n{budget}\n\nAvailable sub-agents:\n\n{listing}'


@dataclass(kw_only=True)
class AgentRevealPart(InstructionCapabilityPart, namespace='dynamic_workflow', name='agent_reveal'):
    """The notice `DynamicWorkflow` enqueues when `reveal()` makes a sub-agent callable mid-run.

    Its text carries the new function's signature, so the `run_workflow` description stays frozen and the prompt-cache
    prefix doesn't move. Find announcements in history by this type.
    """

    tool_name: str
    """The workflow tool the sub-agent can be called from. Never sent to the model."""

    agent_name: str
    """The name of the sub-agent it announces. Never sent to the model."""


def _reveal_announcement(
    name: str,
    catalog: Mapping[str, WorkflowAgent[AgentDepsT]],
    tool_name: str,
) -> AgentRevealPart:
    """Announcement enqueued when a sub-agent is revealed mid-run.

    Delivered in the application's voice mid-conversation (not folded into the cached tool description), so the
    prompt-cache prefix stays stable while the model still learns the agent is now callable. `catalog` holds the agents
    up to and including `name`, in reveal order.
    """
    block = '\n\n'.join(_signature_blocks(catalog, [name], body='...'))
    return AgentRevealPart(
        content=OperatorText(
            f'A new sub-agent is now available to call from inside the `{tool_name}` script:\n\n```python\n{block}\n```'
        ),
        source=OperatorSource(),
        tool_name=tool_name,
        agent_name=name,
    )


def _revealed_agent(part: object, tool_name: str) -> str | None:
    """The sub-agent `part` announces for `tool_name`, or `None` if it isn't a reveal announcement.

    An announcement an earlier version enqueued is a `SystemPromptPart` marked by its metadata.
    """
    if isinstance(part, AgentRevealPart):
        return part.agent_name if part.tool_name == tool_name else None
    metadata = part.metadata if isinstance(part, SystemPromptPart) else None
    if metadata is not None and metadata.get(_REVEAL_TOOL_KEY) == tool_name:
        return metadata[_REVEAL_AGENT_KEY]
    return None


def _visible_revealed_agents(messages: Sequence[ModelMessage], tool_name: str) -> set[str]:
    """Names of the sub-agents whose reveal announcement is still in history after the latest compaction."""
    return {
        name
        for message in post_compaction_window(messages)
        if isinstance(message, ModelRequest)
        for part in message.parts
        if (name := _revealed_agent(part, tool_name)) is not None
    }


def _workflow_result(result: object, printed: str) -> object:
    """Shape the tool return: the script's result, its captured `print()` output, or both."""
    if not printed:
        return result if result is not None else {}
    if result is None:
        return {'output': printed}
    return {'output': printed, 'result': result}


@dataclass(frozen=True)
class _CompletedDispatch:
    """One sub-agent result completed by the failed workflow script."""

    agent_name: str
    task: str
    result: object


def _truncate_preview(value: str, max_chars: int) -> str:
    """Trim a preview with an explicit marker so the model can see it is incomplete."""
    if len(value) <= max_chars:
        return value
    return value[: max_chars - len(_TRUNCATED_MARKER)] + _TRUNCATED_MARKER


def _json_preview(value: object, max_chars: int) -> str:
    """Render a compact JSON preview of a completed sub-agent result."""
    rendered = json.dumps(value, ensure_ascii=True, separators=(',', ':'))
    return _truncate_preview(rendered, max_chars)


def _completed_dispatch_lines(completed: list[_CompletedDispatch]) -> list[str]:
    """Format the most recent completed sub-agent results for model-facing salvage."""
    shown = completed[-_MAX_COMPLETED_DISPATCHES:]
    lines = [
        f'{entry.agent_name}(task={json.dumps(_truncate_preview(entry.task, _MAX_TASK_PREVIEW_CHARS), ensure_ascii=True)})'
        f' -> {_json_preview(entry.result, _MAX_RESULT_PREVIEW_CHARS)}'
        for entry in shown
    ]
    omitted = len(completed) - len(shown)
    if omitted:
        lines.insert(0, f'... {omitted} earlier completed result(s) omitted ...')
    return lines


def _completed_retry_section(completed: list[_CompletedDispatch]) -> str:
    """Build the optional retry-message section listing salvageable completed results."""
    lines = _completed_dispatch_lines(completed)
    if not lines:
        return ''
    listing = '\n'.join(f'- {line}' for line in lines)
    return (
        '\n\nCompleted sub-agent results from the failed script '
        f'(up to {_MAX_COMPLETED_DISPATCHES} bounded previews; reuse untruncated values instead of re-calling them; '
        'their budget was already spent):\n'
        f'{listing}'
    )


def _budget_terminal_result(
    *,
    max_agent_calls: int,
    last_error: str,
    completed_dispatches: list[_CompletedDispatch],
) -> dict[str, object]:
    """Build the terminal result returned after the exact sub-agent-call budget is exhausted."""
    return {
        'error': (
            f'This run exhausted its sub-agent call budget ({max_agent_calls}). '
            'Conclude using the results already gathered; further sub-agent calls in '
            'this run will be refused.'
        ),
        'last_error': last_error,
        'completed': _completed_dispatch_lines(completed_dispatches),
    }


def _worker_crash_result(
    *,
    crash: MontyCrashedError,
    budget_exhausted: bool,
    max_agent_calls: int,
    completed_dispatches: list[_CompletedDispatch],
) -> dict[str, object]:
    if budget_exhausted:
        return _budget_terminal_result(
            max_agent_calls=max_agent_calls,
            last_error='The workflow script crashed the sandbox worker after exhausting the sub-agent budget.',
            completed_dispatches=completed_dispatches,
        )
    raise ModelRetry(
        'The workflow script crashed the sandbox worker. Revise the script and try again.'
        f'{_completed_retry_section(completed_dispatches)}'
    ) from crash


def _completed_workflow_result(
    *,
    completed_output: object,
    printed: str,
    budget_exhausted: bool,
    max_agent_calls: int,
    completed_dispatches: list[_CompletedDispatch],
) -> object:
    """Return a normal result unless the script caught a terminal budget error."""
    if budget_exhausted:
        return _budget_terminal_result(
            max_agent_calls=max_agent_calls,
            last_error='The workflow caught the budget error and completed after exhausting the sub-agent budget.',
            completed_dispatches=completed_dispatches,
        )
    return _workflow_result(completed_output, printed)


def _dispatched_task(agent_name: str, kwargs: Mapping[str, object]) -> str:
    """The `task` a sandbox call to sub-agent `agent_name` passed, its only keyword argument."""
    # The sandbox signature is `(*, task: str)`, but Monty does not validate kwargs against
    # it at runtime, and the static check can be evaded through `Any` (e.g. `json.loads`
    # results) -- so check here: a dropped extra kwarg or a non-string `task` would
    # otherwise run the sub-agent on silently-wrong input. Each raises before the budget
    # is touched.
    if 'task' not in kwargs:
        raise TypeError(f'{agent_name}() missing required keyword argument: task')
    extra = sorted(set(kwargs) - {'task'})
    if extra:
        raise TypeError(f'{agent_name}() got unexpected keyword argument(s): {", ".join(extra)}; only task')
    task = kwargs['task']
    if not isinstance(task, str):
        raise TypeError(f'{agent_name}() task must be a string, got {type(task).__name__}')
    return task


@dataclass(frozen=True)
class WorkflowAgent(Generic[AgentDepsT]):
    """One sub-agent exposed to the orchestration script as an async function.

    `WorkflowAgent` is the per-use-site override for when the agent's own `name`
    or `description` is not what this workflow should show, such as renaming the
    sandbox function or re-describing the agent for this catalog. Passing a bare
    agent to `DynamicWorkflow(agents=[...])` is equivalent to `WorkflowAgent(agent)`.
    """

    agent: AbstractAgent[AgentDepsT, object]
    """The sub-agent to run when the script calls this function."""

    name: str | None = None
    """Sandbox function name; must be a valid Python identifier and unique across the
    workflow. Falls back to the agent's `name`."""

    description: str | None = None
    """Description shown to the model in the sub-agent catalog, rendered as the sandbox
    function's docstring. An explicit value, including `''`, overrides the agent's own
    `description`. When neither is set, the model sees only the bare signature."""

    @property
    def resolved_name(self) -> str | None:
        """The sandbox function name: the explicit `name`, else the agent's `name`."""
        return self.name or self.agent.name

    @property
    def resolved_description(self) -> str | None:
        """The catalog description: the explicit `description`, else the agent's own `description`.

        An explicit empty string hides the agent's own description.
        """
        return self.description if self.description is not None else self.agent.description


def validate_workflow_agent(entry: WorkflowAgent[AgentDepsT], existing_names: set[str]) -> str:
    """Validate one sub-agent entry against the names already taken."""
    name = entry.resolved_name
    if not name:
        raise UserError(
            'DynamicWorkflow sub-agent has no `name` and its agent has no `name`; '
            'set `WorkflowAgent(name=...)` so it can be exposed as a sandbox function.'
        )
    if not _is_python_identifier(name):
        raise UserError(
            f'DynamicWorkflow sub-agent name {name!r} cannot be exposed as a sandbox function: '
            'it must be a Python identifier that is not a reserved keyword. Rename it.'
        )
    if name in existing_names:
        raise UserError(f'DynamicWorkflow has two sub-agents named {name!r}; names must be unique.')
    return name


def validate_workflow_settings(
    *, max_agent_calls: int, resource_limits: WorkflowResourceLimits | Literal['unlimited'] | None
) -> None:
    """Reject settings the toolset cannot run with, so the error points at the constructor call."""
    if max_agent_calls < 1:
        raise UserError('DynamicWorkflow `max_agent_calls` must be at least 1.')
    _resolve_resource_limits(resource_limits)


def index_workflow_agents(
    agents: Sequence[WorkflowAgent[AgentDepsT]],
) -> dict[str, WorkflowAgent[AgentDepsT]]:
    """Index validated sub-agent entries by resolved sandbox name."""
    if not agents:
        raise UserError('DynamicWorkflow requires at least one sub-agent in `agents`.')
    by_name: dict[str, WorkflowAgent[AgentDepsT]] = {}
    existing_names: set[str] = set()
    for entry in agents:
        name = validate_workflow_agent(entry, existing_names)
        existing_names.add(name)
        by_name[name] = entry
    return by_name


@dataclass(kw_only=True)
class DynamicWorkflowToolset(AbstractToolset[AgentDepsT]):
    """Single-tool toolset that runs sub-agent orchestration scripts in a Monty sandbox."""

    agents: list[WorkflowAgent[AgentDepsT]]
    """Sub-agents callable from the orchestration script, each as an async function.

    `DynamicWorkflow.reveal()` is the only supported way to add a sub-agent mid-run.
    The toolset observes appends to this list as the reveal channel. Any entry that
    arrives invalid is a contract violation that raises."""

    tool_name: str = 'run_workflow'
    """Name of the tool exposed to the model."""

    max_agent_calls: int = 50
    """Maximum total sub-agent runs per agent run (an exact, host-enforced ceiling)."""

    max_retries: int = 3
    """Maximum retries for the `run_workflow` tool (syntax/runtime errors count as retries)."""

    forward_usage: bool = True
    """Share the parent run's `usage` accumulator with sub-agents. See
    `DynamicWorkflow.forward_usage` for what is and is not forwarded."""

    inherit_model: bool = False
    """Run every sub-agent with the parent run's resolved model instead of its constructed model.
    See `DynamicWorkflow.inherit_model` for when to use this."""

    sub_agent_usage_limits: UsageLimits | None = None
    """`UsageLimits` applied to every sub-agent run, replacing the parent run's limits or Pydantic AI's default.
    See `DynamicWorkflow.sub_agent_usage_limits` for the budgeting semantics."""

    resource_limits: WorkflowResourceLimits | Literal['unlimited'] | None = None
    """Sandbox limits guarding the orchestration script's own memory (not sub-agents).
    See `DynamicWorkflow.resource_limits` for the `None`/`'unlimited'`/partial-dict semantics."""

    call_scheduler: Callable[[RunContext[AgentDepsT]], WorkflowCallScheduler] | None = None
    """Creates the scheduler that decides when each script's sub-agent calls start.
    See `DynamicWorkflow.call_scheduler`."""

    toolset_id: str | None = None
    """Stable toolset id; defaults to the tool name."""

    owning_capability: AbstractCapability[AgentDepsT] | None = None
    """The `DynamicWorkflow` capability this toolset belongs to, when capability-provided.

    Used to resolve whether the capability is visible to the model on the current step (deferred
    and unloaded means hidden), by identity against the run's capability registry -- ids cannot be
    used for this, because an id-less capability is registered under a run-generated key and a
    wrapper capability is registered in place of what it wraps. `None` (a toolset used directly,
    outside any capability) is always visible."""

    # Per-run count of sub-agent calls; reset on `for_run`.
    _call_count: int = field(default=0, init=False, repr=False)

    # Sub-agents indexed by resolved sandbox name; seeded from `agents` in `__post_init__` and
    # extended in place as runtime appends to `agents` are revealed (`_reveal_pending`).
    _by_name: dict[str, WorkflowAgent[AgentDepsT]] = field(init=False, repr=False)

    # Names rendered in the run-start catalog. Later entries require reveal announcements.
    _baseline_names: frozenset[str] = field(init=False, repr=False)

    # Reveal announcements queued during the current step but not yet present in message history.
    _in_flight_announcements: set[str] = field(default_factory=set[str], init=False, repr=False)
    _announcement_step: int | None = field(default=None, init=False, repr=False)

    # Tool description, frozen at run start. Rendered from the agents present when the run began
    # and never re-rendered after a reveal, so the description -- and thus the prompt-cache
    # prefix -- never changes mid-run.
    _description: str = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.resource_limits = renamed_duration_limit(self.resource_limits, 'DynamicWorkflowToolset')
        validate_workflow_settings(max_agent_calls=self.max_agent_calls, resource_limits=self.resource_limits)
        self._rebuild()

    def _rebuild(self) -> None:
        """Rebuild the name index and the frozen tool description from the current `agents`.

        Unusable entries raise `UserError`. `DynamicWorkflow.__post_init__` and
        `DynamicWorkflow.reveal()` validate entries eagerly, so this fails only when the
        lower-level toolset list was mutated outside those APIs.
        """
        by_name = index_workflow_agents(self.agents)
        self._by_name = by_name
        self._baseline_names = frozenset(by_name)
        self._in_flight_announcements = set[str]()
        self._announcement_step = None
        self._description = _render_catalog(by_name, max_agent_calls=self.max_agent_calls)

    @property
    def id(self) -> str | None:
        return self.toolset_id or self.tool_name

    async def for_run(self, ctx: RunContext[AgentDepsT]) -> Self:
        """Fresh instance per run so the sub-agent-call budget is per-run.

        Clone shallowly, keeping `agents` shared so reveals stay visible to this run,
        reset the per-run call budget, and rebuild the per-run index. Entries are
        validated eagerly by `DynamicWorkflow.__post_init__` and `DynamicWorkflow.reveal()`,
        so a strict rebuild here cannot fail unless this list was mutated outside those
        APIs. That is unsupported and fails fast.
        """
        clone = copy.copy(self)
        clone._call_count = 0
        clone._rebuild()
        return clone

    def _fold_reveals(self, ctx: RunContext[AgentDepsT]) -> None:
        """Fold sub-agents appended to `agents` since the run started into the name index.

        Diffs the live `agents` list against the names already known (`_by_name`, which holds the
        baseline plus anything revealed so far) and folds each newcomer in so `dispatch` resolves
        it. Revealed entries absent from visible post-compaction history are announced again. The
        frozen `_description` is untouched, so the cached prompt prefix is unaffected.

        A newcomer whose name is missing, invalid, or already taken by a different
        sub-agent is a contract violation and raises `UserError`.

        Synchronous and await-free between snapshotting `agents` and mutating `_by_name`, so a
        concurrently-running `dispatch` never observes a half-revealed agent -- the same
        await-free-critical-section reasoning that keeps `max_agent_calls` exact under fan-out.
        """
        if self._announcement_step != ctx.run_step:
            self._in_flight_announcements.clear()
            self._announcement_step = ctx.run_step
        visible_announcements = _visible_revealed_agents(ctx.messages, self.tool_name)

        for entry in tuple(self.agents):
            name = entry.resolved_name
            existing = self._by_name.get(name) if name else None
            if existing is entry:
                assert name is not None
                if (
                    name in self._baseline_names
                    or name in visible_announcements
                    or name in self._in_flight_announcements
                ):
                    continue
            else:
                name = validate_workflow_agent(entry, set(self._by_name))
                self._by_name[name] = entry
            self._in_flight_announcements.add(name)
            try:
                ctx.enqueue(_reveal_announcement(name, self._catalog_through(name), self.tool_name))
            except UserError as exc:
                warnings.warn(
                    f'DynamicWorkflow revealed sub-agent {name!r}, but could not enqueue its announcement: '
                    f'{exc}. It is callable in this run, but the model will not see the reveal message.',
                    stacklevel=2,
                )

    def _visible_to_model(self, ctx: RunContext[AgentDepsT]) -> bool:
        """Whether this toolset's capability is visible to the model on this step.

        A deferred capability's toolset still gets `get_tools` calls while unloaded (its tool
        is indexed for `load_capability`/`search_tools`), but announcing a reveal then would
        leak the sub-agent signature into the conversation while the catalog is still hidden.

        The owning capability is resolved against the run's registry by identity, unwrapping
        `WrapperCapability` chains -- a wrapper over a leaf capability is registered in place of
        the leaf, and its `defer_loading`/registry id are what core keys loading on. Matching by
        id instead would misfire both ways: an id-less capability is registered under a
        run-generated key (so a lookup by tool name can hit an unrelated capability), and a
        deferred wrapper hides a non-deferred inner capability. No registry match (a toolset used
        directly, outside any capability) means always visible.
        """
        owner = self.owning_capability
        if owner is None:
            return True
        for capability_id, registered in ctx.capabilities.items():
            candidate: AbstractCapability[AgentDepsT] | None = registered
            while candidate is not None:
                if candidate is owner:
                    if registered.defer_loading is not True:
                        return True
                    return capability_id in ctx.loaded_capability_ids
                candidate = candidate.wrapped if isinstance(candidate, WrapperCapability) else None
        return True

    async def get_tools(self, ctx: RunContext[AgentDepsT]) -> dict[str, ToolsetTool[AgentDepsT]]:
        # Workflows do not nest: a sub-agent running inside a workflow script is not offered its own.
        if _in_workflow.get():
            return {}
        # Skip reveal processing while the capability is deferred and unloaded: the newcomers
        # stay pending in `agents` and are folded in and announced on the first step after the
        # model loads the capability.
        if self._visible_to_model(ctx):
            self._fold_reveals(ctx)
        return {
            self.tool_name: ToolsetTool(
                toolset=self,
                tool_def=ToolDefinition(
                    name=self.tool_name,
                    description=self._description,
                    parameters_json_schema=_WORKFLOW_ARGS_JSON_SCHEMA,
                    metadata={'code_arg_name': 'code', 'code_arg_language': 'python'},
                    sequential=True,
                ),
                max_retries=self.max_retries,
                args_validator=_WORKFLOW_ARGS_VALIDATOR,
            )
        }

    async def _run_one(
        self, agent_name: str, task: str, ctx: RunContext[AgentDepsT], branches: _LambdaBranches | None = None
    ) -> Any:
        """Run one sub-agent against the shared per-run budget.

        The budget check + increment must stay suspension-free: there must be no `await`
        between them. asyncio only switches tasks at suspension points, so an await-free
        check-then-increment is atomic across the concurrently-gathered dispatches, which
        is what makes `max_agent_calls` an exact ceiling under fan-out. Insert an `await`
        here (e.g. an async permission check) and the count can race past the limit; you
        would then need an explicit reservation instead.

        This exists precisely because `usage_limits` cannot give an exact ceiling here:
        core's own limit check is split from its increment by the model-request `await`
        (a TOCTOU race -- N gathered sub-agents all pass the check before any increments;
        measured ~20x overshoot). Until the run loop reserves before requesting, tree-wide
        caps stay best-effort (see `forward_usage` / `sub_agent_usage_limits` docstrings).
        """
        if self._call_count >= self.max_agent_calls:
            raise _BudgetExhaustedError(self.max_agent_calls)
        self._call_count += 1
        agent = self._by_name[agent_name].agent
        # Also suspension-free: concurrent dispatches join the batch in dispatch order.
        branch = branches.submit(agent, partial(self._run_recorded, agent_name, task, ctx)) if branches else None
        if branch is not None:
            recorded = await branch
            if 'error' in recorded:
                raise RuntimeError(recorded['error'])
            return recorded['output']
        return await self._run_sub_agent(agent_name, task, ctx)

    async def _run_recorded(self, agent_name: str, task: str, ctx: RunContext[AgentDepsT]) -> dict[str, Any]:
        """Run one sub-agent with its failure carried as data, so its branch records it rather than failing."""
        try:
            return {'output': await self._run_sub_agent(agent_name, task, ctx)}
        except RuntimeError as exc:
            return {'error': str(exc)}

    async def _run_sub_agent(self, agent_name: str, task: str, ctx: RunContext[AgentDepsT]) -> Any:
        """Run one sub-agent and return its output as JSON-compatible data."""
        # `ctx.model` is an `AbstractModel`; only a request-response `Model` can drive a sub-agent
        # run. A realtime run's model isn't one, so fall back to the sub-agent's own default rather
        # than forwarding a model it cannot run with. Bind to a local, then `cast` to recover
        # `Model[Any]` from the generic `Model` (which `isinstance` narrows to `Model[Unknown]`),
        # mirroring core's own `reinject_system_prompt` idiom.
        ctx_model = ctx.model
        inherited_model = cast('Model[Any]', ctx_model) if self.inherit_model and isinstance(ctx_model, Model) else None
        serving_model = ServingModelRecorder()
        usage_limits = self.sub_agent_usage_limits
        if usage_limits is None and self.forward_usage:
            # Shared usage is checked against the parent's limits, so they bound the whole tree.
            usage_limits = ctx.usage_limits
        # Interim: a general hook for capabilities to pass themselves on to child runs (#13135) replaces this.
        deny = find_deny_unanswered(ctx)
        try:
            result = await self._by_name[agent_name].agent.run(
                task,
                deps=ctx.deps,
                model=inherited_model,
                usage=ctx.usage if self.forward_usage else None,
                usage_limits=usage_limits,
                capabilities=[serving_model, *([deny] if deny is not None else [])],
            )
            reason = resumable_output_reason(result.output)
            if reason is None:
                return to_jsonable_python(result.output)
            # The script can't check on a request the sub-agent left pending, so it's cancelled.
            await cancel_pending_output(result.output, serving_model)
        except Exception as exc:
            # Don't leak host internals (file paths, deps/agent reprs) to the model;
            # surface the failing agent and error type by default.
            message = f'sub-agent {agent_name!r} raised {type(exc).__name__}'
            if isinstance(exc, _MODEL_SAFE_EXCEPTION_MESSAGE_TYPES):
                message = f'{message}: {exc}'
            raise RuntimeError(message) from exc
        raise RuntimeError(
            f'sub-agent {agent_name!r} {reason}; a workflow script cannot resume it, '
            'so do the task another way, or without this sub-agent'
        )

    def _build_type_check_stubs(self) -> str:
        """Render sub-agent signatures as stubs for Monty's static type checker.

        Fed to `checkout(type_check=True, type_check_stubs=...)`, they let `feed_start`
        reject a positional `task`, a misspelled function, or a wrong-typed argument
        before the script runs -- costing a retry but no sub-agent budget. Each
        `run_workflow` call is a fresh sandbox with no accumulated state, so the check
        is always sound.

        Every sub-agent is rendered as the model was shown it: the baseline as in the frozen tool
        description, and each revealed agent as in its announcement, so a type name the model read
        is the one the checker knows.
        """
        baseline = {name: entry for name, entry in self._by_name.items() if name in self._baseline_names}
        parts = ['import asyncio\nfrom typing import Any, TypedDict, NotRequired, Literal']
        parts.extend(_signature_blocks(baseline, list(baseline), body=_STUB_BODY))
        for name in self._by_name:
            if name not in self._baseline_names:
                parts.extend(_signature_blocks(self._catalog_through(name), [name], body=_STUB_BODY))
        return '\n\n'.join(parts)

    def _catalog_through(self, name: str) -> dict[str, WorkflowAgent[AgentDepsT]]:
        """The sub-agents known when `name` was revealed: those before it in reveal order, and itself."""
        names = list(self._by_name)
        return {known: self._by_name[known] for known in names[: names.index(name) + 1]}

    def _schedule(
        self,
        ctx: RunContext[AgentDepsT],
        dispatch: DispatchFn,
        branches: _LambdaBranches | None,
        *,
        sequential: bool,
    ) -> tuple[DispatchFn, Callable[[], Awaitable[None]] | None]:
        """The executor's `dispatch` and `flush`, routed through `call_scheduler` when one is set."""
        # Exclusive: under `global_sequential`, calls start only after `flush`, one at a time in
        # dispatch order, so neither the Lambda batch nor a scheduler applies.
        if sequential:
            return dispatch, None
        flush = branches.flush if branches is not None else None
        if self.call_scheduler is None:
            return dispatch, flush
        return _apply_scheduler(self.call_scheduler(ctx), dispatch, flush)

    async def call_tool(
        self, name: str, tool_args: dict[str, Any], ctx: RunContext[AgentDepsT], tool: ToolsetTool[AgentDepsT]
    ) -> Any:
        code = tool_args['code']
        budget_exhausted = False
        completed_dispatches: list[_CompletedDispatch] = []

        async def dispatch(agent_name: str, kwargs: dict[str, Any]) -> Any:
            nonlocal budget_exhausted
            task = _dispatched_task(agent_name, kwargs)
            try:
                output = await self._run_one(agent_name, task, ctx, branches)
            except _BudgetExhaustedError:
                budget_exhausted = True
                raise
            completed_dispatches.append(_CompletedDispatch(agent_name=agent_name, task=task, result=output))
            return output

        in_temporal = in_temporal_workflow()
        bridge = _lambda_bridge()
        branches = _LambdaBranches(bridge, self.tool_name) if bridge is not None else None
        sequential = any(_runs_under_dbos(w.agent) for w in self._by_name.values())
        scheduled_dispatch, flush = self._schedule(ctx, dispatch, branches, sequential=sequential)
        limits = _resolve_resource_limits(self.resource_limits)
        capture = PrintCapture()
        type_check_stubs = self._build_type_check_stubs()
        in_workflow_token = _in_workflow.set(True)
        monty = MontyRunState()
        try:
            session = await monty.get_session(
                type_check=True, type_check_stubs=type_check_stubs, limits=limits, in_temporal_workflow=in_temporal
            )
            # `_by_name` is not mutated while a script executes (reveals land in `get_tools`,
            # which does not interleave with `call_tool`), so it is a stable name registry for
            # the whole script.
            completed = await MontyExecutor(
                dispatch=scheduled_dispatch,
                valid_names=self._by_name,
                flush=flush,
                global_sequential=sequential,
                portal=monty.portal,
                max_sleep_seconds=limits.get('max_feed_duration_secs'),
            ).run(partial(session.feed_start, code, print_callback=capture.callback))
        except MontyTypingError as exc:
            raise ModelRetry(f'Type error in workflow:\n{capture.prepend_to(exc.display())}') from exc
        # Backstop: the type checker parses the code first. `lax` because the errors handled below
        # are still matched against this clause.
        except MontySyntaxError as exc:  # pragma: lax no cover
            raise ModelRetry(f'Syntax error in workflow:\n{capture.prepend_to(exc.display())}') from exc
        except MontyRuntimeError as exc:
            if budget_exhausted:
                # The script may catch the budget error and fail later on something else, so
                # the flag -- not the displayed error -- proves this script hit the budget;
                # under gather, the displayed error may also be an independently surfaced
                # failure from the same batch.
                return _budget_terminal_result(
                    max_agent_calls=self.max_agent_calls,
                    last_error=capture.prepend_to(exc.display()),
                    completed_dispatches=completed_dispatches,
                )
            raise ModelRetry(
                f'Runtime error in workflow:\n{capture.prepend_to(exc.display())}'
                f'{_completed_retry_section(completed_dispatches)}'
            ) from exc
        except MontyCrashedError as exc:
            # The worker died mid-script (e.g. resource exhaustion or request timeout);
            # the pool replaces it transparently. Completed sub-agent results are listed
            # so the retry can reuse them as plain values.
            return _worker_crash_result(
                crash=exc,
                budget_exhausted=budget_exhausted,
                max_agent_calls=self.max_agent_calls,
                completed_dispatches=completed_dispatches,
            )
        except BaseException as exc:
            # Convert a sandbox panic to a retry (see `is_sandbox_panic`);
            # anything else (CancelledError, ...) re-raises unchanged.
            if not is_sandbox_panic(exc):
                raise
            if budget_exhausted:
                return _budget_terminal_result(
                    max_agent_calls=self.max_agent_calls,
                    last_error='The workflow script aborted inside the sandbox after exhausting the sub-agent budget.',
                    completed_dispatches=completed_dispatches,
                )
            raise ModelRetry(
                'The workflow script aborted inside the sandbox. Revise the script and try again.'
                f'{_completed_retry_section(completed_dispatches)}'
            ) from exc
        finally:
            _in_workflow.reset(in_workflow_token)
            await monty.aclose()

        # Monty lets workflow code catch host exceptions. Exhausting the budget remains
        # terminal even if the script catches that error and otherwise finishes normally.
        return _completed_workflow_result(
            completed_output=completed.output,
            printed=capture.joined,
            budget_exhausted=budget_exhausted,
            max_agent_calls=self.max_agent_calls,
            completed_dispatches=completed_dispatches,
        )
