from __future__ import annotations as _annotations

import os
import warnings
from dataclasses import dataclass
from datetime import timedelta
from typing import TypeAlias, overload

from pydantic_ai import ModelProfile
from pydantic_ai._http import AsyncHTTPClient, create_async_httpx2_client
from pydantic_ai.profiles import merge_profile
from pydantic_ai.profiles.anthropic import (
    _COUNTING_STRICT_SCHEMAS,  # pyright: ignore[reportPrivateUsage]
    _INLINE_SYSTEM_PROMPT_MODEL_PREFIXES,  # pyright: ignore[reportPrivateUsage]
    AnthropicModelProfile,
    anthropic_model_profile,
)
from pydantic_ai.providers import Provider, missing_api_key_error
from pydantic_ai.providers._bedrock_model_names import split_bedrock_model_id

from .._json_schema import JsonSchema, JsonSchemaTransformer

try:
    from anthropic import (
        AsyncAnthropic,
        AsyncAnthropicBedrock,  # pyright: ignore[reportPrivateImportUsage]
        AsyncAnthropicBedrockMantle,  # pyright: ignore[reportPrivateImportUsage]
        AsyncAnthropicFoundry,
        AsyncAnthropicVertex,  # pyright: ignore[reportPrivateImportUsage]
    )
except ImportError as _import_error:
    raise ImportError(
        'Please install the `anthropic` package to use the Anthropic provider, '
        'you can use the `anthropic` optional group — `pip install "pydantic-ai-slim[anthropic]"`'
    ) from _import_error

# Below the guard on purpose: `anthropic` requires `httpx2`, so without the extra the error above
# is what users should see, not `ModuleNotFoundError: httpx2`.
import httpx2

AsyncAnthropicClient: TypeAlias = (
    AsyncAnthropic | AsyncAnthropicBedrock | AsyncAnthropicBedrockMantle | AsyncAnthropicFoundry | AsyncAnthropicVertex
)

_TOOL_AVAILABILITY_DELTA_MODEL_PREFIXES = (
    'claude-fable-5',
    'claude-mythos-5',
    'claude-opus-4-8',
    'claude-opus-5',
    'claude-sonnet-5-5',
    'claude-haiku-5-5',
)
"""Models that accept `tool_addition` / `tool_removal` blocks on a `{'role': 'system'}` entry.

The list Anthropic publishes for the `mid-conversation-tool-changes-2026-07-01` beta. It matches the published list
for `{'role': 'system'}` entries, but not `_INLINE_SYSTEM_PROMPT_MODEL_PREFIXES`, which leaves out `claude-haiku-5-5`
for its sealed `<system>` rendering: the two are separate features, one GA and one beta. Haiku 5.5 keeps these
blocks, which were measured alongside that rendering. Models predating the beta reject
the blocks with `requires a model that supports ...`, and `claude-sonnet-5` rejects them outright
(`tool_addition/tool_removal is not supported on this model`) rather than accepting and ignoring them
the way it does a plain system entry. Verified live per model, including `claude-haiku-5-5`, except
`claude-mythos-5`, which isn't reachable with our credentials and is included on the strength of the published list.
"""


_REQUEST_SCOPED_SYSTEM_PROMPT_MODEL_PREFIXES = (
    'claude-fable-5',
    'claude-mythos-5',
    'claude-opus-4-8',
    'claude-opus-5',
    'claude-sonnet-5-5',
    'claude-haiku-5-5',
)
"""Models that take a request-scoped `{'role': 'system'}` entry with `clear_at`.

The list Anthropic publishes for the `mid-conversation-system-clear-at-2026-08-21` beta. It's separate from
`_INLINE_SYSTEM_PROMPT_MODEL_PREFIXES`, which leaves out `claude-sonnet-5-5` and `claude-haiku-5-5` for their sealed
`<system>` rendering of lasting system messages. Both bind thinking blocks, and a block that's gone from the next
request invalidates every thinking block after it, while a cleared entry left in place doesn't. So these two get the
entry, with the sealed block inside it. `claude-sonnet-5` accepts and clears these entries too (verified live), but it's
left out because it ignores the role: see `_INLINE_SYSTEM_PROMPT_MODEL_PREFIXES`.
"""


_MID_CONVERSATION_EFFORT_MODEL_PREFIXES = (
    'claude-fable-5-1',
    'claude-fable-5-2',
    'claude-mythos-5-1',
    'claude-mythos-5-2',
    'claude-opus-5',
    'claude-sonnet-5-5',
    'claude-haiku-5-5',
)
"""Models that accept an effort-only `{'role': 'system'}` entry with a per-message `output_config`.

The list Anthropic publishes for the `mid-conversation-output-config-2026-07-01` beta on the Claude API and
Google Cloud: Claude Fable 5.1 and 5.2, Mythos 5.1 and 5.2, Opus 5.5, Opus 5, Sonnet 5.5 and Haiku 5.5. `claude-fable-5`
(5.0) rejects it with `requires a model that supports per-turn effort`. Amazon Bedrock serves fewer, which
`AnthropicModel.profile` narrows per client. https://platform.claude.com/docs/en/build-with-claude/effort
"""

_ON_DEMAND_COMPACTION_MODEL_PREFIXES = (
    'claude-fable-5',
    'claude-mythos-5',
    'claude-mythos-preview',
    'claude-opus-4-6',
    'claude-opus-4-7',
    'claude-opus-4-8',
    'claude-opus-5',
    'claude-sonnet-4-6',
    'claude-sonnet-5',
    'claude-haiku-5-5',
)
"""Models that accept the `compaction` request parameter of the `compact-2026-09-04` beta, and the block it returns.

The models whose `capabilities.compaction.summarize.supported` is true on Anthropic's Models API, which is `false` for
Claude Opus 4.5, Sonnet 4.5 and Haiku 4.5. The Mythos models aren't reachable with our credentials; Anthropic's
on-demand compaction docs list them. https://platform.claude.com/docs/en/build-with-claude/compaction-on-demand

No client narrows it. Besides the Claude API, the legacy Bedrock InvokeModel API and the Bedrock Messages API
(`AsyncAnthropicBedrockMantle`) compact and accept the block back live, although the docs don't list Bedrock. Vertex AI
and Microsoft Foundry are documented as supported, but weren't reachable with our credentials.
"""


class AnthropicProvider(Provider[AsyncAnthropicClient]):
    """Provider for Anthropic API."""

    @property
    def name(self) -> str:
        return 'anthropic'

    @property
    def canonical_system(self) -> str:
        # Fixed, so a subclass that only renames itself keeps sharing thinking signatures. Every client (the
        # Anthropic API, Bedrock, Claude Platform on AWS, Vertex AI and Foundry) verifies the same ones.
        return 'anthropic'

    @property
    def base_url(self) -> str:
        return str(self._client.base_url)

    @property
    def client(self) -> AsyncAnthropicClient:
        return self._client

    @staticmethod
    def model_profile(model_name: str) -> ModelProfile | None:
        # When the underlying client is `AsyncAnthropicBedrock`/`AsyncAnthropicBedrockMantle`, the model
        # name carries a Bedrock `anthropic.` provider segment (and, on the legacy InvokeModel API, a
        # `-v<n>(:<m>)?` version suffix and optional cross-region geo prefix), e.g.
        # `us.anthropic.claude-haiku-4-5-20251001-v1:0`. Strip it so `anthropic_model_profile`'s
        # `claude-...` prefix checks match; the full model name still goes on the wire via `AnthropicModel._model_name`.
        bedrock_provider, base_model_name = split_bedrock_model_id(model_name)
        if bedrock_provider == 'anthropic':
            model_name = base_model_name
        profile = anthropic_model_profile(model_name)
        return merge_profile(
            AnthropicModelProfile(json_schema_transformer=AnthropicJsonSchemaTransformer),
            profile,
            # Accepting a `{'role': 'system'}` entry is a fact about the Messages API, not about the
            # model family, so it's set here rather than in `anthropic_model_profile()`, which is
            # shared with the Bedrock Converse API and the OpenAI-compatible gateways that route the
            # same models. Only the transport verified to serve the role opts in; everywhere else the
            # flag stays `False` and `Model.prepare_messages` keeps applying the `<system>`-tagged
            # rendering, as it did before this was supported anywhere.
            AnthropicModelProfile(
                supports_inline_system_prompts=model_name.startswith(_INLINE_SYSTEM_PROMPT_MODEL_PREFIXES),
                supports_request_scoped_system_prompts=model_name.startswith(
                    _REQUEST_SCOPED_SYSTEM_PROMPT_MODEL_PREFIXES
                ),
            ),
            # Prompt caching is likewise a fact about the Messages API rather than the model family.
            # `AnthropicModel` narrows `supports_auto_cache` per client and model (the legacy Bedrock SDK client only
            # takes the top-level automatic caching parameter on some models), before the user's `profile=` so an
            # explicit value still wins, and `supported_cache_retentions` on Bedrock, which
            # grants the 1-hour TTL to only a subset of Claude models. Anthropic documents the 1-hour TTL on Vertex
            # for all active models: https://platform.claude.com/docs/en/build-with-claude/prompt-caching
            AnthropicModelProfile(
                supports_cache=True,
                supported_cache_retentions=('5m', '1h'),
                supports_auto_cache=True,
            ),
            AnthropicModelProfile(tool_addition_mode='by_reference')
            if model_name.startswith(_TOOL_AVAILABILITY_DELTA_MODEL_PREFIXES)
            else AnthropicModelProfile(),
            AnthropicModelProfile(
                supports_mid_conversation_effort=model_name.startswith(_MID_CONVERSATION_EFFORT_MODEL_PREFIXES)
            ),
            # Verified live on the Messages API and both Bedrock transports; `AnthropicModel` narrows it per client.
            AnthropicModelProfile(anthropic_enforces_strict_schema_limits=True),
            # On-demand compaction is likewise a Messages API feature, so the Bedrock Converse API and the
            # OpenAI-compatible gateways that share `anthropic_model_profile()` don't get it.
            AnthropicModelProfile(
                anthropic_supports_on_demand_compaction=model_name.startswith(_ON_DEMAND_COMPACTION_MODEL_PREFIXES)
            ),
            AnthropicModelProfile(
                # Anthropic-managed caches have a 5-minute minimum TTL refreshed on use across the direct,
                # Bedrock, and Vertex SDK paths. Paid 1-hour cache points are handled by `prompt_cache_outlook`.
                # https://platform.claude.com/docs/en/docs/build-with-claude/prompt-caching#cache-lifetime
                default_cache_retention=timedelta(minutes=5)
            ),
        )

    @overload
    def __init__(self, *, anthropic_client: AsyncAnthropicClient | None = None) -> None: ...

    @overload
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        http_client: httpx2.AsyncClient | None = None,
    ) -> None: ...

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        anthropic_client: AsyncAnthropicClient | None = None,
        http_client: httpx2.AsyncClient | None = None,
    ) -> None:
        """Create a new Anthropic provider.

        Args:
            api_key: The API key to use for authentication, if not provided, the `ANTHROPIC_API_KEY` environment variable
                will be used if available.
            base_url: The base URL to use for the Anthropic API.
            anthropic_client: An existing Anthropic client to use. Accepts
                [`AsyncAnthropic`](https://github.com/anthropics/anthropic-sdk-python),
                [`AsyncAnthropicBedrock`](https://platform.claude.com/docs/en/build-with-claude/claude-on-amazon-bedrock-legacy),
                [`AsyncAnthropicBedrockMantle`](https://platform.claude.com/docs/en/build-with-claude/claude-in-amazon-bedrock),
                [`AsyncAnthropicFoundry`](https://platform.claude.com/docs/en/build-with-claude/claude-in-microsoft-foundry), or
                [`AsyncAnthropicVertex`](https://docs.anthropic.com/en/api/claude-on-vertex-ai).
                If provided, the `api_key` and `http_client` arguments will be ignored.
            http_client: An existing `httpx2.AsyncClient` to use for making HTTP requests.
        """
        if anthropic_client is not None:
            assert http_client is None, 'Cannot provide both `anthropic_client` and `http_client`'
            assert api_key is None, 'Cannot provide both `anthropic_client` and `api_key`'
            self._client = anthropic_client
        else:
            api_key = api_key or os.getenv('ANTHROPIC_API_KEY')
            if not api_key:
                raise missing_api_key_error(
                    'Set the `ANTHROPIC_API_KEY` environment variable or pass it via `AnthropicProvider(api_key=...)`'
                    ' to use the Anthropic provider.'
                )
            if http_client is not None:
                self._client = AsyncAnthropic(api_key=api_key, base_url=base_url, http_client=http_client)
            else:
                http_client = create_async_httpx2_client()
                self._own_http_client = http_client
                self._http_client_factory = create_async_httpx2_client
                self._client = AsyncAnthropic(api_key=api_key, base_url=base_url, http_client=http_client)

    def _set_http_client(self, http_client: AsyncHTTPClient) -> None:
        assert isinstance(http_client, httpx2.AsyncClient)
        self._client._client = http_client  # pyright: ignore[reportPrivateUsage]


@dataclass(init=False)
class AnthropicJsonSchemaTransformer(JsonSchemaTransformer):
    """Transforms schemas to the subset supported by Anthropic structured outputs.

    Transformation is applied when:
    - `NativeOutput` is used as the `output_type` of the Agent
    - `strict=True` is set on the `Tool`

    The behavior of this transformer differs from the OpenAI one in that it sets `Tool.strict=False` by default when not explicitly set to True.

    Example:
        ```python
        from pydantic_ai import Agent

        agent = Agent('anthropic:claude-sonnet-4-6')

        @agent.tool_plain  # -> defaults to strict=False
        def my_tool(x: str) -> dict[str, int]:
            ...
        ```

    Anthropic's SDK `transform_schema()` automatically:
    - Adds `additionalProperties: false` to all objects (required by API)
    - Removes unsupported constraints (minLength, pattern, etc.)
    - Moves removed constraints to description field
    - Removes title and $schema fields
    """

    def walk(self) -> JsonSchema:
        schema = super().walk()

        # The caller (pydantic_ai.models._customize_tool_def or _customize_output_object) coalesces
        # - output_object.strict = self.is_strict_compatible
        # - tool_def.strict = self.is_strict_compatible
        # the reason we don't default to `strict=True` is that the transformation could be lossy
        # so in order to change the behavior (default to True), we need to come up with logic that will check for lossiness
        # https://github.com/pydantic/pydantic-ai/issues/3541
        self.is_strict_compatible = self.strict is True  # not compatible when strict is False/None

        if self.strict is True:
            from anthropic import transform_schema

            return transform_schema(schema)
        else:
            return schema

    def _handle_object(self, schema: JsonSchema) -> JsonSchema:
        schema = super()._handle_object(schema)
        if self.strict is True and not _COUNTING_STRICT_SCHEMAS.get():
            additional_properties = schema.get('additionalProperties')
            if isinstance(additional_properties, dict) or additional_properties is True:
                warnings.warn(
                    '`dict` fields are not supported by Anthropic in strict mode '
                    '(including `NativeOutput`, which is automatically selected when thinking is enabled). '
                    "Anthropic's schema transformation sets `additionalProperties` to `false`, "
                    'which forces the model to return `{}`. '
                    'Use a `list` of `tuple[str, str]`, or a `TypedDict` or `dataclass` '
                    'with explicit `key` and `value` fields, '
                    'or set `output_type=PromptedOutput(...)`.',
                    UserWarning,
                )
        return schema

    def transform(self, schema: JsonSchema) -> JsonSchema:
        schema.pop('title', None)
        schema.pop('$schema', None)
        if self.strict is True:
            _const_to_typed_enum(schema)
        return schema


def _const_to_typed_enum(schema: JsonSchema) -> None:
    """Rewrite a scalar `const` as a typed one-value `enum`, which Anthropic's `transform_schema()` keeps.

    Before SDK 2.7.0, `transform_schema()` moves a `const` into the description, leaving the value unconstrained,
    while it keeps an `enum`. Pydantic emits a typed `const` for a single-value `Literal`, such as a discriminator
    field. A described `Enum`, `Choices()` and `BoolCriteria` render their options as `anyOf` of untyped `const`s,
    which get the type of their value, as older SDKs reject a node without a `type`. SDK 2.7.0 and later keep
    the `enum` and drop its redundant `type`; retain this conversion for supported older SDKs.
    """
    const = schema.get('const')
    # `bool` before `int`, which it subclasses.
    if isinstance(const, bool):
        type_ = 'boolean'
    elif isinstance(const, str):
        type_ = 'string'
    elif isinstance(const, int):
        type_ = 'integer'
    elif isinstance(const, float):
        type_ = 'number'
    else:
        return
    del schema['const']
    schema.setdefault('type', type_)
    schema['enum'] = [const]
