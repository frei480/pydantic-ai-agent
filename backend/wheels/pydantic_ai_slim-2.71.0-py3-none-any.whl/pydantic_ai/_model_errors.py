"""Helpers for model adapters to raise the error category a provider error belongs to."""

from __future__ import annotations as _annotations

from collections.abc import Iterator, Mapping
from typing import Protocol, cast

import pydantic_core

from ._utils import is_str_dict
from .exceptions import (
    ModelAPIError,
    ModelAuthenticationError,
    ModelConnectionError,
    ModelContextWindowExceededError,
    ModelHTTPError,
    ModelNotFoundError,
    ModelOverloadedError,
    ModelQuotaExceededError,
    ModelRateLimitError,
    ModelRequestRejectedError,
    ModelServerError,
    ModelTimeoutError,
    ModelUnavailableError,
    TransportPhase,
)

HTTPErrorCategory = type[
    ModelRateLimitError
    | ModelQuotaExceededError
    | ModelUnavailableError
    | ModelServerError
    | ModelTimeoutError
    | ModelRequestRejectedError
]
"""An error category an HTTP error can belong to; see `ModelHTTPError.for_category`."""

_OVERLOADED_PHRASES = ('overloaded', 'over capacity')


def says_overloaded(*texts: object) -> bool:
    """Whether any of a provider's error code, type or message says it's overloaded, e.g. `'overloaded_error'`."""
    return any(
        isinstance(text, str) and any(phrase in text.lower() for phrase in _OVERLOADED_PHRASES) for text in texts
    )


def http_status_category(status_code: int, message: object = None) -> HTTPErrorCategory | None:
    """The error category an HTTP status code implies on its own, without the provider's error code.

    A 503 whose `message` says the provider is overloaded is a `ModelOverloadedError`; any other 503 is only
    unavailable. A 400, 413 or 422 is a `ModelRequestRejectedError`, unless the caller found a more specific category
    in the provider's own error code or message first. A 408 is the provider timing out the attempt, so a
    `ModelTimeoutError`.
    """
    if status_code == 408:
        return ModelTimeoutError
    if status_code in (401, 403):
        return ModelAuthenticationError
    if status_code == 404:
        return ModelNotFoundError
    if status_code in (400, 413, 422):
        return ModelRequestRejectedError
    if status_code == 402:
        return ModelQuotaExceededError
    if status_code == 429:
        return ModelRateLimitError
    if status_code == 529:
        return ModelOverloadedError
    if status_code == 503:
        return ModelOverloadedError if says_overloaded(message) else ModelUnavailableError
    if 500 <= status_code < 600:
        return ModelServerError
    return None


_QUOTA_CODES = (
    'insufficient_quota',
    'billing_hard_limit_reached',
    'credit_balance_exhausted',
    'organization_spend_limit_exceeded',
    'project_spend_limit_exceeded',
    'organization_usage_limit_exceeded',
)
"""OpenAI error codes that say the account's quota, credits or spend limit is exhausted, rather than a rate limit.

OpenAI sends them with a 429, like a rate limit; see https://developers.openai.com/api/docs/guides/error-codes.
"""

_OPENAI_COMPATIBLE_STATUSES: dict[str, int] = {
    'rate_limit_exceeded': 429,
    'rate_limit_error': 429,
    'too_many_requests': 429,
    **dict.fromkeys(_QUOTA_CODES, 429),
    'context_length_exceeded': 400,
    'service_unavailable': 503,
    'service_unavailable_error': 503,
    'server_is_overloaded': 503,
    'overloaded': 503,
    'server_error': 500,
}
"""The HTTP status OpenAI-compatible APIs use for an error, by its `code` or `type`, for errors that come without one."""

_CONTEXT_WINDOW_MESSAGES = (
    'maximum context length',
    'reduce the length of the messages',
    'exceeded max context length',
)
"""How OpenAI-compatible APIs that send no `context_length_exceeded` code word an overflow
(OpenRouter, vLLM, Groq, Ollama Cloud)."""


def openai_compatible_status(code: str | None, error_type: str | None) -> int | None:
    """The HTTP status an OpenAI-compatible API uses for an error it reported without one, e.g. inside a stream."""
    if (
        status := _OPENAI_COMPATIBLE_STATUSES.get(code or '') or _OPENAI_COMPATIBLE_STATUSES.get(error_type or '')
    ) is not None:
        return status
    if code is not None and code.isdigit() and 400 <= int(code) < 600:
        # Gateways like OpenRouter send the HTTP status itself as the `code`.
        return int(code)
    return None


def openai_compatible_category(
    status_code: int | None, code: str | None, error_type: str | None, message: object
) -> HTTPErrorCategory | None:
    """The error category of an error from an OpenAI-compatible API (OpenAI, Groq, OpenRouter), wherever it was sent."""
    if code in _QUOTA_CODES or error_type in _QUOTA_CODES:
        # Exhausted quota is also a 429, but waiting won't help.
        return ModelQuotaExceededError
    if code == 'context_length_exceeded' or (
        isinstance(message, str) and any(m in message.lower() for m in _CONTEXT_WINDOW_MESSAGES)
    ):
        return ModelContextWindowExceededError
    if says_overloaded(code, error_type):
        return ModelOverloadedError
    if code == 'model_not_found':
        # An error inside a stream carries no status, so only the code says what it is.
        return ModelNotFoundError
    if code == 'invalid_api_key':
        return ModelAuthenticationError
    return http_status_category(status_code, message) if status_code is not None else None


def openai_compatible_status_error(
    model_name: str,
    *,
    status_code: int,
    body: object,
    code: str | None,
    error_type: str | None,
    message: object,
    headers: Mapping[str, str],
) -> ModelHTTPError:
    """The error for an OpenAI-compatible API's error status, in the category its `code`, `type` and message name."""
    return ModelHTTPError.for_category(
        openai_compatible_category(status_code, code, error_type, message),
        status_code=status_code,
        model_name=model_name,
        body=body,
        headers=headers,
        provider_error_code=code,
        provider_error_type=error_type,
    )


def openai_error_fields(error: Mapping[str, object]) -> tuple[str | None, str | None]:
    """The `code` and `type` of an OpenAI-compatible API's error object, as `openai` reads them."""
    code, error_type = error.get('code'), error.get('type')
    return str(code) if code is not None else None, error_type if isinstance(error_type, str) else None


def parse_error_body(text: str | None) -> tuple[object, object, dict[str, str]]:
    """Read an error response body that no SDK read, the way the provider SDKs read one.

    Returns `text` parsed as JSON, or `None` when it isn't JSON; its `error` value, which OpenAI-compatible and Google
    APIs send as `{"error": {...}}`, or the parsed object itself when it has no `error`, or `None` when it isn't an
    object; and the string fields of that error object.
    """
    try:
        parsed: object = pydantic_core.from_json(text) if text else None
    except ValueError:
        parsed = None
    error = parsed.get('error', parsed) if is_str_dict(parsed) else None
    fields = {key: value for key, value in error.items() if isinstance(value, str)} if is_str_dict(error) else {}
    return parsed, error, fields


class MultiValueHeaders(Protocol):
    """Response headers that can repeat a name, like `websockets`' `Headers`."""

    def __iter__(self) -> Iterator[str]: ...

    def get_all(self, key: str) -> list[str]: ...


def joined_headers(headers: MultiValueHeaders) -> dict[str, str]:
    """`headers` as a `dict`, with a repeated header's values joined as `httpx` joins them.

    `dict()` of `websockets`' `Headers` raises `MultipleValuesError` on a repeated header, like two `Set-Cookie` lines.
    """
    return {name: ', '.join(headers.get_all(name)) for name in headers}


def openai_compatible_response_error(
    model_name: str, status_code: int, body: str | None, headers: Mapping[str, str]
) -> ModelHTTPError:
    """The error for an OpenAI-compatible error response that no SDK read, like a rejected WebSocket upgrade.

    It gets the category, error code and error type the SDK's error for the same response gets, and keeps `body` as
    the response text. A status below 400 isn't an error response, so it gets no category.
    """
    _, _, fields = parse_error_body(body)
    code, error_type = fields.get('code'), fields.get('type')
    category = openai_compatible_category(status_code, code, error_type, fields.get('message', body))
    return ModelHTTPError.for_category(
        category if status_code >= 400 else None,
        status_code=status_code,
        model_name=model_name,
        body=body,
        headers=headers,
        provider_error_code=code,
        provider_error_type=error_type,
    )


_ZAI_QUOTA_CODES = frozenset(
    {'1113', '1308', '1309', '1310', '1311', '1313', '1314', '1315', '1316', '1317', '1318', '1319', '1320', '1321'}
)
"""Z.ai error codes for an exhausted balance or plan limit, see https://docs.z.ai/api-reference/api-code."""


def zai_code_category(code: str | None) -> HTTPErrorCategory | None:
    """The error category for a Z.ai error code, where it differs from the HTTP status's.

    Z.ai sends an exhausted balance or plan limit with a 429, like its transient `1302` rate limit and `1305` overload,
    so only the code tells them apart.
    """
    return ModelQuotaExceededError if code in _ZAI_QUOTA_CODES else None


def moonshot_type_category(error_type: str | None) -> HTTPErrorCategory | None:
    """The error category for a Moonshot AI error `type`, where it differs from the HTTP status's.

    Moonshot sends an exhausted balance or a suspended account as a 429 with the type `exceeded_current_quota_error`,
    like its `rate_limit_reached_error`, so only the type tells them apart; see
    https://forum.moonshot.ai/t/429-insufficient-balance/244.
    """
    return ModelQuotaExceededError if error_type == 'exceeded_current_quota_error' else None


_GOOGLE_CONTEXT_WINDOW_MESSAGES = ('input token count', 'number of tokens allowed')
"""Gemini reports a context window overflow as `INVALID_ARGUMENT`, identifiable only by its message.

The full message is `The input token count (N) exceeds the maximum number of tokens allowed (M)`; the file-upload
variant drops the leading clause.
"""


def google_error_details(body: object) -> list[dict[str, object]]:
    """The `details` of a Google API error body, like its `google.rpc.ErrorInfo` and `google.rpc.QuotaFailure`."""
    error = body.get('error') if is_str_dict(body) else None
    details = error.get('details') if is_str_dict(error) else None
    if not isinstance(details, list):
        return []
    return [detail for detail in cast(list[object], details) if is_str_dict(detail)]


def google_error_reason(body: object) -> str | None:
    """The `reason` of the `google.rpc.ErrorInfo` in a Google API error body, like `'API_KEY_INVALID'`, if any."""
    for detail in google_error_details(body):
        if isinstance(reason := detail.get('reason'), str):
            return reason
    return None


def google_exceeds_daily_quota(body: object) -> bool:
    """Whether a Google API error body's `google.rpc.QuotaFailure` says a daily quota was exceeded.

    Gemini sends a `RESOURCE_EXHAUSTED` with a violation for each quota the request exceeded, like
    `GenerateRequestsPerMinutePerProjectPerModel-FreeTier` or `GenerateRequestsPerDayPerProjectPerModel-FreeTier`.
    A daily quota resets at midnight Pacific time, see https://ai.google.dev/gemini-api/docs/rate-limits.
    """
    for detail in google_error_details(body):
        violations = detail.get('violations')
        if isinstance(violations, list):
            for violation in cast(list[object], violations):
                if (
                    is_str_dict(violation)
                    and isinstance(quota_id := violation.get('quotaId'), str)
                    and 'PerDay' in quota_id
                ):
                    return True
    return False


def google_retry_after(error: ModelHTTPError) -> float | None:
    """Seconds to wait from `error`'s `google.rpc.RetryInfo` detail, or the `Retry-After` header it already read.

    Gemini reports the wait in the error body rather than a `Retry-After` header, so the body is the fallback: a
    response that carries the header keeps that value. The delay is a protobuf `Duration` string of seconds, like
    `'14s'` or `'0.5s'`; one that's absent, doesn't end in `s`, holds no number before it, or is negative or
    infinite says nothing.
    """
    if error.retry_after is not None:
        return error.retry_after
    for detail in google_error_details(error.body):
        if isinstance(raw := detail.get('retryDelay'), str) and raw.endswith('s'):
            try:
                seconds = float(raw[:-1])
            except ValueError:
                continue
            if 0 <= seconds < float('inf'):
                return seconds
    return None


def google_status_category(status: str | None, message: object, body: object) -> HTTPErrorCategory | None:
    """The error category for a Google API error status, like `RESOURCE_EXHAUSTED`, and the error `body`'s details.

    Gemini sends `RESOURCE_EXHAUSTED` for both per-minute rate limits and the daily quota, with the same message, so
    only the quotas listed in the body's `google.rpc.QuotaFailure` tell them apart; without them, it's a rate limit.
    It sends an invalid API key as `INVALID_ARGUMENT`, with the `reason` `API_KEY_INVALID`.
    """
    if google_error_reason(body) == 'API_KEY_INVALID':
        return ModelAuthenticationError
    match status:
        case 'RESOURCE_EXHAUSTED':
            # The daily quota doesn't reset until midnight Pacific time, so waiting won't help.
            return ModelQuotaExceededError if google_exceeds_daily_quota(body) else ModelRateLimitError
        case 'FAILED_PRECONDITION' if isinstance(message, str) and 'billing' in message.lower():
            # Like `Gemini API free tier is not available in your country. Please enable billing on your project in
            # Google AI Studio.`; other preconditions, like `User location is not supported`, are rejected requests.
            return ModelQuotaExceededError
        case 'UNAVAILABLE':
            # Like `The model is overloaded. Please try again later.`
            return ModelOverloadedError if says_overloaded(message) else ModelUnavailableError
        case 'INTERNAL':
            return ModelServerError
        case 'INVALID_ARGUMENT' if isinstance(message, str) and any(
            m in message.lower() for m in _GOOGLE_CONTEXT_WINDOW_MESSAGES
        ):
            return ModelContextWindowExceededError
        case 'INVALID_ARGUMENT':
            return ModelRequestRejectedError
        case 'UNAUTHENTICATED' | 'PERMISSION_DENIED':
            return ModelAuthenticationError
        case 'NOT_FOUND':
            return ModelNotFoundError
        case _:
            return None


def google_status_error(
    model_name: str,
    *,
    status_code: int,
    status: str | None,
    message: str | None,
    body: object,
    headers: Mapping[str, str] | None,
    suggested_model_id: str | None = None,
    in_stream: bool = False,
) -> ModelHTTPError:
    """The error for a Google API error response, in the category its `status` and `body`'s details name.

    Its `retry_after` falls back to the body's `google.rpc.RetryInfo`.
    """
    error = ModelHTTPError.for_category(
        google_status_category(status, message, body) or http_status_category(status_code, message),
        status_code=status_code,
        model_name=model_name,
        body=body,
        headers=headers,
        suggested_model_id=suggested_model_id,
        provider_error_code=status,
        in_stream=in_stream,
    )
    error.retry_after = google_retry_after(error)
    return error


_BEDROCK_CONTEXT_WINDOW_MESSAGES = ('input is too long', 'input tokens exceeded', 'prompt is too long')
"""Bedrock reports a context window overflow as a `ValidationException`, identifiable only by its message."""


def bedrock_code_category(code: str | None, message: object) -> HTTPErrorCategory | None:
    """The error category for a Bedrock error code, which is capitalized in an HTTP error and not in a stream."""
    match code and code.lower():
        case 'throttlingexception':
            return ModelRateLimitError
        case 'servicequotaexceededexception':
            return ModelQuotaExceededError
        case 'modelstreamerrorexception':
            # The model failed while streaming its response; Bedrock says to retry the request.
            return ModelServerError
        case 'modeltimeoutexception':
            return ModelTimeoutError
        case 'serviceunavailableexception' | 'modelnotreadyexception':
            return ModelOverloadedError if says_overloaded(message) else ModelUnavailableError
        case 'mpagreementbeingcreated':
            # A 403 while the account's AWS Marketplace subscription to the model is still being processed; AWS says
            # to try again after 15 minutes, so it's not a permanent authorization failure.
            # https://docs.aws.amazon.com/bedrock/latest/userguide/troubleshooting-api-error-codes.html#ts-mp-agreement-created
            return ModelUnavailableError
        case 'validationexception' if isinstance(message, str) and any(
            m in message.lower() for m in _BEDROCK_CONTEXT_WINDOW_MESSAGES
        ):
            return ModelContextWindowExceededError
        case (
            'accessdeniedexception'
            | 'unrecognizedclientexception'
            | 'invalidsignatureexception'
            | 'expiredtokenexception'
            | 'expiredtoken'
        ):
            return ModelAuthenticationError
        case 'resourcenotfoundexception':
            return ModelNotFoundError
        case _:
            return None


def stream_error(model_name: str, message: str, body: object) -> ModelAPIError:
    """Map an error object sent inside a 200 stream by an OpenAI-compatible API, classified by its `code` or `type`.

    It gets the status and category the same error has before a stream opens, so it's handled the same way whether
    or not the request was streamed, with `in_stream` set. An error with no clear status isn't a `ModelHTTPError`.
    """
    code = body.get('code') if is_str_dict(body) else None
    error_type = body.get('type') if is_str_dict(body) else None
    code = str(code) if isinstance(code, str | int) else None
    error_type = error_type if isinstance(error_type, str) else None
    status_code = openai_compatible_status(code, error_type)
    category = openai_compatible_category(status_code, code, error_type, message)
    if status_code is None:
        return (category or ModelAPIError)(
            model_name=model_name,
            message=message,
            body=body,
            provider_error_code=code,
            provider_error_type=error_type,
            in_stream=True,
        )
    return ModelHTTPError.for_category(
        category,
        status_code=status_code,
        model_name=model_name,
        body=body,
        provider_error_code=code,
        provider_error_type=error_type,
        in_stream=True,
    )


_HTTPX_PHASES: dict[str, TransportPhase] = {
    'PoolTimeout': 'pool',
    'ConnectTimeout': 'connect',
    'ConnectError': 'connect',
    'WriteTimeout': 'write',
    'WriteError': 'write',
    'ReadTimeout': 'read',
    'ReadError': 'read',
    'RemoteProtocolError': 'read',
}

_TRANSPORT_PHASES: dict[tuple[str, str], TransportPhase] = {
    # `httpx` and `httpx2` share their exception names.
    **{(package, name): phase for package in ('httpx', 'httpx2') for name, phase in _HTTPX_PHASES.items()},
    ('botocore', 'ConnectTimeoutError'): 'connect',
    ('botocore', 'EndpointConnectionError'): 'connect',
    ('botocore', 'ReadTimeoutError'): 'read',
    ('botocore', 'ResponseStreamingError'): 'read',
    # botocore reads an event stream straight from urllib3, so these only reach us while reading a response.
    ('urllib3', 'ReadTimeoutError'): 'read',
    ('urllib3', 'ProtocolError'): 'read',
}
"""Transport exceptions whose stage of the request is known, by top-level package and class name.

Matched by name so the HTTP libraries an adapter doesn't use needn't be importable.
"""


def transport_phase(error: BaseException) -> TransportPhase | None:
    """The stage of the request at which a transport error happened, from it or the exceptions it was raised from.

    SDKs like `openai` and `anthropic` wrap the HTTP library's exception, keeping it as `__cause__`.
    """
    seen: set[int] = set()
    current: BaseException | None = error
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        for cls in type(current).__mro__:
            if (phase := _TRANSPORT_PHASES.get((cls.__module__.partition('.')[0], cls.__name__))) is not None:
                return phase
        current = current.__cause__
    return None


def connection_error(model_name: str, message: str, error: BaseException, *, timeout: bool) -> ModelConnectionError:
    """A `ModelConnectionError` (or `ModelTimeoutError`) for a transport `error`, with its phase if known."""
    error_class = ModelTimeoutError if timeout else ModelConnectionError
    return error_class(model_name=model_name, message=message, phase=transport_phase(error))


class HTTPStatusResponse(Protocol):
    """The parts of an `httpx` or `httpx2` response that `transport_status_error` reads."""

    @property
    def status_code(self) -> int: ...

    @property
    def headers(self) -> Mapping[str, str]: ...

    @property
    def content(self) -> bytes: ...


def transport_error_body(response: HTTPStatusResponse) -> tuple[object, dict[str, object], str]:
    """Read the body of an error status the HTTP transport raised before the provider SDK saw the response.

    A retrying transport's `validate_response` raises `HTTPStatusError` for a status it retries, and re-raises it
    once it runs out of attempts. Most SDKs let that exception through unchanged, and `anthropic` and `groq` wrap it
    in their connection error, though the provider did respond.

    Returns the body, parsed as JSON, or its text when it isn't JSON or is `null`, or `None` when it's empty or the
    transport closed the response without reading it; the error object in it, which most APIs wrap as
    `{"error": {...}}`, or the body itself when it holds no `error`, or `{}` when it isn't an object; and the body's
    text.
    """
    try:
        content = response.content
    except RuntimeError:  # `ResponseNotRead`: the transport closed the response without reading its body.
        content = b''
    text = content.decode(errors='replace')
    parsed, error, _ = parse_error_body(text)
    return parsed if parsed is not None else text or None, error if is_str_dict(error) else {}, text


def transport_status_error(model_name: str, response: HTTPStatusResponse) -> ModelHTTPError:
    """The `ModelHTTPError` for an error status the HTTP transport raised, by its status and body text alone.

    See `transport_error_body` for when the transport raises it.
    """
    body, _, text = transport_error_body(response)
    return ModelHTTPError.for_category(
        http_status_category(response.status_code, text),
        status_code=response.status_code,
        model_name=model_name,
        body=body,
        headers=dict(response.headers),
    )


def google_transport_error_fields(response: HTTPStatusResponse) -> tuple[object, str | None, str]:
    """The body, Google API `status` and message of an error status the HTTP transport raised.

    They're read as `google.genai` reads them, which takes the text of a body that isn't JSON as the message. See
    `transport_error_body` for when the transport raises it.
    """
    body, error, text = transport_error_body(response)
    status, message = error.get('status'), error.get('message')
    return body, status if isinstance(status, str) else None, message if isinstance(message, str) else text


def google_transport_status_error(model_name: str, response: HTTPStatusResponse) -> ModelHTTPError:
    """The `google_status_error` for an error status the HTTP transport raised, from `google_transport_error_fields`."""
    body, status, message = google_transport_error_fields(response)
    return google_status_error(
        model_name,
        status_code=response.status_code,
        status=status,
        message=message,
        body=body,
        headers=dict(response.headers),
    )
