"""Settings for realtime model sessions, mirroring [`pydantic_ai.settings`][pydantic_ai.settings]."""

from __future__ import annotations as _annotations

from typing import Literal

from typing_extensions import TypeAliasType, TypedDict

from ..settings import ThinkingLevel, ToolChoice

AudioRetention = TypeAliasType('AudioRetention', Literal['transcript_only', 'input_audio', 'output_audio', 'all'])
"""How much audio a [`RealtimeSession`][pydantic_ai.realtime.RealtimeSession] retains in its history.

Values other than `'transcript_only'` are additive: transcripts are always kept, and the named audio is
retained alongside them.

- `'transcript_only'` (default): keep only transcripts; drop all audio bytes.
- `'input_audio'`: also retain the user's spoken audio.
- `'output_audio'`: also retain the model's spoken audio.
- `'all'`: retain both sides' audio.

Retained audio is stored on the [`SpeechPart`][pydantic_ai.messages.SpeechPart]'s `audio` as WAV
[`BinaryContent`][pydantic_ai.messages.BinaryContent]. Live audio deltas remain raw PCM. Retained
input audio is split only at boundaries the provider reports. OpenAI, Azure, and xAI report the end
of each detected speech segment, so each user part normally contains audio sent since the preceding
speech-end boundary through the current one. This can include inter-turn microphone input. Gemini
does not report speech-end boundaries, so its user part contains everything sent since the preceding
response completed through the current response completion, including silence sent while the model
is responding. Retention records the microphone stream only; it does not mix the model's output audio
into the user's part unless that output is present in the microphone input itself.

How much retained audio a session keeps is bounded by `retain_audio_max_seconds` on
[`AgentRealtime.session`][pydantic_ai.agent.AgentRealtime.session]; the oldest is evicted first, keeping
its transcript.
"""


class TurnDetection(TypedDict, total=False):
    """Cross-provider automatic voice-activity detection (VAD) knobs.

    Set as [`RealtimeModelSettings.turn_detection`][pydantic_ai.realtime.RealtimeModelSettings] to turn
    automatic detection on with these settings. (Pass `True` for the provider defaults, or `False` to
    disable it entirely for push-to-talk.) Each field maps to the closest knob on each provider; for
    finer, provider-specific control use the provider-prefixed escape hatch (`openai_turn_detection`,
    `xai_turn_detection`, `google_vad`), which fully overrides this when set.
    """

    sensitivity: Literal['low', 'medium', 'high']
    """How readily the provider detects turn boundaries (speech start/end). Higher is snappier but more
    prone to false triggers. Defaults to the provider default. Maps per provider: **OpenAI / Azure / xAI** → server-VAD `threshold`
    (`low`≈0.7, `medium`≈0.5, `high`≈0.3); **Gemini** → both start and end sensitivity (`low`→`low`,
    `high`→`high`, `medium` leaves the provider default); **Eleven Realtime** → semantic-VAD `eagerness`."""

    prefix_padding_ms: int
    """Audio retained before detected speech onset, in milliseconds. Honored by OpenAI, xAI, Gemini, and
    Eleven Realtime. Defaults to the provider default."""

    silence_duration_ms: int
    """Silence required to mark the end of speech, in milliseconds. Honored by OpenAI, xAI, Gemini, and
    Eleven Realtime. Defaults to the provider default."""


class RealtimeModelSettings(TypedDict, total=False):
    """Settings to configure a realtime model session.

    Defines the common settings vocabulary used across realtime model providers. A provider treats a
    setting it can't apply as a [standard model](../agent.md#model-run-settings) does: tuning knobs like
    `max_tokens` are ignored silently, so the same settings work across providers;
    `parallel_tool_calls=False` emits an [`UnsupportedSettingWarning`][pydantic_ai.exceptions.UnsupportedSettingWarning];
    and a `tool_choice` that forces a tool call raises [`UserError`][pydantic_ai.exceptions.UserError] before
    connecting. A few settings a provider can't honor raise too: see each field's docs and the
    [provider pages](../realtime/overview.md#provider-support).
    Providers with additional generation parameters extend it, e.g.
    [`GoogleRealtimeModelSettings`][pydantic_ai.realtime.google.GoogleRealtimeModelSettings].
    """

    max_tokens: int
    """The maximum number of tokens to generate per response before stopping.

    Supported by: OpenAI, Azure OpenAI, Gemini, and Eleven Realtime. xAI accepts it but ignores it, and
    OpenAI GPT-Live and ElevenLabs Agents ignore it too.
    """

    parallel_tool_calls: bool
    """Whether to allow parallel tool calls.

    Supported by: OpenAI, Azure OpenAI, Azure AI Voice Live (where `True` leaves the model's default,
    since some models can't call tools in parallel), and OpenAI GPT-Live, where it applies to the
    delegated backend unless `openai_live_delegation` sets its own `parallel_tool_calls`. xAI accepts it
    but ignores it, and Gemini, Eleven Realtime, and ElevenLabs Agents ignore it too: on those, `False` with
    function tools emits an [`UnsupportedSettingWarning`][pydantic_ai.exceptions.UnsupportedSettingWarning], as
    on a standard model.
    """

    async_tool_calls: bool | None
    """Whether the model keeps the conversation going while a tool call runs. `None` (the default) leaves it to the model.

    With async tool calls, the model can keep speaking (typically saying what it's doing) and answer the
    user while a tool runs, and the result reaches it when it's ready. Without them, the model goes quiet
    until the result is back. This pays off for tools that take a noticeable moment; see
    [Concurrent tool execution](../realtime/tools.md#concurrent-tool-execution) for the tradeoffs.

    Only models whose profile's
    [`async_tool_call_mode`][pydantic_ai.realtime.RealtimeModelProfile.async_tool_call_mode] is
    `'optional'` offer a choice, and every one of them defaults to off. The others ignore this setting,
    since they either always or never run tool calls asynchronously. A model that always does warns about an
    ignored `False` (with function tools) with an
    [`UnsupportedSettingWarning`][pydantic_ai.exceptions.UnsupportedSettingWarning], as a standard model does
    for a guarantee it can't keep.

    Supported by: the Gemini native-audio models and `gemini-3.8-live`.
    """

    tool_choice: ToolChoice
    """Control which function tools the model can use.

    See the [Tool Choice guide](../tools-advanced.md#tool-choice) for detailed documentation. Every
    form is resolved exactly as it is for a standard run, including the error a name that matches no
    tool raises; a session has no output tools, so
    [`ToolOrOutput`][pydantic_ai.settings.ToolOrOutput] restricts the function tools while leaving the
    model free to just speak.

    It is applied once, when the session is created, and holds for every response. `'none'` and
    function-tool allow-lists are enforced on every provider by restricting the tools advertised to the
    model. Every provider raises [`UserError`][pydantic_ai.exceptions.UserError] before connecting for a
    choice that forces a tool call (`'required'` or a list of tool names): applied to every response,
    including the one after a tool result, it would never let the model answer, and Gemini can't express
    it at all. Use `ToolOrOutput` to restrict the tools instead. ElevenLabs Agents restricts a hosted
    agent's attached tools through its toggle-gated `tool_ids` conversation override.

    Supported by: OpenAI, Azure OpenAI, Gemini, xAI, Eleven Realtime, ElevenLabs Agents, and OpenAI GPT-Live,
    for `'auto'`, `'none'`, and `ToolOrOutput` restrictions.
    """

    input_transcription_model: KnownRealtimeTranscriptionModelName | str | None
    """Model used to transcribe the user's audio input, so their turns are captured into history.

    `'auto'` (the default) uses the provider's recommended realtime transcription model; pass a
    specific id (e.g. `'gpt-live-transcribe'`) to pin one, or `None` to disable transcription (see
    `audio_retention` to retain the raw audio instead).

    `None` turns transcription off on every provider that can disable it. OpenAI GPT-Live, Eleven Realtime,
    and ElevenLabs Agents always transcribe, so on them `None` leaves transcription on.
    A *pinned* id applies only to the providers that
    transcribe with a separate model, and the others ignore it, as a standard model ignores a tuning knob it
    doesn't support: Gemini transcribes natively (`google_input_transcription` configures its own
    transcription), and OpenAI GPT-Live, Eleven Realtime, and ElevenLabs Agents transcribe with their own model.

    Supported by: OpenAI, Azure OpenAI, Gemini (`None` only), and xAI.
    """

    output_modality: Literal['audio', 'text']
    """The single modality generated by the model. Defaults to `'audio'`, or to `'text'` for a model whose
    profile reports [`supports_audio_output=False`][pydantic_ai.realtime.RealtimeModelProfile.supports_audio_output].

    Unlike most settings here, an unsupported value is *not* silently ignored: a model whose
    profile reports [`supports_text_output=False`][pydantic_ai.realtime.RealtimeModelProfile.supports_text_output]
    (or `supports_audio_output=False`, for `'audio'`) raises [`UserError`][pydantic_ai.exceptions.UserError]
    before connecting, because a session that quietly spoke instead of writing would be worse than one that
    didn't start.

    Text is supported by: OpenAI, Azure OpenAI, Vertex AI's half-cascade `gemini-live-2.5-flash`, Gemini's
    text-only `gemini-robotics-er-*` streaming models, and ElevenLabs Agents (via the hosted agent's
    toggle-gated `conversation.text_only` override). The other Gemini Live models and xAI always generate
    audio: read the spoken answer from the transcript on the [`SpeechPart`][pydantic_ai.messages.SpeechPart]
    instead.
    """

    output_speech_timestamps: bool
    """Whether to report when each piece of the model's speech is heard in its audio, so an application can line
    the text up with playback (for example, to reveal words as they are spoken). Defaults to `False`.

    When on, the timestamps stream as [`SpeechPartDelta.timestamps`][pydantic_ai.messages.SpeechPartDelta.timestamps]
    and are recorded on the [`SpeechPart`][pydantic_ai.messages.SpeechPart] in history. How fine they are is the
    model profile's
    [`output_speech_timestamp_granularity`][pydantic_ai.realtime.RealtimeModelProfile.output_speech_timestamp_granularity];
    a model that reports none emits an [`UnsupportedSettingWarning`][pydantic_ai.exceptions.UnsupportedSettingWarning]
    when the session opens.

    Supported by: Azure AI Voice Live (per word, with an Azure voice), ElevenLabs Agents (per word), and xAI Grok
    Voice (per segment).
    """

    thinking: ThinkingLevel
    """Enable or configure reasoning/thinking, mirroring the unified
    [`thinking`][pydantic_ai.settings.ModelSettings.thinking] setting on the request-response models.

    `True` enables it at effort `'medium'` on OpenAI (including GPT-Live's backend), Azure OpenAI, and
    Azure AI Voice Live, at the closest supported thinking level to `'medium'` on Gemini, and at `'high'`,
    its only enabled effort, on xAI. `'minimal'`/`'low'`/`'medium'`/`'high'`/`'xhigh'`/`'max'` selects an
    effort level. `False` disables thinking (sent as effort `'none'` on OpenAI, Azure OpenAI, Azure AI
    Voice Live, and xAI).
    OpenAI and Gemini apply it only to models whose profile reports
    [`supports_thinking`][pydantic_ai.realtime.RealtimeModelProfile.supports_thinking]. Other models
    silently ignore it. Providers with a richer native config expose it separately
    (e.g. Gemini's `google_thinking_config`), which takes precedence.

    Supported by: OpenAI `gpt-realtime-2*` models (also on Azure), reasoning chat models like `gpt-5`
    on Azure AI Voice Live, the Gemini Live models except Vertex AI's `gemini-live-2.5-flash` and
    `gemini-3.8-live` (its `gemini-3.8-live-extended-thinking` variant always thinks), xAI's reasoning Grok
    Voice models (`grok-voice-latest` and the `grok-voice-think-*` family), and OpenAI GPT-Live, where it
    sets the reasoning effort of the delegated backend model if that model reasons, unless
    `openai_live_delegation` sets its own `reasoning_effort`.
    """

    turn_detection: bool | TurnDetection
    """Automatic voice-activity detection (VAD) / turn-taking. Modeled on
    [`thinking`][pydantic_ai.settings.ModelSettings.thinking]:

    - Absent (the default) or `True`: automatic turn detection on, at the provider's defaults.
    - `False`: disable it — push-to-talk, drive turns manually with `commit_audio()` /
      `create_response()` (only on providers whose [model profile](#model-profile) reports
      `supports_manual_turn_control`).
    - [`TurnDetection`][pydantic_ai.realtime.TurnDetection]: on, with specific cross-provider knobs.

    For finer, provider-specific control use the provider-prefixed setting documented on each provider's
    settings type (`openai_turn_detection`, `xai_turn_detection`, `google_vad`); when present it fully
    overrides this field.

    OpenAI GPT-Live and ElevenLabs Agents own turn-taking server-side: they ignore the `TurnDetection`
    knobs, and raise [`UserError`][pydantic_ai.exceptions.UserError] for `False`, as Gemini does.
    """

    handshake_timeout: float
    """Seconds to wait for the realtime protocol handshake to complete. Defaults to `30.0`.

    On OpenAI, Azure OpenAI, xAI, and Eleven Realtime this bounds the wait for each handshake event; on Gemini it
    bounds opening the socket and waiting for the session setup to complete; on ElevenLabs Agents it bounds the wait
    for the conversation initiation metadata.

    Supported by: OpenAI, Azure OpenAI, Gemini, xAI, Eleven Realtime, and ElevenLabs Agents.
    """

    reconnect: ReconnectPolicy
    """[`ReconnectPolicy`][pydantic_ai.realtime.ReconnectPolicy] to transparently recover from a
    dropped connection. Without a policy, an unexpectedly closed connection is fatal: the low-level
    connection reports a non-recoverable session error and `RealtimeSession` raises
    [`RealtimeError`][pydantic_ai.realtime.RealtimeError] from iteration.

    What server-side state survives a reconnect depends on the provider (see
    [`ReconnectPolicy`][pydantic_ai.realtime.ReconnectPolicy]). Setting a policy enables Gemini's
    native session resumption unless `google_enable_session_resumption=False` is set explicitly — that
    combination raises
    [`UserError`][pydantic_ai.exceptions.UserError] at connect time, since a re-dial without
    resumption would lose the conversation.

    Supported by: OpenAI, Azure OpenAI, Gemini, xAI, Eleven Realtime, and OpenAI GPT-Live, which forks a session stored
    with `openai_live_store=True` and otherwise replays the local history into a new one. ElevenLabs Agents
    can't resume a conversation, so it ignores a policy with an
    [`UnsupportedSettingWarning`][pydantic_ai.exceptions.UnsupportedSettingWarning], and a drop ends the session.
    """


RealtimeModelSettingName = TypeAliasType(
    'RealtimeModelSettingName',
    Literal[
        'max_tokens',
        'parallel_tool_calls',
        'async_tool_calls',
        'tool_choice',
        'input_transcription_model',
        'output_modality',
        'output_speech_timestamps',
        'thinking',
        'turn_detection',
        'handshake_timeout',
        'reconnect',
    ],
)
"""The names of the [`RealtimeModelSettings`][pydantic_ai.realtime.RealtimeModelSettings] fields, as
[`ModelSettingName`][pydantic_ai.settings.ModelSettingName] is for `ModelSettings`."""


KnownRealtimeTranscriptionModelName = TypeAliasType(
    'KnownRealtimeTranscriptionModelName',
    Literal[
        'auto',
        'whisper-1',
        'gpt-4o-transcribe',
        'gpt-4o-mini-transcribe',
        'gpt-realtime-whisper',
        'gpt-live-transcribe',
        'gpt-transcribe',
        'grok-transcribe',
        'azure-speech',
        'mai-transcribe',
    ],
)
"""Known values for the OpenAI-protocol models' `input_transcription_model`, pinned by a provider sync test.

`'auto'` is the sentinel that resolves to the provider's recommended transcription model; the rest are
concrete model ids. The values span providers, so an id valid for one provider (e.g. `'grok-transcribe'`
for xAI) is rejected by another at connect time. The field also accepts any other `str`, so a newer id
not listed here still works — this is just an autocomplete aid, like
[`KnownModelName`][pydantic_ai.models.KnownModelName].
"""


class ReconnectPolicy(TypedDict, total=False):
    """How to recover when a realtime connection drops mid-session.

    Set as the `reconnect` key of [`RealtimeModelSettings`][pydantic_ai.realtime.RealtimeModelSettings],
    either as a model-level default (`settings=`) or per session (`model_settings=`).

    On a dropped connection the session is re-dialed and its configuration (instructions, tools,
    voice, ...) re-applied, emitting a
    [`RealtimeSessionReconnectEvent`][pydantic_ai.realtime.RealtimeSessionReconnectEvent] event. What server-side state
    survives depends on the provider: OpenAI Realtime, Azure OpenAI and xAI Grok Voice have the session
    replay its finalized message history into the new connection (prior turns survive; buffered input
    audio and a reply in flight do not), while Gemini Live restores prior turns through native session
    resumption, enabled automatically whenever a reconnect policy is set
    (Gemini honors an explicit `google_enable_session_resumption=False` opt-out by refusing the
    combination with a [`UserError`][pydantic_ai.exceptions.UserError]).
    """

    max_attempts: int
    """Number of re-dial attempts per drop before giving up and raising
    [`RealtimeError`][pydantic_ai.realtime.RealtimeError]. Defaults to `3`."""
    max_reconnects: int
    """Total successful reconnects allowed for the life of the session.

    `max_attempts` bounds the retries for a single drop, and resets once a dial succeeds, so on its
    own it cannot stop a session that reconnects, drops, and reconnects forever. This bounds the whole
    session instead.

    The default is generous for the case this exists to serve: providers end sessions at a duration
    cap (OpenAI at 60 minutes) and a long-running session legitimately renews at that boundary, so 50
    covers days of continuous conversation. It only bites a server that hangs up as fast as we dial.
    Defaults to `50`.
    """
    base_delay: float
    """Base backoff delay in seconds; doubles each attempt up to `max_delay`. Defaults to `0.5`."""
    max_delay: float
    """Maximum backoff delay in seconds. Defaults to `30.0`."""
    jitter: bool
    """Whether to apply random jitter to each backoff delay to avoid thundering herds. Defaults to `True`."""
