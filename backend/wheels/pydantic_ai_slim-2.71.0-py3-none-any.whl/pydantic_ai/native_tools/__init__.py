from __future__ import annotations as _annotations

import warnings
from abc import ABC
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from types import MemberDescriptorType
from typing import Annotated, Any, Literal, Union

import pydantic
from pydantic_core import core_schema
from typing_extensions import TypedDict

from pydantic_ai._warnings import (
    PydanticAIDeprecationWarning,
    provider_field_warnings_suppressed,
    suppress_provider_field_warnings,
)
from pydantic_ai.exceptions import UserError
from pydantic_ai.messages import UploadedFile

__all__ = (
    'AbstractNativeTool',
    'AnthropicWebSearchToolSettings',
    'OpenRouterWebSearchToolSettings',
    'WebSearchProviderSettings',
    'WebSearchTool',
    'WebSearchUserLocation',
    'XSearchTool',
    'CodeExecutionTool',
    'AnthropicWebFetchToolSettings',
    'WebFetchProviderSettings',
    'WebFetchTool',
    'ImageGenerationModelName',
    'OpenAIImageGenerationToolSettings',
    'ImageGenerationProviderSettings',
    'ImageGenerationTool',
    'ImageAspectRatio',
    'ImageSize',
    'ImageQuality',
    'MemoryTool',
    'MCPServerTool',
    'XaiFileSearchToolSettings',
    'FileSearchProviderSettings',
    'FileSearchTool',
    'AdvisorModelName',
    'AnthropicAdvisorToolSettings',
    'OpenRouterAdvisorToolSettings',
    'AdvisorProviderSettings',
    'AdvisorTool',
    'NATIVE_TOOL_TYPES',
    'SUPPORTED_NATIVE_TOOLS',
    'NATIVE_TOOLS_REQUIRING_CONFIG',
)

NATIVE_TOOL_TYPES: dict[str, type[AbstractNativeTool]] = {}
"""Registry of all native tool types, keyed by their kind string.

This dict is populated automatically via `__init_subclass__` when tool classes are defined.
"""


def _validate_without_provider_field_warnings(value: Any, handler: core_schema.ValidatorFunctionWrapHandler) -> Any:
    """Stay quiet when a tool is rebuilt from data, as durable execution does between activities.

    The tool may come from a capability, whose user has nothing to change, and the warning would point into pydantic.
    """
    with suppress_provider_field_warnings():
        return handler(value)


def _moved_to_provider_settings(system: str, name: str) -> Any:
    """Mark a field moved into `provider_settings` as deprecated in the JSON schema, for spec authors' editors."""
    return pydantic.Field(deprecated=f'Use `provider_settings={{"{system}": {{"{name}": ...}}}}` instead.')


def _check_moved_fields(
    tool: AbstractNativeTool,
    system: str,
    nested: Mapping[str, object],
    moved_fields: Mapping[str, tuple[object, object]],
) -> None:
    """Reject moved fields that disagree with `provider_settings`, and warn about the ones that are set.

    `moved_fields` maps each deprecated field to its value and its default. The warning's `stacklevel` points at
    whoever constructs the tool, through `__init__` and `__post_init__`.
    """
    set_fields = {name: value for name, (value, default) in moved_fields.items() if value != default}
    for name, value in set_fields.items():
        if name in nested and nested[name] != value:
            raise UserError(
                f'`{type(tool).__name__}` field `{name}` conflicts with `provider_settings["{system}"]["{name}"]`; '
                'set only `provider_settings`.'
            )
    if not set_fields or provider_field_warnings_suppressed.get():
        return

    formatted_fields = ', '.join(f'`{name}`' for name in set_fields)
    label, verb = ('field', 'is') if len(set_fields) == 1 else ('fields', 'are')
    warnings.warn(
        f'`{type(tool).__name__}` {label} {formatted_fields} {verb} deprecated and will be removed in v3; '
        f'use `provider_settings={{"{system}": {{...}}}}` instead.',
        PydanticAIDeprecationWarning,
        stacklevel=4,
    )


ImageAspectRatio = Literal['21:9', '16:9', '4:3', '3:2', '1:1', '9:16', '3:4', '2:3', '5:4', '4:5']
"""Supported aspect ratios for image generation tools.

The direct image API takes the wider
[`ImageGenerationAspectRatio`][pydantic_ai.images.ImageGenerationAspectRatio], of which these ten are a subset.
"""

ImageSize = Literal['auto', '1024x1024', '1024x1536', '1536x1024', '512', '1K', '2K', '4K']
"""Supported sizes for image generation tools."""

ImageQuality = Literal['low', 'medium', 'high', 'xhigh', 'max', 'auto']
"""Supported quality settings for OpenAI image generation."""

ImageGenerationModelName = (
    Literal[
        'gpt-image-2.6-flare',
        'gpt-image-2.6-sunburst',
        'gpt-image-2',
        'gpt-image-1.5',
        'gpt-image-1-mini',
    ]
    | str
)
"""Known OpenAI image generation model names, or another OpenAI image model ID."""

AdvisorModelName = (
    Literal[
        'claude-fable-5-2',
        'claude-opus-5-5',
        'claude-sonnet-5-5',
        'claude-haiku-5-5',
        'claude-opus-4-8',
        'claude-sonnet-4-6',
    ]
    | str
)
"""Known Anthropic advisor model names, or any other model ID string.

The literals list the latest models Anthropic accepts as the *advisor* — the stronger model an
executor consults mid-generation. The executor/advisor pairing is validated by the API, not here.
The literals are Anthropic model IDs; on OpenRouter, pass a catalog slug string instead
(e.g. `anthropic/claude-opus-4.8` or the `~anthropic/claude-opus-latest` alias).
See [Anthropic's model compatibility list](https://platform.claude.com/docs/en/agents-and-tools/tool-use/advisor-tool#model-compatibility).
"""


@dataclass(kw_only=True)
class AbstractNativeTool(ABC):
    """A native tool that can be used by an agent.

    This class is abstract and cannot be instantiated directly.

    The native tools are passed to the model as part of the `ModelRequestParameters`.
    """

    kind: str = 'unknown_native_tool'
    """Native tool identifier, this should be available on all native tools as a discriminator."""

    optional: bool = False
    """Whether this instance is a best-effort upgrade rather than a hard requirement.

    When `True`, the instance is silently dropped from the request on a model that doesn't
    support it natively, instead of raising when no local fallback is provided. Use for
    native tools where a fallback path exists (e.g. a local function tool that takes over when
    the native one isn't available). When `False` (the default), the request errors on
    models that can't honor the native tool — the user explicitly asked for it, so fail loudly
    rather than silently substituting different behavior.
    """

    @property
    def unique_id(self) -> str:
        """A unique identifier for the native tool.

        If multiple instances of the same native tool can be passed to the model, subclasses should override this property to allow them to be distinguished.
        """
        return self.kind

    @property
    def label(self) -> str:
        """Human-readable label for UI display.

        Subclasses should override this to provide a meaningful label.
        """
        return self.kind.replace('_', ' ').title()

    @property
    def restricting_settings(self) -> frozenset[str]:
        """The names of the settings set on this instance that narrow what the tool may do.

        These are settings such as domain filters and usage limits, which are usually there for compliance or
        cost reasons. A model that can't apply one of them treats this instance as unsupported, so the request
        uses the local fallback when one is provided, leaves the tool out when it is `optional`, and raises
        [`UserError`][pydantic_ai.exceptions.UserError] otherwise. Settings that only tune results, such as a
        search context size, are not included.

        Models report which of these they can't apply via
        [`Model.unsupported_native_tool_settings`][pydantic_ai.models.Model.unsupported_native_tool_settings].
        """
        return frozenset()

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        NATIVE_TOOL_TYPES[cls._declared_kind()] = cls

    @classmethod
    def _declared_kind(cls) -> str:
        kind = cls.kind
        if isinstance(kind, MemberDescriptorType):
            # `@dataclass(slots=True)` recreates the class, re-running `__init_subclass__` with `kind` turned into a
            # slot, so the kind is the field's default.
            return cls.__dataclass_fields__['kind'].default
        return kind

    @classmethod
    def __get_pydantic_core_schema__(
        cls, _source_type: Any, handler: pydantic.GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        if cls is not AbstractNativeTool:
            return core_schema.no_info_wrap_validator_function(_validate_without_provider_field_warnings, handler(cls))

        # A snapshot: a type registering on another thread would change the registry mid-iteration.
        tools = tuple(NATIVE_TOOL_TYPES.values())
        if len(tools) == 1:  # pragma: no cover
            tools_type = next(iter(tools))
        else:
            # The discriminator is a function, so the union's JSON schema is a `oneOf` with no mapping, and each
            # tool's `kind` is a plain string with a default. Pinning `kind` keeps `{'kind': 'code_execution'}` from
            # matching several members; it's required because a document without one loads as no built-in tool.
            # `kind=tool._declared_kind()` binds each member's own kind: a closure would see only the last one.
            tools_annotated = [
                Annotated[
                    tool,
                    pydantic.Tag(tool._declared_kind()),
                    pydantic.GetPydanticSchema(
                        get_pydantic_json_schema=lambda schema, handler, kind=tool._declared_kind(): {
                            'allOf': [handler(schema), {'properties': {'kind': {'const': kind}}, 'required': ['kind']}]
                        }
                    ),
                ]
                for tool in tools
            ]
            tools_type = Annotated[Union[tuple(tools_annotated)], pydantic.Discriminator(_tool_discriminator)]  # noqa: UP007

        return handler(tools_type)


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class AnthropicWebSearchToolSettings(TypedDict, total=False):
    """Anthropic-specific settings for [`WebSearchTool`][pydantic_ai.native_tools.WebSearchTool]."""

    response_inclusion: Literal['full', 'excluded']
    """Whether results consumed by completed code execution calls remain in the response.

    Anthropic defaults to `'full'`. This has no effect when the model calls the tool directly, which is the default on
    models without dynamic filtering and on requests whose citations route the tool to direct calls: direct results,
    and results from code execution calls that paused before completing, are returned in full.
    """


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class OpenRouterWebSearchToolSettings(TypedDict, total=False):
    """OpenRouter-specific settings for [`WebSearchTool`][pydantic_ai.native_tools.WebSearchTool]."""

    engine: Literal['auto', 'native', 'exa', 'firecrawl', 'parallel', 'perplexity'] | str
    """The search engine OpenRouter should use.

    Other strings are forwarded as they are, so an engine OpenRouter adds later works without a new release.
    """

    mode: Literal['instant', 'fast', 'auto', 'deep-lite', 'deep', 'deep-reasoning', 'turbo', 'basic', 'advanced'] | str
    """The search mode, which depends on the engine.

    Exa and Parallel each accept their own set of values, and other engines ignore this option. OpenRouter decides
    whether a value fits the engine, so it isn't checked here.
    """

    max_results: int
    """The maximum results returned by each search call."""

    max_total_results: int
    """The maximum results returned across all search calls in one request."""

    max_characters: int
    """The maximum content characters returned for each result."""


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class WebSearchProviderSettings(TypedDict, total=False):
    """Provider-specific web search settings, keyed by the model class that reads them."""

    anthropic: AnthropicWebSearchToolSettings
    openrouter: OpenRouterWebSearchToolSettings


@dataclass(kw_only=True)
class WebSearchTool(AbstractNativeTool):
    """A native tool that allows your agent to search the web for information.

    The parameters that PydanticAI passes depend on the model, as some parameters may not be supported by certain models.
    The restricting settings `allowed_domains`, `blocked_domains`, `max_uses`, and `external_web_access=False` are
    the exception: on a model that can't apply one that is set, the tool is treated as unsupported, so the local
    fallback runs if one is provided, the tool is left out if it is `optional`, and
    [`UserError`][pydantic_ai.exceptions.UserError] is raised otherwise.
    OpenRouter uses its Beta web-search server tool, which lets the model decide whether to search and how often.
    It accepts the portable settings below, though their effect depends on OpenRouter's selected
    search engine and downstream provider.

    Supported by:

    * Anthropic
    * OpenAI Responses
    * Groq
    * Google
    * xAI
    * OpenRouter
    """

    search_context_size: Literal['low', 'medium', 'high'] = 'medium'
    """The `search_context_size` parameter controls how much context is retrieved from the web to help the tool formulate a response.

    Supported by:

    * OpenAI Responses
    * OpenRouter
    """

    user_location: WebSearchUserLocation | None = None
    """The `user_location` parameter allows you to localize search results based on a user's location.

    Supported by:

    * Anthropic
    * OpenAI Responses
    * xAI, see <https://docs.x.ai/docs/guides/tools/search-tools#web-search-parameters>
    * OpenRouter, see <https://openrouter.ai/docs/guides/features/server-tools/web-search#configuration>
    """

    blocked_domains: list[str] | None = None
    """If provided, these domains will never appear in results.

    With Anthropic, you can only use one of `blocked_domains` or `allowed_domains`, not both.

    Supported by:

    * Anthropic, see <https://docs.anthropic.com/en/docs/build-with-claude/tool-use/web-search-tool#domain-filtering>
    * Groq, see <https://console.groq.com/docs/agentic-tooling#search-settings>
    * OpenAI Responses, see <https://developers.openai.com/api/docs/guides/tools-web-search#domain-filtering>
    * xAI, see <https://docs.x.ai/docs/guides/tools/search-tools#web-search-parameters>
    * OpenRouter, see <https://openrouter.ai/docs/guides/features/server-tools/web-search#configuration>
    """

    allowed_domains: list[str] | None = None
    """If provided, only these domains will be included in results.

    With Anthropic, you can only use one of `blocked_domains` or `allowed_domains`, not both.

    Supported by:

    * Anthropic, see <https://docs.anthropic.com/en/docs/build-with-claude/tool-use/web-search-tool#domain-filtering>
    * Groq, see <https://console.groq.com/docs/agentic-tooling#search-settings>
    * OpenAI Responses, see <https://platform.openai.com/docs/guides/tools-web-search>
    * xAI, see <https://docs.x.ai/docs/guides/tools/search-tools#web-search-parameters>
    * OpenRouter, see <https://openrouter.ai/docs/guides/features/server-tools/web-search#configuration>
    """

    max_uses: int | None = None
    """If provided, the tool will stop searching the web after the given number of uses.

    For OpenRouter, this limit is enforced with a non-native search engine or Anthropic's native
    search. Other native providers ignore it.

    Supported by:

    * Anthropic
    * OpenRouter
    """

    external_web_access: bool | None = None
    """Whether the hosted web search tool may fetch live web content.

    If `False`, the tool uses only cached or indexed results. If `None`, the parameter is omitted and the provider
    default is used. OpenAI currently defaults to `True`.

    Supported by:

    * OpenAI Responses `web_search` tool, see <https://developers.openai.com/api/docs/guides/tools-web-search#live-internet-access>

    OpenAI's legacy `web_search_preview` tool ignores this parameter.
    """

    provider_settings: WebSearchProviderSettings | None = None
    """Provider-specific web search settings, keyed by the model class that reads them."""

    kind: str = 'web_search'
    """The kind of tool."""

    @property
    def restricting_settings(self) -> frozenset[str]:
        """`allowed_domains`, `blocked_domains` and `max_uses` when set, and `external_web_access` when `False`."""
        settings: set[str] = set()
        if self.allowed_domains is not None:
            settings.add('allowed_domains')
        if self.blocked_domains is not None:
            settings.add('blocked_domains')
        if self.max_uses is not None:
            settings.add('max_uses')
        if self.external_web_access is False:
            settings.add('external_web_access')
        return frozenset(settings)


class WebSearchUserLocation(TypedDict, total=False):
    """Allows you to localize search results based on a user's location.

    Supported by:

    * Anthropic
    * OpenAI Responses
    * xAI
    * OpenRouter
    """

    city: str
    """The city where the user is located."""

    country: str
    """The country where the user is located.

    For OpenAI and xAI, this must be a 2-letter ISO 3166-1 alpha-2 country code (e.g., 'US', 'GB')."""

    region: str
    """The region or state where the user is located."""

    timezone: str
    """The timezone of the user's location."""


@dataclass(kw_only=True)
class XSearchTool(AbstractNativeTool):
    """A native tool that allows your agent to search X/Twitter for posts and content.

    See <https://docs.x.ai/developers/tools/x-search> for more details.

    When used via the [`XSearch`][pydantic_ai.capabilities.XSearch] capability with a
    `fallback_subagent_model` set, this tool also works with non-xAI models by delegating to a
    subagent running the specified xAI model.

    Supported by:

    * xAI
    """

    allowed_x_handles: list[str] | None = None
    """If provided, only posts from these X handles will be included (max 20).

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    excluded_x_handles: list[str] | None = None
    """If provided, posts from these X handles will be excluded (max 20).

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    from_date: datetime | None = None
    """If provided, only posts created on or after this datetime will be included.

    Naive datetimes are interpreted as UTC by the xAI API.

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    to_date: datetime | None = None
    """If provided, only posts created on or before this datetime will be included.

    Naive datetimes are interpreted as UTC by the xAI API.

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    enable_image_understanding: bool = False
    """Enable image analysis from X posts.

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    enable_video_understanding: bool = False
    """Enable video analysis from X content.

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    include_output: bool = False
    """Include raw X search results in the response as
    [`NativeToolReturnPart`][pydantic_ai.messages.NativeToolReturnPart].

    Without this, the model uses the search results internally but only returns
    its text summary. Enabling it gives programmatic access to searched posts,
    sources, and metadata.

    Can also be set via
    [`XaiModelSettings.xai_include_x_search_output`][pydantic_ai.models.xai.XaiModelSettings.xai_include_x_search_output].

    Supported by:

    * xAI, see <https://docs.x.ai/developers/tools/x-search>
    """

    kind: str = 'x_search'
    """The kind of tool."""

    def __post_init__(self) -> None:
        if self.allowed_x_handles is not None and self.excluded_x_handles is not None:
            raise ValueError('Cannot specify both allowed_x_handles and excluded_x_handles')
        if self.allowed_x_handles and len(self.allowed_x_handles) > 20:
            raise ValueError('allowed_x_handles cannot contain more than 20 handles')
        if self.excluded_x_handles and len(self.excluded_x_handles) > 20:
            raise ValueError('excluded_x_handles cannot contain more than 20 handles')


@dataclass(kw_only=True)
class CodeExecutionTool(AbstractNativeTool):
    """A native tool that allows your agent to execute code.

    Supported by:

    * Anthropic
    * OpenAI Responses
    * Google
    * Bedrock (Nova2.0)
    * xAI
    """

    files: list[UploadedFile] | None = None
    """Uploaded files to make available in the code execution environment.

    Only files matching the model provider are used; files from other providers are ignored.

    Supported by:

    * Anthropic
    * OpenAI Responses
    """

    kind: str = 'code_execution'
    """The kind of tool."""


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class AnthropicWebFetchToolSettings(TypedDict, total=False):
    """Anthropic-specific settings for [`WebFetchTool`][pydantic_ai.native_tools.WebFetchTool]."""

    enable_citations: bool
    """Whether fetched content is cited. Maps to `citations={'enabled': True}`.

    The [`citations`][pydantic_ai.settings.ModelSettings.citations] model setting also enables them.
    """

    max_content_tokens: int
    """Maximum length, in tokens, of the fetched content that Anthropic adds to the context."""

    use_cache: bool
    """Whether Anthropic may return cached web content.

    Anthropic defaults to `True`; `False` fetches the page fresh, which adds latency.
    """

    response_inclusion: Literal['full', 'excluded']
    """Whether results consumed by completed code execution calls remain in the response.

    Anthropic defaults to `'full'`. This has no effect when the model calls the tool directly, which is the default on
    models without dynamic filtering and on requests whose citations route the tool to direct calls: direct results,
    and results from code execution calls that paused before completing, are returned in full.
    """


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class WebFetchProviderSettings(TypedDict, total=False):
    """Provider-specific web fetch settings, keyed by the model class that reads them."""

    anthropic: AnthropicWebFetchToolSettings


@dataclass(kw_only=True)
class WebFetchTool(AbstractNativeTool):
    """Allows your agent to access contents from URLs.

    The parameters that PydanticAI passes depend on the model, as some parameters may not be supported by certain models.
    The restricting settings `allowed_domains`, `blocked_domains`, and `max_uses` are the exception: on a model that
    can't apply one that is set, the tool is treated as unsupported, so the local fallback runs if one is provided,
    the tool is left out if it is `optional`, and [`UserError`][pydantic_ai.exceptions.UserError] is raised
    otherwise.

    Supported by:

    * Anthropic
    * Google
    """

    max_uses: int | None = None
    """If provided, the tool will stop fetching URLs after the given number of uses.

    Supported by:

    * Anthropic
    """

    allowed_domains: list[str] | None = None
    """If provided, only these domains will be fetched.

    With Anthropic, you can only use one of `blocked_domains` or `allowed_domains`, not both.

    Supported by:

    * Anthropic, see <https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/web-fetch-tool#domain-filtering>
    """

    blocked_domains: list[str] | None = None
    """If provided, these domains will never be fetched.

    With Anthropic, you can only use one of `blocked_domains` or `allowed_domains`, not both.

    Supported by:

    * Anthropic, see <https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/web-fetch-tool#domain-filtering>
    """

    enable_citations: Annotated[bool, _moved_to_provider_settings('anthropic', 'enable_citations')] = False
    """If True, enables citations for fetched content.

    Deprecated: set `provider_settings.anthropic.enable_citations` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    The [`citations`][pydantic_ai.settings.ModelSettings.citations] model setting also enables them.

    Supported by:

    * Anthropic
    """

    max_content_tokens: Annotated[int | None, _moved_to_provider_settings('anthropic', 'max_content_tokens')] = None
    """Maximum content length in tokens for fetched content.

    Deprecated: set `provider_settings.anthropic.max_content_tokens` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * Anthropic
    """

    provider_settings: WebFetchProviderSettings | None = None
    """Provider-specific web fetch settings, keyed by the model class that reads them."""

    kind: str = 'web_fetch'
    """The kind of tool."""

    def __post_init__(self) -> None:
        _check_moved_fields(
            self,
            'anthropic',
            (self.provider_settings or {}).get('anthropic', {}),
            {'enable_citations': (self.enable_citations, False), 'max_content_tokens': (self.max_content_tokens, None)},
        )

    @property
    def restricting_settings(self) -> frozenset[str]:
        """`allowed_domains`, `blocked_domains` and `max_uses` when set."""
        settings: set[str] = set()
        if self.allowed_domains is not None:
            settings.add('allowed_domains')
        if self.blocked_domains is not None:
            settings.add('blocked_domains')
        if self.max_uses is not None:
            settings.add('max_uses')
        return frozenset(settings)


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class OpenAIImageGenerationToolSettings(TypedDict, total=False):
    """OpenAI-specific settings for [`ImageGenerationTool`][pydantic_ai.native_tools.ImageGenerationTool]."""

    action: Literal['generate', 'edit', 'auto']
    """Whether to generate a new image, edit an input image, or let OpenAI choose. Defaults to `'auto'`."""

    background: Literal['transparent', 'opaque', 'auto']
    """The image background. `'transparent'` requires PNG or WebP output. Defaults to `'auto'`."""

    input_fidelity: Literal['high', 'low']
    """How closely edits should preserve features from input images. Defaults to `'low'`."""

    moderation: Literal['auto', 'low']
    """The OpenAI image moderation level. Defaults to `'auto'`."""

    model: ImageGenerationModelName
    """The OpenAI image generation model. By default, OpenAI selects the model."""

    partial_images: int
    """The number of partial images to stream, from 0 to 3. Defaults to 0."""

    quality: ImageQuality
    """The OpenAI image quality level. Defaults to `'auto'`. `gpt-image-2` and earlier models reject `xhigh` and `max`."""


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class ImageGenerationProviderSettings(TypedDict, total=False):
    """Provider-specific image generation settings, keyed by the model class that reads them."""

    openai: OpenAIImageGenerationToolSettings


@dataclass(kw_only=True)
class ImageGenerationTool(AbstractNativeTool):
    """A native tool that allows your agent to generate images.

    Supported by:

    * OpenAI Responses
    * Google
    """

    action: Annotated[Literal['generate', 'edit', 'auto'], _moved_to_provider_settings('openai', 'action')] = 'auto'
    """Whether to generate a new image or edit an existing image.

    Deprecated: set `provider_settings.openai.action` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses. Default: 'auto'.
    """

    background: Annotated[
        Literal['transparent', 'opaque', 'auto'], _moved_to_provider_settings('openai', 'background')
    ] = 'auto'
    """Background type for the generated image.

    Deprecated: set `provider_settings.openai.background` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses. 'transparent' is only supported for 'png' and 'webp' output formats.
    """

    input_fidelity: Annotated[
        Literal['high', 'low'] | None, _moved_to_provider_settings('openai', 'input_fidelity')
    ] = None
    """
    Control how much effort the model will exert to match the style and features,
    especially facial features, of input images.

    Deprecated: set `provider_settings.openai.input_fidelity` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses. Default: 'low'.
    """

    moderation: Annotated[Literal['auto', 'low'], _moved_to_provider_settings('openai', 'moderation')] = 'auto'
    """Moderation level for the generated image.

    Deprecated: set `provider_settings.openai.moderation` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses
    """

    model: Annotated[ImageGenerationModelName | None, _moved_to_provider_settings('openai', 'model')] = None
    """The image generation model to use.

    Deprecated: set `provider_settings.openai.model` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses. Defaults to the provider's image generation model selection.
      Known image generation models include `gpt-image-2.6-flare`, `gpt-image-2.6-sunburst`,
      `gpt-image-2`, `gpt-image-1.5`, and `gpt-image-1-mini`.

    This selects the underlying image generation model used by the tool; it does
    not change the agent's conversational model.
    """

    output_compression: int | None = None
    """Compression level for the output image.

    Supported by:

    * OpenAI Responses. Only supported for 'jpeg' and 'webp' output formats. Default: 100.
    * Google (Vertex AI only). Only supported for 'jpeg' output format. Default: 75.
      Setting this will default `output_format` to 'jpeg' if not specified.
    """

    output_format: Literal['png', 'webp', 'jpeg'] | None = None
    """The output format of the generated image.

    Supported by:

    * OpenAI Responses. Default: 'png'.
    * Google (Vertex AI only). Default: 'png', or 'jpeg' if `output_compression` is set.
    """

    partial_images: Annotated[int, _moved_to_provider_settings('openai', 'partial_images')] = 0
    """
    Number of partial images to generate in streaming mode.

    Deprecated: set `provider_settings.openai.partial_images` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses. Supports 0 to 3.
    """

    quality: Annotated[ImageQuality, _moved_to_provider_settings('openai', 'quality')] = 'auto'
    """The quality of the generated image.

    Deprecated: set `provider_settings.openai.quality` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * OpenAI Responses. `gpt-image-2` and earlier models reject `xhigh` and `max`.
    """

    size: ImageSize | None = None
    """The size of the generated image.

    * OpenAI Responses: 'auto' (default: model selects the size based on the prompt), '1024x1024', '1024x1536', '1536x1024'
    * Google (Gemini 3 Pro Image and later): '512' (Gemini 3.1 Flash Image only), '1K' (default), '2K', '4K'
    """

    aspect_ratio: ImageAspectRatio | None = None
    """The aspect ratio to use for generated images.

    Supported by:

    * Google image-generation models (Gemini)
    * OpenAI Responses (maps '1:1', '2:3', and '3:2' to supported sizes)
    """

    provider_settings: ImageGenerationProviderSettings | None = None
    """Provider-specific image generation settings, keyed by the model class that reads them."""

    kind: str = 'image_generation'
    """The kind of tool."""

    def __post_init__(self) -> None:
        _check_moved_fields(
            self,
            'openai',
            (self.provider_settings or {}).get('openai', {}),
            {
                'action': (self.action, 'auto'),
                'background': (self.background, 'auto'),
                'input_fidelity': (self.input_fidelity, None),
                'moderation': (self.moderation, 'auto'),
                'model': (self.model, None),
                'partial_images': (self.partial_images, 0),
                'quality': (self.quality, 'auto'),
            },
        )


@dataclass(kw_only=True)
class MemoryTool(AbstractNativeTool):
    """A native tool that allows your agent to use memory.

    Supported by:

    * Anthropic
    """

    kind: str = 'memory'
    """The kind of tool."""


@dataclass(kw_only=True)
class MCPServerTool(AbstractNativeTool):
    """A native tool that allows your agent to use MCP servers.

    Supported by:

    * OpenAI Responses
    * Anthropic
    * xAI
    """

    id: str
    """A unique identifier for the MCP server."""

    url: str
    """The URL of the MCP server to use.

    For OpenAI Responses, it is possible to use `connector_id` by providing it as `x-openai-connector:<connector_id>`.
    """

    authorization_token: str | None = None
    """Authorization header to use when making requests to the MCP server.

    Supported by:

    * OpenAI Responses
    * Anthropic
    * xAI
    """

    description: str | None = None
    """A description of the MCP server.

    Supported by:

    * OpenAI Responses
    * xAI
    """

    allowed_tools: list[str] | None = None
    """A list of tools that the MCP server can use.

    Supported by:

    * OpenAI Responses
    * Anthropic
    * xAI
    """

    headers: dict[str, str] | None = None
    """Optional HTTP headers to send to the MCP server.

    Use for authentication or other purposes.

    Supported by:

    * OpenAI Responses
    * xAI
    """

    kind: str = 'mcp_server'

    @property
    def _telemetry_url_derived_id(self) -> str | None:
        value = getattr(self, '_telemetry_url_derived_id_value', None)
        return value if isinstance(value, str) else None

    @_telemetry_url_derived_id.setter
    def _telemetry_url_derived_id(self, value: str | None) -> None:
        object.__setattr__(self, '_telemetry_url_derived_id_value', value)

    @property
    def unique_id(self) -> str:
        return ':'.join([self.kind, self.id])

    @property
    def label(self) -> str:
        return f'MCP: {self.id}'


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class XaiFileSearchToolSettings(TypedDict, total=False):
    """xAI-specific settings for [`FileSearchTool`][pydantic_ai.native_tools.FileSearchTool]."""

    instructions: str
    """Instructions for interpreting and ranking xAI collections search results."""

    retrieval_mode: Literal['hybrid', 'semantic', 'keyword']
    """The xAI collections search retrieval strategy. xAI defaults to `'hybrid'` server-side."""


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class FileSearchProviderSettings(TypedDict, total=False):
    """Provider-specific file search settings, keyed by the model class that reads them."""

    xai: XaiFileSearchToolSettings


@dataclass(kw_only=True)
class FileSearchTool(AbstractNativeTool):
    """A native tool that allows your agent to search through uploaded files using vector search.

    This tool provides a fully managed Retrieval-Augmented Generation (RAG) system that handles
    file storage, chunking, embedding generation, and context injection into prompts.

    Supported by:

    * OpenAI Responses
    * Google (Gemini)
    * xAI (mapped to collections search)
    """

    file_store_ids: Sequence[str]
    """The file store IDs to search through.

    For OpenAI, these are the IDs of vector stores created via the OpenAI API.
    For Google, these are file search store names that have been uploaded and processed via the Gemini Files API.
    For xAI, these are collection IDs for the xAI collections search tool.
    """

    max_num_results: int | None = None
    """The maximum number of results to return.

    Supported by:

    * OpenAI Responses (mapped to `max_num_results`; OpenAI accepts 1 to 50)
    * xAI (mapped to collections search `limit`, defaults to 10 server-side)
    """

    instructions: Annotated[str | None, _moved_to_provider_settings('xai', 'instructions')] = None
    """Optional instructions that guide how the collections search results are interpreted and ranked.

    Deprecated: set `provider_settings.xai.instructions` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * xAI
    """

    retrieval_mode: Annotated[
        Literal['hybrid', 'semantic', 'keyword'] | None, _moved_to_provider_settings('xai', 'retrieval_mode')
    ] = None
    """The retrieval strategy for the search.

    Deprecated: set `provider_settings.xai.retrieval_mode` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * xAI (defaults to `hybrid` server-side)
    """

    provider_settings: FileSearchProviderSettings | None = None
    """Provider-specific file search settings, keyed by the model class that reads them."""

    kind: str = 'file_search'
    """The kind of tool."""

    def __post_init__(self) -> None:
        _check_moved_fields(
            self,
            'xai',
            (self.provider_settings or {}).get('xai', {}),
            {'instructions': (self.instructions, None), 'retrieval_mode': (self.retrieval_mode, None)},
        )


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class AnthropicAdvisorToolSettings(TypedDict, total=False):
    """Anthropic-specific settings for [`AdvisorTool`][pydantic_ai.native_tools.AdvisorTool]."""

    caching: Literal['5m', '1h']
    """The ephemeral cache TTL for the Anthropic advisor context. Maps to `caching={'type': 'ephemeral', 'ttl': ...}`."""


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class OpenRouterAdvisorToolSettings(TypedDict, total=False):
    """OpenRouter-specific settings for [`AdvisorTool`][pydantic_ai.native_tools.AdvisorTool]."""

    forward_transcript: bool
    """Whether OpenRouter should include the conversation transcript in the advisor request."""


@pydantic.with_config(pydantic.ConfigDict(extra='allow'))
class AdvisorProviderSettings(TypedDict, total=False):
    """Provider-specific advisor settings, keyed by the model class that reads them."""

    anthropic: AnthropicAdvisorToolSettings
    openrouter: OpenRouterAdvisorToolSettings


@dataclass(kw_only=True)
class AdvisorTool(AbstractNativeTool):
    """A native tool that lets a faster executor model consult a stronger advisor model mid-generation.

    The first-class fields describe behavior shared by the supported systems; system-specific options
    live in `provider_settings`. See the per-field docstrings for which provider supports each option.

    Supported by:

    * Anthropic
    * OpenRouter
    """

    model: AdvisorModelName
    """The advisor model to consult, i.e. the `model` field of the provider's advisor tool definition.

    The executor/advisor pairing is validated by the provider's API, not here. The accepted namespace
    depends on the executing provider: Anthropic model IDs (e.g. `claude-opus-4-8`) on Anthropic,
    OpenRouter catalog slugs (e.g. `anthropic/claude-opus-4.8`) on OpenRouter.

    Supported by:

    * Anthropic
    * OpenRouter
    """

    max_uses: int | None = None
    """If provided, the advisor can be consulted at most this many times per request. Maps to `max_uses`.

    This is a per-request cap, not a per-run budget: a run that spans multiple requests resets the
    count each request. Enforce a conversation-wide ceiling yourself if you need one.

    Supported by:

    * Anthropic

    OpenRouter caps advisor consultations per request with a fixed gateway limit and ignores
    `max_uses`.
    """

    max_tokens: int | None = None
    """If provided, caps the advisor's output tokens (minimum 1024). Maps to `max_tokens` on Anthropic
    and `max_completion_tokens` on OpenRouter.

    When set, the Anthropic advisor result carries a `stop_reason`.

    Supported by:

    * Anthropic
    * OpenRouter
    """

    caching: Annotated[Literal['5m', '1h'] | None, _moved_to_provider_settings('anthropic', 'caching')] = None
    """If provided, caches the advisor context ephemerally with the given TTL. Maps to
    `caching={'type': 'ephemeral', 'ttl': ...}`.

    Deprecated: set `provider_settings.anthropic.caching` instead, and read it from there too.
    This field holds only a value set on it directly, not one set in `provider_settings`.

    Supported by:

    * Anthropic

    OpenRouter's advisor tool has no equivalent knob and ignores `caching`.
    """

    provider_settings: AdvisorProviderSettings | None = None
    """Provider-specific advisor settings, keyed by the model class that reads them."""

    kind: str = 'advisor'
    """The kind of tool."""

    def __post_init__(self) -> None:
        _check_moved_fields(
            self,
            'anthropic',
            (self.provider_settings or {}).get('anthropic', {}),
            {'caching': (self.caching, None)},
        )
        if self.max_tokens is not None and self.max_tokens < 1024:
            raise ValueError('AdvisorTool.max_tokens must be at least 1024')


# Imported after the base class is defined — `_tool_search.py` subclasses
# `AbstractNativeTool`, so the import has to follow. Loading the submodule registers
# `ToolSearchTool` in `NATIVE_TOOL_TYPES` via `__init_subclass__`. `ToolSearchTool` is
# framework-internal (constructed exclusively by the
# [`ToolSearch`][pydantic_ai.capabilities.ToolSearch] capability) and intentionally not
# re-exported here; user-facing strategy types live on `pydantic_ai.capabilities`.
from . import _tool_search as _tool_search  # noqa: E402


def _tool_discriminator(tool_data: dict[str, Any] | AbstractNativeTool) -> str:
    if isinstance(tool_data, dict):
        return tool_data.get('kind', AbstractNativeTool.kind)
    else:
        return tool_data.kind


SUPPORTED_NATIVE_TOOLS = frozenset(NATIVE_TOOL_TYPES.values())
"""Set of all native tool types."""

NATIVE_TOOLS_REQUIRING_CONFIG: frozenset[type[AbstractNativeTool]] = frozenset(
    {FileSearchTool, MCPServerTool, MemoryTool, AdvisorTool, _tool_search.ToolSearchTool}
)
