from __future__ import annotations

from dataclasses import KW_ONLY, dataclass
from typing import TYPE_CHECKING

from pydantic_ai._content_filter import content_filter_message
from pydantic_ai._run_context import AgentDepsT, RunContext
from pydantic_ai.exceptions import ContentFilterError
from pydantic_ai.messages import ModelMessagesTypeAdapter, ModelResponse

from .abstract import AbstractCapability

if TYPE_CHECKING:
    from pydantic_ai.models import ModelRequestContext


@dataclass
class RaiseContentFilterError(AbstractCapability[AgentDepsT]):
    """Raises `ContentFilterError` when a model response has `finish_reason='content_filter'`.

    Add this capability to opt into treating content-filtered responses as run-ending errors,
    even when the provider returns partial text or refusal text. The full
    [`ModelResponse`][pydantic_ai.messages.ModelResponse] is serialized into
    [`ContentFilterError.body`][pydantic_ai.exceptions.UnexpectedModelBehavior.body] so callers
    can inspect any partial content.
    """

    _: KW_ONLY

    id: str | None = 'raise_content_filter_error'
    """One-off: the capability takes no configuration, so a second instance can only duplicate the first, so the id is fixed by default.

    Two of them resolve to one via [`combine`][pydantic_ai.capabilities.AbstractCapability.combine],
    which keeps the last. Pass a distinct `id` to keep both, or `id=None` for derived ids.
    """

    async def after_model_request(
        self,
        ctx: RunContext[AgentDepsT],
        *,
        request_context: ModelRequestContext,
        response: ModelResponse,
    ) -> ModelResponse:
        if response.finish_reason == 'content_filter':
            body = ModelMessagesTypeAdapter.dump_json([response]).decode()
            raise ContentFilterError(content_filter_message(response.provider_details), body=body)

        return response
