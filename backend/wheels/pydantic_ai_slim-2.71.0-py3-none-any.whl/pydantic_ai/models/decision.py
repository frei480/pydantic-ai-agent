from __future__ import annotations as _annotations

import dataclasses
import json
from abc import abstractmethod
from collections.abc import AsyncGenerator, AsyncIterator, Collection, Iterable, Mapping, Sequence
from contextlib import asynccontextmanager
from dataclasses import dataclass, field, replace
from datetime import datetime
from decimal import Decimal
from functools import cached_property
from math import isfinite
from typing import Any, ClassVar, Literal, TypeAlias, assert_never, cast

from opentelemetry.trace import INVALID_SPAN, Span, SpanKind
from opentelemetry.util.types import AttributeValue
from pydantic import JsonValue
from pydantic_core import to_jsonable_python
from typing_extensions import deprecated

from .. import _utils, usage
from .._deferred_capabilities import DEFERRED_CAPABILITY_CATALOG_ID
from .._instrumentation import model_attributes, open_request_policy, record_uncaught_errors, safe_to_json
from .._json_schema import InlinedValues
from .._output import DEFAULT_OUTPUT_TOOL_DESCRIPTION, DEFAULT_OUTPUT_TOOL_NAME
from .._run_context import RunContext
from .._warnings import PydanticAIDeprecationWarning
from ..exceptions import ModelAPIError, UnexpectedModelBehavior, UserError
from ..messages import (
    ERROR_OUTCOMES,
    BaseToolReturnPart,
    BinaryContent,
    CachePoint,
    CapabilityInstructionSource,
    CompactionPart,
    FilePart,
    ImageUrl,
    InstructionBaselinePart,
    InstructionDeltaPart,
    InstructionId,
    InstructionPart,
    ModelMessage,
    ModelRequest,
    ModelRequestPart,
    ModelResponse,
    ModelResponseStreamEvent,
    MultiModalContent,
    NativeToolCallPart,
    NativeToolReturnPart,
    RetryFeedbackPart,
    RetryPromptPart,  # pyright: ignore[reportDeprecated]  # TODO(v3): remove RetryPromptPart
    SpeechPart,
    StructuredContent,
    SystemPromptPart,
    TextContent,
    TextPart,
    ThinkingPart,
    ToolCallPart,
    ToolReturnPart,
    UserPromptPart,
    _tool_return_items_json,  # pyright: ignore[reportPrivateUsage]
    _translate_legacy_retry_part,  # pyright: ignore[reportPrivateUsage]
    is_multi_modal_content,
    tool_return_ta,
)
from ..profiles import ModelProfile, merge_profile
from ..profiles.decision import DecisionModelProfile
from ..providers import InterfaceClient
from ..settings import ModelSettings
from ..tools import ToolDefinition
from ..usage import RequestUsage
from . import (
    DeferredCapabilityEntry,
    Model,
    ModelRequestParameters,
    StreamedResponse,
    _unconverted_speech_part_error,  # pyright: ignore[reportPrivateUsage]
    _unprepared_part_error,  # pyright: ignore[reportPrivateUsage]
    _UnpreparedPart,  # pyright: ignore[reportPrivateUsage]
    _unprojected_instruction_delta_error,  # pyright: ignore[reportPrivateUsage]
    check_allow_model_requests,
    download_item,
)

__all__ = (
    'ChoiceAnswer',
    'ChoiceQuestion',
    'DecisionAnswer',
    'DecisionHandOff',
    'DecisionModel',
    'DecisionModelSettings',
    'DecisionQuestion',
    'DecisionRequest',
    'DecisionResponse',
    'DecisionStreamedResponse',
    'NoulAnswer',
    'NoulCriteria',
    'NoulQuestion',
    'ScoreAnswer',
    'ScoreQuestion',
    'UnfillableRoute',
    'UnsureRoute',
)


@dataclass(kw_only=True)
class NoulCriteria:
    """Descriptions of the two outcomes of a yes/no question."""

    true: JsonValue = None
    """Description of the yes outcome."""
    false: JsonValue = None
    """Description of the no outcome."""


@dataclass(kw_only=True)
class NoulQuestion:
    """A yes/no question whose answer is the probability of yes."""

    instructions: JsonValue = None
    """What to decide about the state."""
    criteria: NoulCriteria | None = None
    """Descriptions of the yes and no outcomes."""
    type: Literal['noul'] = 'noul'
    """The Decisions protocol question type."""


@dataclass(kw_only=True)
class ChoiceQuestion:
    """A question that selects one named option."""

    criteria: dict[str, JsonValue]
    """Option labels mapped to their descriptions."""
    instructions: JsonValue = None
    """What to decide about the state."""
    type: Literal['choice'] = 'choice'
    """The Decisions protocol question type."""


@dataclass(kw_only=True)
class ScoreQuestion:
    """A question that scores the state against ordered levels."""

    criteria: list[JsonValue]
    """One description per level, starting at zero."""
    instructions: JsonValue = None
    """What to decide about the state."""
    type: Literal['score'] = 'score'
    """The Decisions protocol question type."""


DecisionQuestion: TypeAlias = NoulQuestion | ChoiceQuestion | ScoreQuestion
"""A question supported by the Decisions protocol."""


@dataclass(kw_only=True)
class NoulAnswer:
    """The probability of yes for a yes/no question."""

    noul: float
    """The probability of yes, from 0 to 1."""
    type: Literal['noul'] = 'noul'
    """The Decisions protocol answer type."""


@dataclass(kw_only=True)
class ChoiceAnswer:
    """The selected option and its probability distribution."""

    choice: str
    """The selected option label."""
    confidence: float
    """Confidence in the selected option."""
    probabilities: dict[str, float]
    """Probability for each option label."""
    type: Literal['choice'] = 'choice'
    """The Decisions protocol answer type."""


@dataclass(kw_only=True)
class ScoreAnswer:
    """A score and its probability distribution across levels."""

    score: float
    """The expected score along the ordered levels."""
    confidence: float
    """Confidence in the score."""
    probabilities: dict[int, float]
    """Probability for each level."""
    legend: dict[int, JsonValue] = field(default_factory=dict[int, JsonValue])
    """The descriptions of the levels, as the backend echoes them back, if it does.

    Not read to build the output, which comes from `score` alone; kept so the answer is recorded as it was received.
    """
    type: Literal['score'] = 'score'
    """The Decisions protocol answer type."""


DecisionAnswer: TypeAlias = NoulAnswer | ChoiceAnswer | ScoreAnswer
"""An answer returned by the Decisions protocol."""


@dataclass(kw_only=True)
class DecisionRequest:
    """A request to decide typed questions about a state."""

    state: JsonValue
    """The text or JSON value to decide about."""
    questions: dict[str, DecisionQuestion]
    """Named questions to answer about the state."""
    images: tuple[BinaryContent, ...] = ()
    """Image evidence, in the order of the `<image N>` references in `state`.

    Only image media types are supported. Backends that do not support images must reject a nonempty tuple,
    including when `decide` is called directly.
    """
    messages: list[ModelMessage] = field(default_factory=list[ModelMessage])
    """The conversation `state` was built from, for a backend that takes a conversation natively.

    Empty when `decide` is called directly with only a `state`. Its images are the ones in `images`, resolved and in
    the same order: the order they appear in, message by message and part by part.
    """


@dataclass(kw_only=True)
class DecisionResponse:
    """The answers to a [`DecisionRequest`][pydantic_ai.models.decision.DecisionRequest], and what produced them."""

    answers: dict[str, DecisionAnswer]
    """Answers keyed by question name."""
    model_name: str
    """The model that produced the answers."""
    usage: RequestUsage = field(default_factory=RequestUsage)
    """Usage for this request."""
    provider_response_id: str | None = None
    """The backend's identifier for this request, if it returned one.

    Recorded as `gen_ai.response.id` on the request's `decide` span. It is not copied to the
    `ModelResponse`, which can be built from two Decisions requests.
    """


def _wire(value: DecisionQuestion | DecisionAnswer) -> dict[str, Any]:
    """A question or answer in the Decisions protocol's JSON shape: `type` first, and unset fields left out.

    What a `decide` span records, so it reads as what was sent and received.
    Read field by field rather than through `asdict`, which would deep-copy whatever a backend put in an answer.
    """
    wire: dict[str, Any] = {'type': value.type}
    for name in (f.name for f in dataclasses.fields(value) if f.name != 'type'):
        item = getattr(value, name)
        if isinstance(item, NoulCriteria):
            # A question's own dataclass, which is the protocol's to shape, unlike what a backend answers.
            item = dataclasses.asdict(item)
        if isinstance(value, NoulQuestion) and name == 'criteria' and item is not None:
            # Either side of a yes/no can be left undescribed, and is then left out, like the question's own fields.
            item = {outcome: meaning for outcome, meaning in item.items() if meaning is not None}
        if item is not None:
            wire[name] = item
    return wire


def _text(value: JsonValue) -> str:  # pyright: ignore[reportUnusedFunction]
    """A protocol value as the text an API takes: a string as it is, anything else as JSON."""
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)


def _half_unit(value: Decimal, float_tolerance: Decimal) -> Decimal:
    """How far a displayed value may be from the one it stands for.

    Half a unit of its last decimal place, using at least two, as a value rounded for display may be off by. An
    unrounded float prints all of its digits, which would make that interval far narrower than the error its own
    arithmetic carries, so it is never narrower than `float_tolerance`.
    """
    return max(Decimal(1).scaleb(-max(2, -int(value.as_tuple().exponent))) / 2, float_tolerance)


def _probability_bounds(
    probabilities: Collection[float], *, float_tolerance: Decimal = Decimal(0)
) -> tuple[list[Decimal], list[Decimal]]:
    """The bounded rounding intervals of the displayed probabilities, using at least two decimal places.

    Each interval is at least `float_tolerance` either side of its probability, for a backend that sends unrounded
    floats.
    """
    values: list[Decimal] = [Decimal(str(probability)) for probability in probabilities]
    half_units: list[Decimal] = [_half_unit(value, float_tolerance) for value in values]
    lower: list[Decimal] = [max(Decimal(0), value - half_unit) for value, half_unit in zip(values, half_units)]
    upper: list[Decimal] = [min(Decimal(1), value + half_unit) for value, half_unit in zip(values, half_units)]
    return lower, upper


def _score_fits(
    lower: Sequence[Decimal], upper: Sequence[Decimal], score: float, *, float_tolerance: Decimal = Decimal(0)
) -> bool:
    """Whether rounded probabilities can sum to one and produce the displayed score.

    The score's own interval is at least `float_tolerance` either side of it, for a backend that sends unrounded
    floats.
    """
    remaining = Decimal(1) - sum(lower, Decimal(0))
    valid = 0 <= remaining <= sum((high - low for low, high in zip(lower, upper)), Decimal(0))
    if valid:
        bounds: list[Decimal] = []
        for levels in (range(len(lower)), reversed(range(len(lower)))):
            rest = remaining
            mean = sum((level * low for level, low in enumerate(lower)), Decimal(0))
            for level in levels:
                taken = min(rest, upper[level] - lower[level])
                mean += level * taken
                rest -= taken
            bounds.append(mean)
        displayed_score = Decimal(str(score))
        score_half_unit = _half_unit(displayed_score, float_tolerance)
        valid = displayed_score + score_half_unit >= bounds[0] and displayed_score - score_half_unit <= bounds[1]
    return valid


# How far an unrounded probability or score may be from the exact value, on top of display rounding. Jev rounds
# what it sends to two decimals, but a server such as vLLM, or Google's decisions API, sends a softmax and its
# expected level unrounded, with all their float digits, and computed in float32 or float64: their sum is one, and
# the score their mean, only within that arithmetic's error, which float32 puts near 1e-7. A wrong answer is off by
# far more than this.
_FLOAT_TOLERANCE = Decimal('1e-6')


def _answer_fits(question: DecisionQuestion, answer: DecisionAnswer) -> bool:  # pyright: ignore[reportUnusedFunction]
    """Whether `answer` is a valid answer to `question`, from a backend that may round or send unrounded floats."""
    match question:
        case NoulQuestion():
            return isinstance(answer, NoulAnswer) and isfinite(answer.noul) and 0 <= answer.noul <= 1
        case ChoiceQuestion():
            return (
                isinstance(answer, ChoiceAnswer)
                and answer.choice in question.criteria
                and answer.probabilities.keys() == question.criteria.keys()
                and _probabilities_fit(answer)
            )
        case ScoreQuestion():
            return isinstance(answer, ScoreAnswer) and _score_answer_fits(question, answer)
        case _:
            assert_never(question)


def _probabilities_fit(answer: ChoiceAnswer | ScoreAnswer) -> bool:
    """Whether an answer's confidence and probabilities are probabilities, and its probabilities sum to one."""
    probabilities = answer.probabilities.values()
    # Jev displays probabilities to two decimal places, so each may differ by half a unit, which also
    # covers the float error of a backend that sends them unrounded.
    return (
        isfinite(answer.confidence)
        and 0 <= answer.confidence <= 1
        and all(isfinite(p) and 0 <= p <= 1 for p in probabilities)
        and abs(sum(probabilities) - 1) <= float(_FLOAT_TOLERANCE) + len(answer.probabilities) * 0.005
    )


def _score_answer_fits(question: ScoreQuestion, answer: ScoreAnswer) -> bool:
    """Whether a score answer rates the rubric's levels, and its score is one its probabilities could produce."""
    levels = set(range(len(question.criteria)))
    if not (
        answer.probabilities.keys() == levels
        and (not answer.legend or answer.legend.keys() == levels)
        and isfinite(answer.score)
        and 0 <= answer.score <= len(question.criteria) - 1
        and _probabilities_fit(answer)
    ):
        return False
    # A displayed score and its probabilities may each be rounded, or carry float error. Check
    # whether any distribution within their intervals could produce that score, using at least
    # Jev's two decimals and never less than the float tolerance.
    probabilities_by_level: list[float] = [answer.probabilities[level] for level in range(len(question.criteria))]
    lower, upper = _probability_bounds(probabilities_by_level, float_tolerance=_FLOAT_TOLERANCE)
    return _score_fits(lower, upper, answer.score, float_tolerance=_FLOAT_TOLERANCE)


_UNSUPPORTED_FIELD_HINT = (
    'Use `bool`, a `Literal` or `Enum` of two or more strings or whole numbers, a `float` bounded with `ge=0` and '
    '`le=1`, a `list` of a `Literal` or `Enum`, a rubric of whole numbers from 0 with a description per level in its '
    'schema, or a model of these.'
)

# A pick-one or a rubric still says what it is asking through its options; a yes/no may have nothing else.
_ASKS_NOTHING = (
    'Output field {name!r} asks the model nothing. A question is not part of the text being judged: give the field '
    'a description, or the agent `instructions`, and leave the prompt to the material the question is about. '
    'A `system_prompt` will not do: a decision model is told what was said, not what to ask.'
)

# What a pick-one, a rubric, or a yes/no with described answers asks when nothing else does, on a backend that
# `requires_instructions`: its options say the rest, worded like the route question's `Which of these ...`.
_DEFAULT_QUESTION = 'Which of these applies?'


class DecisionModelSettings(ModelSettings, total=False):
    """Settings used for a decision model request."""

    decision_boolean_threshold: float
    """How likely a yes has to be before a `bool` field is `True`, from 0 to 1. Default: 0.5.

    A decision model answers a yes/no with the probability of yes, and the default rounds it: what the framework
    cannot know is what `True` has to mean for you. Raise it where a false positive is the expensive mistake and a
    `True` should be earned, lower it where a false negative is. It applies to every `bool` field and to each option
    of a `list` of a `Literal` or `Enum`, which is one yes/no per option; a `float` bounded with `ge=0` and `le=1`
    returns the probability itself and is not thresholded.

    Reported confidence is the distance from the threshold rather than from the probability, scaled to run from 0
    at the threshold to 1 at certainty, so a yes at 0.8 under a threshold of 0.75 reports the narrow margin it is.
    """

    decision_route_threshold: float
    """How likely the picked route has to be before it is taken, from 0 to 1. Default: unset, so the pick always is.

    With tools attached, or a union of output types, one more question asks which route the text calls for: a
    tool, an output type, an output function or `None`. The likeliest route is taken. With this set, a pick whose
    own probability is below it raises [`UnsureRoute`][pydantic_ai.models.decision.UnsureRoute] instead, before
    any request to fill it. That is a [`ModelAPIError`][pydantic_ai.exceptions.ModelAPIError], so a
    [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] with a language model behind the decision model
    hands that model the step; without one, the run raises it.

    A route taken without a pick is not held to it: the one route left when every other has returned this turn, or
    a single output type with nothing else on offer. A higher threshold hands off more steps and gets more of the
    rest right; tune it on labelled examples of your own.

    This is not a guard for a tool with side effects, such as a refund or an account change: require approval
    for that tool instead.
    """


class DecisionHandOff(ModelAPIError):
    """A decision model handed the step off instead of answering it: the base of the hand-offs it raises.

    A [`ModelAPIError`][pydantic_ai.exceptions.ModelAPIError], so a
    [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] with a language model behind the decision model
    hands that model the whole step by default, tools and all, and only the steps the decision model hands off cost
    a language model call. Pass `fallback_on=DecisionHandOff` to hand off only these, and let an error from the
    decision model's backend fail the run rather than go to the language model.
    """

    route: str
    """The route the model picked, by the label the route question offered it under."""

    probability: float
    """How likely the model found the picked route, from 0 to 1."""

    def __init__(self, model_name: str, route: str, probability: float, message: str):
        self.route = route
        self.probability = probability
        super().__init__(model_name, message)

    def __reduce__(self) -> tuple[type, tuple[Any, ...]]:
        return self.__class__, (self.model_name, self.route, self.probability, self.message)


class UnfillableRoute(DecisionHandOff):
    """A decision model picked a route whose fields or arguments it cannot fill.

    A tool with an argument the model cannot express, such as a free-form `str`, or an output type with such a
    field. See [`DecisionHandOff`][pydantic_ai.models.decision.DecisionHandOff] for how a
    [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] takes the step.
    """

    def __init__(self, model_name: str, route: str, probability: float):
        super().__init__(
            model_name,
            route,
            probability,
            f'{model_name} picked {route!r} (probability {probability:.2f}) but cannot fill it. Put a model that '
            'can behind it: `FallbackModel(decision_model, language_model)` hands `language_model` this step.',
        )

    @property
    @deprecated('`tool_name` is deprecated, use `route` instead.', category=PydanticAIDeprecationWarning)
    def tool_name(self) -> str:
        """Deprecated alias for [`route`][pydantic_ai.models.decision.DecisionHandOff.route].

        For a tool, the tool's name. For an output type, the name the route question offered it under, as `Reply`,
        rather than the name of the output tool Pydantic AI made for it.
        """
        return self.route

    def __reduce__(self) -> tuple[type, tuple[Any, ...]]:
        return self.__class__, (self.model_name, self.route, self.probability)


class UnsureRoute(DecisionHandOff):
    """A decision model picked a route less likely than `decision_route_threshold`.

    Raised before any request to fill the route. See
    [`DecisionHandOff`][pydantic_ai.models.decision.DecisionHandOff] for how a
    [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] takes the step.
    """

    probabilities: dict[str, float]
    """The probability the model gave every route, by label."""

    threshold: float
    """The `decision_route_threshold` the pick fell below."""

    def __init__(self, model_name: str, route: str, probabilities: dict[str, float], threshold: float):
        self.probabilities = probabilities
        self.threshold = threshold
        probability = probabilities[route]
        super().__init__(
            model_name,
            route,
            probability,
            f'{model_name} picked {route!r} with probability {probability:.2f}, below '
            f'`decision_route_threshold` ({threshold:.2f}). Put a model behind it to take the steps it is unsure '
            'of: `FallbackModel(decision_model, language_model)` hands `language_model` this step.',
        )

    def __reduce__(self) -> tuple[type, tuple[Any, ...]]:
        return self.__class__, (self.model_name, self.route, self.probabilities, self.threshold)


@dataclass(frozen=True)
class _Limits:
    """How many options a pick-one and how many levels a rubric can have on this model, `None` for no limit.

    Read once per request from the profile's `decision_max_choice_options` and `decision_max_score_levels`, or the
    model's `max_choice_options` and `max_score_levels` where the profile leaves them out, so that turning fields into
    questions can refuse a pick-one the backend would reject before anything is sent, and ask whole numbers with
    more levels than a rubric can have as a pick-one instead. Also whether the model needs `instructions` on every
    question, from the profile's `decision_requires_instructions` or the model's `requires_instructions`.
    The backend's per-request question cap bounds speculation independently of those model-specific limits.
    """

    choice_options: int | None
    score_levels: int | None
    requires_instructions: bool
    questions: int | None


@dataclass(init=False)
class DecisionModel(Model[InterfaceClient]):
    """Base class for decision models: models that answer typed questions about evidence rather than write text.

    A decision model is sent a *state*, the text or JSON value to judge, and a set of named questions of three
    kinds: a yes/no ([`NoulQuestion`][pydantic_ai.models.decision.NoulQuestion]), a pick-one
    ([`ChoiceQuestion`][pydantic_ai.models.decision.ChoiceQuestion]), and a score against an ordered rubric
    ([`ScoreQuestion`][pydantic_ai.models.decision.ScoreQuestion]). It answers each one with a probability or a
    distribution. That exchange is the Decisions protocol, and this class maps an agent run onto it, so that an
    agent whose job is to decide something runs on a decision model like on any other model:

    - Each field of the `output_type` is one question, and its type picks the kind: a `bool` is a yes/no, a
      `Literal` or `Enum` of strings is a pick-one, and whole numbers from 0 with a description per level are a
      rubric. A `list` or `dict` of options is one yes/no per option, and a nested model is its fields. A field of
      any other type is a [`UserError`][pydantic_ai.exceptions.UserError] before a request is sent, unless there
      is another route to take, as below.
    - The field's description is the question, the output type's docstring its goal, and the agent's
      `instructions` framing shared by every question; a nested field's question also carries what it sits in.
      The latest user prompt is the text to judge, the message history before it goes along beside it, and once a
      tool has returned or a retry was sent, what was done since goes along apart from both.
    - With tools attached, or a union of output types, one more pick-one asks which route the text calls for, and
      the likeliest is taken. The fields of every route the model can fill are asked beside it, each on the premise
      of its route, and only the taken route's answers are read; past a size or question-count cutoff, a picked
      route with fields is filled in a second request instead. A route whose fields the model cannot express, a single output type's
      included, is raised as [`UnfillableRoute`][pydantic_ai.models.decision.UnfillableRoute], for a
      [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] to hand to a language model. A pick below
      `decision_route_threshold`, when set, is raised as [`UnsureRoute`][pydantic_ai.models.decision.UnsureRoute]
      the same way.
    - An [on-demand capability](https://pydantic.dev/docs/ai/capabilities/on-demand/) is a route of its own, under
      its `id` and described by its `description`, and picking it loads it. The catalog that lists them for a
      language model is left out of the framing.
    - Each field's confidence, the full distribution of each pick-one and rubric, and the route pick are reported
      in [`ModelResponse.provider_details`][pydantic_ai.messages.ModelResponse.provider_details].

    The answers arrive in one piece, so a streamed run gets the whole answer as one event.

    To support a backend, subclass this, implement [`decide`][pydantic_ai.models.decision.DecisionModel.decide]
    along with `model_name`, `system` and `base_url`, set `max_choice_options` and `max_score_levels` to the
    backend's limits, and `requires_instructions` if it refuses a question without `instructions`, or have its
    provider set these per model in a [`DecisionModelProfile`][pydantic_ai.profiles.decision.DecisionModelProfile].
    Set `supports_image_input` if the backend accepts images, and `max_images` and `max_questions` to its
    per-request transport limits. These caps describe the endpoint, so profiles do not override them.
    See [Decision models](../../models/decision.md#implementing-a-decision-model) for the full rules and an example.
    """

    # A decision model writes no text and makes at most one tool call, so `max_tokens`, `stop_sequences` and
    # `parallel_tool_calls` hold without being sent and are not listed.
    unsupported_settings = frozenset(
        {'frequency_penalty', 'logit_bias', 'presence_penalty', 'seed', 'service_tier', 'temperature', 'top_k', 'top_p'}
    )

    supports_image_input: ClassVar[bool] = False
    """Whether the backend can receive image evidence in `DecisionRequest.images`.

    Set this on a backend that supports images. The shared history mapper then labels images in the state
    and resolves image URLs before calling `decide`. This is a transport capability, not a profile default.
    """

    max_images: ClassVar[int | None] = None
    """The most images the endpoint accepts in one request, or `None` for no limit.

    This is a transport limit, independent of the selected model, so profiles do not override it.

    An oversized request raises [`ModelAPIError`][pydantic_ai.exceptions.ModelAPIError] before image URLs
    are downloaded, so a [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] can take over.
    """

    max_questions: ClassVar[int | None] = None
    """The most questions the endpoint accepts in one request, or `None` for no limit.

    This is a transport limit, independent of the selected model, so profiles do not override it.
    Speculative route fields that do not fit are filled in a separate request after the route is selected.

    An oversized request raises [`ModelAPIError`][pydantic_ai.exceptions.ModelAPIError] before image URLs
    are downloaded.
    """

    max_choice_options: ClassVar[int | None] = None
    """The most options the backend accepts in one pick-one question, or `None` for no limit.

    The profile's `decision_max_choice_options` takes precedence where it is set. A pick-one field with more options, or more routes than this on the route question, is a
    [`UserError`][pydantic_ai.exceptions.UserError] before a request is sent.
    """

    max_score_levels: ClassVar[int | None] = None
    """The most levels the backend accepts in one rubric, or `None` for no limit.

    The profile's `decision_max_score_levels` takes precedence where it is set. Whole numbers from 0 with more levels than this are not a rubric, so a field of them is asked as a pick-one
    instead, and counts against `max_choice_options`.
    """

    requires_instructions: ClassVar[bool] = False
    """Whether the backend refuses a question without `instructions`.

    The profile's `decision_requires_instructions` takes precedence where it is set. A pick-one, a rubric, or a
    yes/no with described answers can say what it asks through its options alone, so with no field description,
    output type docstring or agent `instructions` to send, such a question goes without `instructions`. A backend
    that requires them is sent a generic question instead, which leaves the options to carry the meaning, as they do
    without it.
    """

    # Retry feedback is a step taken for the prompt, so it goes along as a `retry` entry: translated, a validation
    # error would become the user text judged as the request, and a `ModelRetry` message a system prompt.
    _renders_retry_feedback = True

    @cached_property
    def profile(self) -> ModelProfile:
        """The model profile: text output off, inline system prompts on, and file input as the class takes it.

        A decision model answers questions and has no way to write text, so this is a fact about the class
        rather than a default to override: with text output left on, an `output_type` like `[Ticket, str]`
        would pass the shared request preparation and have its `str` branch silently never taken.

        It also judges a system prompt rather than asking it, so a system prompt partway through the conversation
        stays a `system` entry: without inline system prompts, the shared request preparation would fold it into
        the user text, where it would be judged as the request.

        Images are read only when the class sets
        [`supports_image_input`][pydantic_ai.models.decision.DecisionModel.supports_image_input], and documents,
        audio and video never are, so [`FileUnderstanding`][pydantic_ai.capabilities.FileUnderstanding] describes
        those files instead of letting them be refused, and a tool's file is otherwise replaced by a note.
        """
        return merge_profile(
            super().profile,
            ModelProfile(
                supports_text_output=False,
                supports_inline_system_prompts=True,
                supports_image_input=self.supports_image_input,
                supports_document_input=False,
                supports_audio_file_input=False,
                supports_video_input=False,
            ),
        )

    def prepare_messages(
        self,
        messages: list[ModelMessage],
        model_request_parameters: ModelRequestParameters | None = None,
    ) -> list[ModelMessage]:
        """Pre-process the history as [`Model.prepare_messages`][pydantic_ai.models.Model.prepare_messages] does.

        Changes to the deferred capability catalog are left out first: the capabilities are offered as routes of
        their own, so a catalog that changed since the conversation began, such as one with a capability added
        between runs, would otherwise reach the state as a system message repeating every description.
        """
        if model_request_parameters is not None and _loads_capabilities(model_request_parameters):
            messages = _without_catalog_changes(messages)
        return super().prepare_messages(messages, model_request_parameters)

    @abstractmethod
    async def decide(self, request: DecisionRequest, model_settings: DecisionModelSettings) -> DecisionResponse:
        """Send one request to the backend and return its answers.

        This is called once per request the model makes: once per step, or twice when a route is picked in one
        request and, past the size cutoff for asking every route's fields up front, filled in a second. Every
        question in `request.questions` needs an answer of the matching kind under the same name.
        Image-capable backends serialize `request.images` as evidence alongside `request.state`; other
        backends must reject a nonempty tuple, including when this method is called directly. Backend request
        limits also apply to direct calls. A backend that takes a conversation natively sends `request.messages`
        when there are any, in place of `request.state`.

        Raise [`ModelHTTPError`][pydantic_ai.exceptions.ModelHTTPError] or
        [`ModelAPIError`][pydantic_ai.exceptions.ModelAPIError] when the backend fails, so a
        [`FallbackModel`][pydantic_ai.models.fallback.FallbackModel] can take over;
        [`UnexpectedModelBehavior`][pydantic_ai.exceptions.UnexpectedModelBehavior] when it returns something that
        cannot be read; and [`UserError`][pydantic_ai.exceptions.UserError] when the request cannot be sent as
        given. Forward `timeout`, `extra_headers` and `extra_body` from `model_settings` where the backend
        supports them.
        """
        raise NotImplementedError()

    @asynccontextmanager
    async def _decide(
        self,
        request: DecisionRequest,
        model_settings: DecisionModelSettings,
        *,
        route: str | None = None,
        fields: bool = False,
        route_question: str | None = None,
        route_questions: Mapping[str, list[str]] | None = None,
    ) -> AsyncGenerator[tuple[DecisionResponse, Span]]:
        """Send one request through `decide()`, in a `decide` span when an instrumented request is open.

        Yields the response and the span, which stays open for the caller to record what the run made of the
        answers before it closes. Nothing more is sent inside it: a request that fills a picked route is a sibling
        of the one that picked it, not its child. Outside an instrumented request the span is a non-recording one.

        `route` is the label of the route whose fields this request asks, as the route question offers it, when it
        was or is being picked from others; `fields` says the request asks field questions at all; `route_question`
        is the key of the question that picks between routes, and `route_questions` the keys of the fields
        asked beside it, by the label of the route they belong to.

        A pick the step can't take is raised inside the span, as [`UnsureRoute`][pydantic_ai.models.decision.UnsureRoute]
        or [`UnfillableRoute`][pydantic_ai.models.decision.UnfillableRoute], and recorded on it like any other
        error, with the picked route's label on the exception event.
        """
        policy = open_request_policy()
        if policy is None:
            yield await self.decide(request, model_settings), INVALID_SPAN
            return
        include_content = policy.include_content
        with (
            policy.tracer.start_as_current_span(
                f'decide {self.model_name}',
                attributes=_decide_span_attributes(
                    self,
                    request,
                    model_settings,
                    route=route,
                    fields=fields,
                    route_question=route_question,
                    route_questions=route_questions,
                    include_content=include_content,
                ),
                kind=SpanKind.CLIENT,
                record_exception=False,
                set_status_on_exception=False,
            ) as span,
            record_uncaught_errors(span, include_content=include_content, event_attributes=_hand_off_attributes),
        ):
            response = await self.decide(request, model_settings)
            if span.is_recording():
                # A span that isn't recording, as a sampler can make it, keeps nothing, so nothing is built for it.
                span.set_attributes(_decide_response_attributes(response, request, route_question, include_content))
            yield response, span

    async def request(
        self,
        messages: list[ModelMessage],
        model_settings: ModelSettings | None,
        model_request_parameters: ModelRequestParameters,
    ) -> ModelResponse:
        check_allow_model_requests()
        # The one place a single output type's own name survives, since its tool is `final_result`. Read before
        # preparing, which drops `output_object` outside native and prompted output.
        output_name = output_object.name if (output_object := model_request_parameters.output_object) else None
        model_settings, model_request_parameters = self.prepare_request(model_settings, model_request_parameters)
        output_tools, hand_offs = _output_tools(model_request_parameters)
        # A withheld tool is not on any wire; one revealed through the history is, and the model sees the history.
        function_tools = _capability_routes(
            [
                tool
                for tool in model_request_parameters.function_tools
                if model_request_parameters.visibility_of(tool.name) != 'withheld'
            ],
            model_request_parameters.deferred_capabilities,
        )
        offered = [*hand_offs, *function_tools]
        tools, done = _tools_left(messages, offered)
        routes = _route_labels(output_tools, tools, output_name)
        forced_tool = _forced_tool(output_tools, tools, offered)
        if forced_tool is not None and not _has_fields(forced_tool):
            # Preserve the no-request path: there is no state or question to build when no arguments need filling.
            return self._forced(forced_tool, next(iter(routes)))
        instructions = self._instruction_text(messages, model_request_parameters)
        settings = cast(DecisionModelSettings, model_settings or {})
        # The bars are read before anything is sent: a setting outside 0 to 1 is a coding error, and finding
        # out from a rejected answer would mean paying for the request that carried the prompt and history.
        # An unset route bar is 0, which no probability is below, so every pick is taken.
        route_threshold = _threshold(settings, 'decision_route_threshold', 0.0)
        boolean_threshold = _threshold(settings, 'decision_boolean_threshold', _DEFAULT_BOOLEAN_THRESHOLD)
        # The model behind the URL sets its own limits through the profile, and the class's are the fallback.
        profile = cast(DecisionModelProfile, self.profile)
        limits = _Limits(
            choice_options=profile.get('decision_max_choice_options', self.max_choice_options),
            score_levels=profile.get('decision_max_score_levels', self.max_score_levels),
            requires_instructions=profile.get('decision_requires_instructions', self.requires_instructions),
            questions=self.max_questions,
        )
        if forced_tool is not None:
            # Every other route has returned this turn, so the one left is taken without a choice question.
            return await self._forced_with_arguments(
                forced_tool, next(iter(routes)), messages, instructions, settings, boolean_threshold, limits, turn=done
            )
        fillable = _fillable_outputs(output_tools, offered, instructions, limits)
        if not tools and len(output_tools) == 1:
            # One output type and nothing else on offer: there is no route to pick, only fields to fill.
            output_tool = output_tools[0]
            if not fillable:
                # Every other route has returned this turn, and the one left cannot be filled: it is taken without
                # a choice question, like the last tool left, and handing it off needs no request either.
                raise UnfillableRoute(self.model_name, next(iter(routes)), 1.0)
            ask = _Ask.about(output_tool, instructions, limits, label=None)
            state, image_inputs = self._map_decision_input(messages, turn=done)
            request = await self._prepare_decision_request(state, image_inputs, ask.questions, settings, messages)
            async with self._decide(request, settings, fields=True) as (
                response,
                span,
            ):
                args, provider_details, confidence = ask.answers(response, boolean_threshold)
                _record_outcome(span, confidence)
            return self._response(output_tool, args, response.usage, response.model_name, provider_details)

        route_questions: dict[str, DecisionQuestion] = {}
        route_key = _route_question(route_questions, routes, output_tools, tools, instructions, limits)
        state, image_inputs = self._map_decision_input(messages, turn=done)
        speculation = _Speculation.about(routes, output_tools, state, instructions, limits)
        questions = speculation.questions()
        questions.update(route_questions)
        request_template = await self._prepare_decision_request(state, image_inputs, questions, settings, messages)

        # The questions of a picked route whose fields are asked in a second request, past the size cutoff.
        to_fill: _Ask | None = None
        async with self._decide(
            request_template,
            settings,
            fields=bool(speculation.asks),
            route_question=route_key,
            route_questions={label: list(keys) for label, keys in speculation.keys.items()},
        ) as (response, span):
            route_details = _route_picked(response.answers.get(route_key), routes)
            label = route_details['choice']
            probability = route_details['probabilities'][label]
            # A pick the step can't take is raised here, inside the span of the request that picked it, so the span
            # records it. `UnsureRoute` and `UnfillableRoute` are `ModelAPIError`s, and a `FallbackModel` that gives
            # a language model the step ends the model request span without an error.
            if probability < route_threshold:
                raise UnsureRoute(self.model_name, label, route_details['probabilities'], route_threshold)
            route = routes[label]
            confidence = None
            if label in speculation.asks:
                # The fields were asked beside the route question, speculatively, and only the taken route's answers
                # are read: answers to a route not taken describe nothing in this response.
                args, provider_details, confidence = speculation.answers(label, response, boolean_threshold)
            else:
                args, provider_details, to_fill = self._unasked_route(route, label, probability, instructions, limits)
            _record_outcome(span, confidence)
        response_usage = response.usage

        if to_fill is not None:
            response, args, provider_details = await self._fill(
                label, to_fill, request_template, settings, boolean_threshold
            )
            response_usage += response.usage
            # `RequestUsage.requests` is fixed at 1, so usage cannot say that this turn asked twice: the
            # choice and the fill are two requests inside one step. The count is reported here, and only
            # here, so it appears exactly when it differs from what usage reports. See #8498.
            provider_details['requests'] = 2
        provider_details['route'] = route_details
        return self._response(route, args, response_usage, response.model_name, provider_details)

    def _instruction_text(
        self, messages: list[ModelMessage], model_request_parameters: ModelRequestParameters
    ) -> str | None:
        """The agent's instructions as one text, which the questions carry, or `None` without any."""
        instruction_parts = self._get_instruction_parts(messages, model_request_parameters) or []
        loads_capabilities = _loads_capabilities(model_request_parameters)
        return (
            '\n\n'.join(part.content for part in instruction_parts if not (loads_capabilities and _catalog(part)))
            or None
        )

    def _unasked_route(
        self, route: ToolDefinition, label: str, probability: float, instructions: str | None, limits: _Limits
    ) -> tuple[dict[str, Any], dict[str, Any], _Ask | None]:
        """The arguments, details and fill questions of a picked route whose fields were not asked beside the pick.

        A route with fields gets empty arguments and details, and the questions a second request fills it with.
        """
        if not _has_fields(route):
            # Nothing to write, so the call is made on the pick alone, and no answer built it.
            return _route_args(route), _unanswered(), None
        fill = _Ask.to_fill(route, instructions, limits, label=label)
        if fill is None:
            # A route whose fields the model cannot express is handed off before a request to fill it.
            raise UnfillableRoute(self.model_name, label, probability)
        # Filled once the picking request's span has closed: the fill is its sibling, not its child.
        return {}, {}, fill

    def _response(
        self,
        route: ToolDefinition,
        args: dict[str, Any],
        response_usage: RequestUsage,
        model_name: str,
        provider_details: dict[str, Any],
    ) -> ModelResponse:
        """The one tool call a decision model's step answers with."""
        return ModelResponse(
            parts=[ToolCallPart(route.name, args, _utils.generate_tool_call_id())],
            usage=response_usage,
            model_name=model_name,
            provider_name=self.system,
            provider_url=self.base_url,
            provider_details=provider_details,
            finish_reason='tool_call',
        )

    def _map_decision_input(
        self, messages: list[ModelMessage], *, turn: bool
    ) -> tuple[JsonValue, list[BinaryContent | ImageUrl]]:
        """Map history once, keeping image URLs unresolved until the request passes preflight."""
        image_inputs: list[BinaryContent | ImageUrl] = []
        state = _map_messages(messages, turn=turn, images=image_inputs if self.supports_image_input else None)
        return state, image_inputs

    def _check_request_limits(self, *, image_count: int = 0, question_count: int = 0) -> None:
        for kind, count, limit in (
            ('images', image_count, self.max_images),
            ('questions', question_count, self.max_questions),
        ):
            if limit is not None and count > limit:
                raise ModelAPIError(self.model_name, f'{self.model_name} accepts at most {limit} {kind}; got {count}.')

    async def _prepare_decision_request(
        self,
        state: JsonValue,
        image_inputs: list[BinaryContent | ImageUrl],
        questions: dict[str, DecisionQuestion],
        model_settings: DecisionModelSettings,
        messages: list[ModelMessage],
    ) -> DecisionRequest:
        """Validate a complete request before resolving its image URLs."""
        self._check_request_limits(image_count=len(image_inputs), question_count=len(questions))
        images: list[BinaryContent] = []
        for item in image_inputs:
            if isinstance(item, BinaryContent):
                images.append(item)
            else:
                downloaded = await download_item(item, data_format='bytes')
                image = BinaryContent(
                    downloaded['data'], media_type=downloaded['data_type'], vendor_metadata=item.vendor_metadata
                )
                if not image.is_image:
                    raise UserError(f'Image URL {item.url!r} returned content that is not an image.')
                images.append(image)
        return DecisionRequest(state=state, questions=questions, images=tuple(images), messages=messages)

    async def _fill(
        self,
        label: str,
        ask: _Ask,
        request_template: DecisionRequest,
        settings: DecisionModelSettings,
        boolean_threshold: float,
    ) -> tuple[DecisionResponse, dict[str, Any], dict[str, Any]]:
        """Ask a selected route's fields in a second request.

        One helper for both routes the model picks and then fills: a tool's arguments, and a union member's fields.
        They are the same two steps, and a route whose fields the model cannot express is the same hand-off either
        way, decided by the caller before this is reached, with `_Ask.to_fill`, and raised as
        [`UnfillableRoute`][pydantic_ai.models.decision.UnfillableRoute] inside the span of the request that picked
        it. This is also how a single output type the model cannot express is taken when tools or a `None` are on
        offer beside it: it is a route like any other.

        `label` is the route's name on the route question, from `_route_labels`, which the fill's questions carry in
        their premise, so that the model sees one name for one route across the two requests.
        """
        try:
            async with self._decide(
                dataclasses.replace(request_template, questions=ask.questions),
                settings,
                route=label,
                fields=True,
            ) as (response, span):
                args, provider_details, confidence = ask.answers(response, boolean_threshold)
                _record_outcome(span, confidence)
        except (ModelAPIError, UnexpectedModelBehavior) as e:
            # The first request committed to this route. Letting a fallback model rerun the whole original step
            # could silently choose another route, so a failure while filling is terminal and names that route.
            raise UnexpectedModelBehavior(
                f'{self.model_name} selected {label!r}, but failed while filling its fields: {e}'
            ) from e
        return response, args, provider_details

    async def _forced_with_arguments(
        self,
        tool: ToolDefinition,
        label: str,
        messages: list[ModelMessage],
        instructions: str | None,
        settings: DecisionModelSettings,
        boolean_threshold: float,
        limits: _Limits,
        *,
        turn: bool,
    ) -> ModelResponse:
        """Fill the arguments of the one route left, without a choice request."""
        fill = _Ask.to_fill(tool, instructions, limits, label=label)
        if fill is None:
            raise UnfillableRoute(self.model_name, label, 1.0)
        state, image_inputs = self._map_decision_input(messages, turn=turn)
        request_template = await self._prepare_decision_request(state, image_inputs, fill.questions, settings, messages)
        response, args, details = await self._fill(label, fill, request_template, settings, boolean_threshold)
        details['route'] = _forced_route(label)
        return self._response(tool, args, response.usage, response.model_name, details)

    def _forced(self, tool: ToolDefinition, label: str) -> ModelResponse:
        """Call the one argumentless route left, without asking the model."""
        details = {**_unanswered(), 'route': _forced_route(label)}
        return ModelResponse(
            parts=[ToolCallPart(tool.name, _route_args(tool), _utils.generate_tool_call_id())],
            usage=usage.RequestUsage(),
            model_name=self.model_name,
            provider_name=self.system,
            provider_url=self.base_url,
            provider_details=details,
            finish_reason='tool_call',
        )

    @asynccontextmanager
    async def request_stream(
        self,
        messages: list[ModelMessage],
        model_settings: ModelSettings | None,
        model_request_parameters: ModelRequestParameters,
        run_context: RunContext[Any] | None = None,
    ) -> AsyncGenerator[StreamedResponse]:
        # The answers arrive in one piece, so the whole answer is the one event; a streamed run keeps working.
        response = await self.request(messages, model_settings, model_request_parameters)
        yield DecisionStreamedResponse(model_request_parameters, response)


@dataclass
class DecisionStreamedResponse(StreamedResponse):
    """A decision model's whole answer as one event, so that a streamed run works on a model that cannot stream."""

    _response: ModelResponse

    def __post_init__(self):
        self._usage = self._response.usage
        self.provider_details = self._response.provider_details
        self.finish_reason = self._response.finish_reason

    async def close_stream(self) -> None:
        """No live stream to close: the whole answer was in hand before the first event."""

    async def _get_event_iterator(self) -> AsyncIterator[ModelResponseStreamEvent]:
        for i, part in enumerate(self._response.parts):
            assert isinstance(part, ToolCallPart)  # `request` builds nothing else
            # `ToolCallPart` subclasses narrow `args` to a `TypedDict`; the parts manager takes the plain union.
            yield self._parts_manager.handle_tool_call_part(
                vendor_part_id=i,
                tool_name=part.tool_name,
                args=cast('str | dict[str, Any] | None', part.args),
                tool_call_id=part.tool_call_id,
            )

    @property
    def model_name(self) -> str:
        return self._response.model_name or ''

    @property
    def provider_name(self) -> str | None:
        return self._response.provider_name

    @property
    def provider_url(self) -> str | None:
        return self._response.provider_url

    @property
    def timestamp(self) -> datetime:
        return self._response.timestamp


_DEFAULT_BOOLEAN_THRESHOLD = 0.5


def _hand_off_attributes(error: Exception) -> dict[str, AttributeValue]:
    """The label of the picked route a hand-off names, for its exception event.

    The exception's message names it too, but a message is only recorded with content, and a label is not content.
    """
    return {'pydantic_ai.decision.route': error.route} if isinstance(error, DecisionHandOff) else {}


# What each kind of answer keeps without content: its numbers, and what they are keyed by only where that is not
# content. A score's probabilities are keyed by level numbers; a choice's are keyed by option labels, which can quote
# the text being judged, as can the picked choice itself and a rubric's legend.
_NUMERIC_ANSWER_FIELDS: dict[str, tuple[str, ...]] = {
    'noul': ('noul',),
    'choice': ('confidence',),
    'score': ('score', 'confidence', 'probabilities'),
}


def _decide_span_attributes(
    model: DecisionModel[Any],
    request: DecisionRequest,
    settings: DecisionModelSettings,
    *,
    route: str | None,
    fields: bool,
    route_question: str | None,
    route_questions: Mapping[str, list[str]] | None,
    include_content: bool,
) -> dict[str, AttributeValue]:
    """A `decide` span's attributes from the request, before it is sent.

    The questions are always recorded by type, keyed like the answers, so a trace shows what kind of decision was
    asked even without content; their instructions and criteria are the user's words, and need `include_content`.
    The routes are recorded by their labels, the names of the user's tools and output types, which are not
    content, so they are recorded either way.
    """
    questions = {
        name: _wire(question) if include_content else {'type': question.type}
        for name, question in request.questions.items()
    }
    thresholds = {'boolean': _threshold(settings, 'decision_boolean_threshold', _DEFAULT_BOOLEAN_THRESHOLD)}
    if 'decision_route_threshold' in settings:
        # Unset, every pick is taken, which no number says better than its absence.
        thresholds['route'] = _threshold(settings, 'decision_route_threshold', 0.0)
    attributes: dict[str, AttributeValue] = {
        'gen_ai.operation.name': 'decide',
        **model_attributes(model),
        'pydantic_ai.decision.questions': safe_to_json(questions).decode(),
        'pydantic_ai.decision.thresholds': safe_to_json(thresholds).decode(),
    }
    json_attributes = ['pydantic_ai.decision.questions', 'pydantic_ai.decision.thresholds']
    if route is not None:
        attributes['pydantic_ai.decision.route'] = route
    if fields:
        # Set once the response is in, and declared here with the rest.
        json_attributes.append('pydantic_ai.decision.confidence')
    if route_question is not None:
        question = request.questions[route_question]
        assert isinstance(question, ChoiceQuestion)  # `_tool_question` asks nothing else
        attributes['pydantic_ai.decision.route_question'] = route_question
        attributes['pydantic_ai.decision.route_options'] = safe_to_json(list(question.criteria)).decode()
        json_attributes.append('pydantic_ai.decision.route_options')
    if route_questions:
        # Which route each field question belongs to. The keys can't be split to tell: a label and a nested field's
        # name can both contain dots.
        attributes['pydantic_ai.decision.route_questions'] = safe_to_json(route_questions).decode()
        json_attributes.append('pydantic_ai.decision.route_questions')
    if include_content:
        # The state is text or JSON, as a backend that sends it puts it on the wire, and only JSON is declared as such.
        # A backend that sends `request.messages` instead puts the conversation the model request span records.
        if isinstance(request.state, str):
            attributes['pydantic_ai.decision.state'] = request.state
        else:
            attributes['pydantic_ai.decision.state'] = safe_to_json(request.state).decode()
            json_attributes.append('pydantic_ai.decision.state')
    json_attributes.append('pydantic_ai.decision.answers')
    attributes['logfire.json_schema'] = safe_to_json(
        {
            'type': 'object',
            'properties': {
                name: {'type': 'array' if name == 'pydantic_ai.decision.route_options' else 'object'}
                for name in json_attributes
            },
        }
    ).decode()
    return attributes


def _decide_response_attributes(
    response: DecisionResponse, request: DecisionRequest, route_question: str | None, include_content: bool
) -> dict[str, AttributeValue]:
    """A `decide` span's attributes from the response.

    Usage is this request's alone, and deliberately not `gen_ai.usage.*`: the `chat` span above reports the sum of its
    requests there, and a backend that adds up usage across spans would count it twice.

    The answers are what the backend sent, so recording them must not be able to fail the request: whatever goes
    wrong reading them for the span leaves them out of it, and the request goes on as it would uninstrumented.
    """
    attributes: dict[str, AttributeValue] = {
        'gen_ai.response.model': response.model_name,
        'pydantic_ai.decision.usage.input_tokens': response.usage.input_tokens,
        'pydantic_ai.decision.usage.output_tokens': response.usage.output_tokens,
    }
    if response.provider_response_id is not None:
        attributes['gen_ai.response.id'] = response.provider_response_id
    offered: frozenset[str] = frozenset()
    if route_question is not None and isinstance(question := request.questions.get(route_question), ChoiceQuestion):
        offered = frozenset(question.criteria)
    try:
        answers = {
            name: _answer_attribute(
                answer, include_content=include_content, offered=offered if name == route_question else None
            )
            for name, answer in response.answers.items()
            # Not an answer at all, from a backend breaking its contract, is left out. The run rejects it as it would
            # without instrumentation, with `UnexpectedModelBehavior`, which the span records.
            if isinstance(answer, NoulAnswer | ChoiceAnswer | ScoreAnswer)
        }
        attributes['pydantic_ai.decision.answers'] = safe_to_json(answers).decode()
    except Exception:
        # Instrumentation must not fail an otherwise-successful request, as a backend's answer nested too deeply to
        # serialize would; the span is left without the answers rather than with a partial or misleading set.
        pass
    return attributes


def _answer_attribute(
    answer: DecisionAnswer, *, include_content: bool, offered: frozenset[str] | None
) -> dict[str, Any]:
    """One answer as a `decide` span records it.

    With content, it's the answer as received. Without content, it keeps its type and numbers, built from those
    fields alone: a score its level probabilities too, which are keyed by number, but not a choice its option
    probabilities, nor the picked option or a rubric's legend, which can quote the state. A `type` the protocol
    doesn't have keeps nothing else.

    The route question's answer, `offered` being the labels its request offered, keeps its pick and probabilities
    without content, as they are route labels: the names of the user's tools and output types. Only those labels
    are kept, as a backend could answer with any string, and a pick or probability under a label that wasn't
    offered is left out.
    """
    if include_content:
        return _wire(answer)
    if offered is not None and isinstance(answer, ChoiceAnswer):
        return _route_answer_attribute(answer, offered)
    attribute: dict[str, Any] = {'type': answer.type}
    for name in _NUMERIC_ANSWER_FIELDS.get(answer.type, ()):
        value = getattr(answer, name, None)
        if name == 'probabilities' and isinstance(value, Mapping):
            attribute[name] = {
                level: p
                for level, p in cast(Mapping[object, object], value).items()
                if _is_number(level) and _is_number(p)
            }
        elif _is_number(value):
            attribute[name] = value
    return attribute


def _route_answer_attribute(answer: ChoiceAnswer, offered: frozenset[str]) -> dict[str, Any]:
    """The route question's answer as a `decide` span records it without content, keeping only `offered` labels."""
    attribute: dict[str, Any] = {'type': answer.type}
    if answer.choice in offered:
        attribute['choice'] = answer.choice
    if _is_number(answer.confidence):
        attribute['confidence'] = answer.confidence
    attribute['probabilities'] = {
        label: p for label, p in answer.probabilities.items() if label in offered and _is_number(p)
    }
    return attribute


def _is_number(value: object) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool)


def _record_outcome(span: Span, confidence: dict[str, float] | None) -> None:
    """Record on a `decide` span the confidence of the answers the step used, which is not content.

    `confidence` is the thresholded confidence per field question, keyed like the questions, or `None` when the
    step used none of the span's field answers.
    """
    if confidence is not None and span.is_recording():
        # Always recorded, so only numbers: a backend could put anything where its confidence belongs.
        numbers = {key: value for key, value in confidence.items() if _is_number(value)}
        span.set_attribute('pydantic_ai.decision.confidence', safe_to_json(numbers).decode())


def _threshold(settings: DecisionModelSettings, name: str, default: float) -> float:
    """A probability setting, which is only meaningful inside the range the model answers in."""
    threshold = cast(float, settings.get(name, default))
    if not 0 <= threshold <= 1:
        raise UserError(f'`{name}` must be between 0 and 1; got {threshold!r}.')
    return threshold


def _fanned_in(
    name: str, options: Mapping[Any, Any], answers: Mapping[str, object], boolean_threshold: float
) -> tuple[dict[str, tuple[bool, float]], dict[str, float]]:
    """Read back the yes/no per option that `_fan_out` asked, as verdicts and as the raw probabilities.

    A list and a mapping ask the same questions and differ only in how the verdicts are shaped afterwards.
    """
    labelled: dict[str, float] = {}
    for option in options:
        answer = answers.get(f'{name}.{option}')
        if not isinstance(answer, NoulAnswer):
            raise UnexpectedModelBehavior(
                f'Unexpected answer from the model for output field {name!r}, option {option!r}: {answer!r}'
            )
        labelled[option] = answer.noul
    return {option: _verdict(p, boolean_threshold) for option, p in labelled.items()}, labelled


def _verdict(probability: float, threshold: float) -> tuple[bool, float]:
    """Whether the probability of yes clears the bar, and how far from the bar it landed.

    A yes/no is answered with the probability of yes and no confidence of its own, so what is lost in rounding the
    probability to an answer is how sure that answer is. That is the distance from the bar, scaled to run 0 to 1 on
    whichever side of it the answer fell — like the confidence reported for the other two kinds of question. Under
    the default bar of 0.5 this is the distance from the coin flip, doubled: a no returned at 0.01 reports 0.98.
    """
    if not 0 <= probability <= 1:
        # Both scalings divide by the room left on their side of the bar, which a probability outside 0 to 1
        # can make zero. A malformed answer is the model's to report, not a crash.
        raise UnexpectedModelBehavior(f'Unexpected probability from the model: {probability!r}')
    if probability >= threshold:
        # An answer exactly at the bar is the least sure one there is, including when the bar is certainty.
        sureness = (probability - threshold) / (1 - threshold) if threshold < 1 else 0.0
    else:
        sureness = (threshold - probability) / threshold
    # The arithmetic leaves float noise, as 0.8600000000000001 for 0.86, which six places remove without losing
    # anything a probability from the model carries. A fanned-out field's confidence is the least of these, so it
    # is rounded too.
    return probability >= threshold, round(sureness, 6)


def _answers(
    answers: Mapping[str, object],
    properties: dict[str, dict[str, Any]],
    questions: dict[str, DecisionQuestion],
    boolean_threshold: float,
    defaulted: frozenset[str],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, float]]:
    """The output's arguments and `provider_details` from the model's answers to the field questions.

    Also each question's confidence, keyed like the questions: `provider_details['confidence']` is keyed by field,
    and gives a field that fans out the least sure of its options, where this keeps each option's own.
    """
    read = _ReadAnswers()
    for name, prop in properties.items():
        prop, none_option = _optional(prop)
        if keys := _mapping_options(prop):
            _read_mapping(read, name, keys, answers, boolean_threshold)
            continue
        if prop.get('type') == 'array':
            _read_list(read, name, prop, answers, boolean_threshold)
            continue
        answer = answers.get(name)
        match questions[name], answer:
            case NoulQuestion(), NoulAnswer():
                _read_noul(read, name, prop, answer, boolean_threshold)
            case ChoiceQuestion(), ChoiceAnswer():
                _read_choice(read, name, prop, properties[name], none_option, answer)
            case ScoreQuestion(), ScoreAnswer():
                _read_score(read, name, answer)
            case _:
                raise UnexpectedModelBehavior(f'Unexpected answer from the model for output field {name!r}: {answer!r}')
    _leave_out_unanswered(read.args, properties, defaulted)
    details = {'confidence': read.confidence, 'probabilities': read.probabilities, 'scores': read.scores}
    return read.args, details, read.by_question


@dataclass
class _ReadAnswers:
    """What `_answers` reads back from the answers to the field questions, field by field."""

    args: dict[str, Any] = field(default_factory=dict[str, Any])
    confidence: dict[str, float] = field(default_factory=dict[str, float])
    by_question: dict[str, float] = field(default_factory=dict[str, float])
    probabilities: dict[str, dict[str, float]] = field(default_factory=dict[str, dict[str, float]])
    scores: dict[str, float] = field(default_factory=dict[str, float])


def _read_mapping(
    read: _ReadAnswers, name: str, keys: dict[Any, str | None], answers: Mapping[str, object], boolean_threshold: float
) -> None:
    # A mapping keeps every option with the answer it got, unlike a list.
    verdicts, labelled = _fanned_in(name, keys, answers, boolean_threshold)
    _set(read.args, name, {key: chosen for key, (chosen, _) in verdicts.items()})
    _read_verdicts(read, name, verdicts, labelled)


def _read_list(
    read: _ReadAnswers, name: str, prop: dict[str, Any], answers: Mapping[str, object], boolean_threshold: float
) -> None:
    # A list is the options that came back yes, in their order.
    verdicts, labelled = _fanned_in(name, _options(prop['items']) or {}, answers, boolean_threshold)
    _set(read.args, name, [option for option, (chosen, _) in verdicts.items() if chosen])
    _read_verdicts(read, name, verdicts, labelled)


def _read_verdicts(
    read: _ReadAnswers, name: str, verdicts: dict[str, tuple[bool, float]], labelled: dict[str, float]
) -> None:
    """The confidence and probabilities of a field that fans out, from its options' verdicts."""
    read.confidence[name] = min(sureness for _, sureness in verdicts.values())
    read.by_question.update({f'{name}.{option}': sureness for option, (_, sureness) in verdicts.items()})
    read.probabilities[name] = labelled


def _read_noul(
    read: _ReadAnswers, name: str, prop: dict[str, Any], answer: NoulAnswer, boolean_threshold: float
) -> None:
    if (bound := _bounded(prop)) is not None:
        # The probability is the answer, so there is no separate confidence to report: a field
        # that asks for the number would otherwise get it back twice under two names. The bound is
        # the units it is asked in, so the same answer comes back as 0.42 or as 42.
        _set(read.args, name, answer.noul * bound)
    else:
        chosen, sureness = _verdict(answer.noul, boolean_threshold)
        _set(read.args, name, chosen)
        read.confidence[name] = read.by_question[name] = sureness


def _read_choice(
    read: _ReadAnswers,
    name: str,
    prop: dict[str, Any],
    declared: dict[str, Any],
    none_option: dict[str, str],
    answer: ChoiceAnswer,
) -> None:
    if answer.choice not in none_option:
        # The option itself is written back, looked up by its label rather than parsed out of it: `1`
        # and `'1'` are two options, and only the lookup knows which one the label stood for.
        labelled = _labelled(_options(prop) or {})
        _set(read.args, name, labelled.get(answer.choice, answer.choice))
    elif 'default' in declared:
        # "None of these" is the absence of an answer, and a default says what to use when there is
        # none, so the field is left out for Pydantic to fill in. The model it belongs to is still put
        # in place, to apply the default in, unless that model has a default of its own to apply instead.
        _slot(read.args, name)
    else:
        _set(read.args, name, None)
    read.confidence[name] = read.by_question[name] = answer.confidence
    read.probabilities[name] = answer.probabilities


def _read_score(read: _ReadAnswers, name: str, answer: ScoreAnswer) -> None:
    # `score` is a position along the rubric and falls between levels. The answer has to be one of them,
    # so it is rounded to the nearest; the likeliest level would throw away the ordering that makes a
    # rubric a rubric. A half goes up, unlike `round`.
    _set(read.args, name, min(int(answer.score + 0.5), max(answer.probabilities)))
    read.confidence[name] = read.by_question[name] = answer.confidence
    read.probabilities[name] = {str(level): p for level, p in answer.probabilities.items()}
    read.scores[name] = answer.score


def _route_picked(answer: object, routes: dict[str, ToolDefinition]) -> dict[str, Any]:
    """The model's answer to the route question, as `provider_details['route']` reports it.

    Everything in it is a route label, the name the route question offered each route under, looked up in
    `routes`. The pick is reported with its probabilities and what was on offer, so the rate at which picks fall
    below a `decision_route_threshold` can be watched, and a tool that was withheld this turn can be seen to have been.
    """
    if (
        not isinstance(answer, ChoiceAnswer)
        or answer.choice not in answer.probabilities
        or not all(0 <= p <= 1 for p in answer.probabilities.values())
    ):
        raise UnexpectedModelBehavior(f'Unexpected answer from the model for the route question: {answer!r}')
    if answer.choice not in routes:
        raise UnexpectedModelBehavior(f'The model picked a route it was not offered: {answer.choice!r}')
    return {'choice': answer.choice, 'probabilities': dict(answer.probabilities), 'offered': list(routes)}


def _forced_route(label: str) -> dict[str, Any]:
    """`provider_details['route']` for the one route left, taken without asking: certain, because it was alone."""
    return {'choice': label, 'probabilities': {label: 1.0}, 'offered': [label]}


def _unanswered() -> dict[str, Any]:
    """`provider_details` for a response no answer built: a route taken on the pick alone has no fields to report."""
    return {'confidence': {}, 'probabilities': {}, 'scores': {}}


def _expressible(tool: ToolDefinition, instructions: str | None, limits: _Limits) -> bool:
    """Whether the model could fill this route's fields, decided without sending anything."""
    try:
        _Ask.about(tool, instructions, limits, label=None)
    except UserError:
        return False
    return True


def _fillable_outputs(
    output_tools: list[ToolDefinition], offered: list[ToolDefinition], instructions: str | None, limits: _Limits
) -> list[ToolDefinition]:
    """The output tools whose fields the model can fill, or a `UserError` if every route would be handed off."""
    fillable = [tool for tool in output_tools if _expressible(tool, instructions, limits)]
    if (
        output_tools
        and not fillable
        and not any(
            _none_route(tool) or _capability_id(tool) is not None or _expressible(tool, instructions, limits)
            for tool in offered
        )
    ):
        # A route the model cannot fill is a hand-off, but only while some other route is a real alternative:
        # an output type it can fill, a route with nothing to fill, or a tool whose arguments it can. With
        # none of them the choice is decided before it is asked: every answer hands off, so the request that
        # asks it buys nothing, and every run pays for the decision model on top of the model behind it.
        if len(output_tools) == 1:
            # Alone, the output type's own unsupported field is the error, as it names what to change.
            _Ask.about(output_tools[0], instructions, limits, label=None)
        raise UserError(
            'None of the output types can be filled by this model, so every answer would be handed off and '
            'the request asking which would be wasted. Give the agent an `output_type` it can fill, or drop '
            'it from this model.'
        )
    return fillable


def _forced_tool(
    output_tools: list[ToolDefinition], tools: list[ToolDefinition], offered: list[ToolDefinition]
) -> ToolDefinition | None:
    """The one tool left to take without a choice question.

    That is the route left once every other route on offer has returned, or a lone capability to load: loading it
    is the only thing to do, and there is no other route to ask about.
    """
    if output_tools or len(tools) != 1:
        return None
    return tools[0] if len(offered) > 1 or _capability_id(tools[0]) is not None else None


_REQUEST_TOKENS = 260
"""About how many tokens a request costs before its state and questions: what a second request adds besides them."""

_SPECULATION_TOKENS = 16_000
"""The most tokens a request that asks every route's fields up front is allowed to grow to."""

_STATE_CHARS_PER_TOKEN = 6
_QUESTION_CHARS_PER_TOKEN = 4
"""How many characters of JSON make a token, near enough to size a request before it is sent.

Prose, as a state mostly is, packs more characters into a token than a question's labels and punctuation do; both
were fitted on requests to `jev-latest`, where they recover each request's input tokens to within a few percent.
"""


def _state_tokens(state: JsonValue) -> float:
    return len(json.dumps(state, ensure_ascii=False)) / _STATE_CHARS_PER_TOKEN


def _question_tokens(questions: Mapping[str, DecisionQuestion]) -> float:
    return (
        sum(len(json.dumps(dataclasses.asdict(question), ensure_ascii=False)) for question in questions.values())
        / _QUESTION_CHARS_PER_TOKEN
    )


@dataclass(frozen=True)
class _Speculation:
    """The routes whose fields are asked beside the route question, before the pick, so the pick needs no fill.

    Asking a route's fields only once it is picked costs a second request, with the state sent again. Asking every
    route's fields up front costs the questions of the routes that are not taken, which the model answers and the
    run throws away. So every route the model can fill is asked up front while those questions cost no more than the
    request they save, and the request stays small enough to answer as quickly as a small one; past that, a route is
    picked first and filled after, and only a single output type beside tools is still asked up front, as it always
    has been. A route the model cannot fill is never asked, a single output type included: picking it hands the step
    off, so for the cost it is a route with nothing to ask, whose pick would throw every question away.

    Each route's questions are keyed `'<label>.<field>'`, so the same field name on two routes is two questions. A
    question's key is for reading its answer back, not something the model sees, so a key that collides, as a label
    with a dot in it can make one, just gets `_` appended; the answers are read back by the keys each route was
    given, never by parsing one.
    """

    asks: dict[str, _Ask]
    keys: dict[str, dict[str, str]]
    """Per route label, each of its own question keys by the key it was asked under."""

    @classmethod
    def about(
        cls,
        routes: dict[str, ToolDefinition],
        output_tools: list[ToolDefinition],
        state: JsonValue,
        instructions: str | None,
        limits: _Limits,
    ) -> _Speculation:
        asks = _fillable_asks(routes, instructions, limits)
        sizes = {label: _question_tokens(ask.questions) for label, ask in asks.items()}
        state_tokens = _state_tokens(state)
        # The route taken is not known yet, so the questions thrown away are all but the smallest route's, at most,
        # and all of them when the route taken could be one with nothing asked about it.
        smallest = min(sizes.values()) if len(sizes) == len(routes) else 0
        unpicked = sum(sizes.values()) - smallest
        if (
            unpicked > _REQUEST_TOKENS + state_tokens
            or state_tokens + sum(sizes.values()) > _SPECULATION_TOKENS
            or (
                limits.questions is not None and 1 + sum(len(ask.questions) for ask in asks.values()) > limits.questions
            )
        ):
            asks = {
                label: ask for label, ask in asks.items() if routes[label] in output_tools and len(output_tools) == 1
            }
        if limits.questions is not None and 1 + sum(len(ask.questions) for ask in asks.values()) > limits.questions:
            asks = {}
        return cls(asks, _scoped_keys(asks))

    def questions(self) -> dict[str, DecisionQuestion]:
        """Every speculated route's questions, under their scoped keys."""
        return {
            scoped: self.asks[label].questions[key] for label, keys in self.keys.items() for scoped, key in keys.items()
        }

    def answers(
        self, label: str, response: DecisionResponse, boolean_threshold: float
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, float]]:
        """The taken route's arguments and details, from the answers to its own questions alone.

        Also each of its questions' confidence, keyed as it was asked, under its scoped key.
        """
        keys = self.keys[label]
        own = {key: response.answers.get(scoped) for scoped, key in keys.items()}
        args, details, confidence = self.asks[label].read(own, boolean_threshold)
        # A question of a field that fans out gets its option's key appended, so the scoped key is found the same way.
        scoped_by_key = {key: scoped for scoped, key in keys.items()}
        return args, details, {scoped_by_key[key]: value for key, value in confidence.items()}


def _fillable_asks(routes: dict[str, ToolDefinition], instructions: str | None, limits: _Limits) -> dict[str, _Ask]:
    """The questions of each route with fields to fill that the model can fill, by route label."""
    asks: dict[str, _Ask] = {}
    for label, route in routes.items():
        if _has_fields(route):
            try:
                asks[label] = _Ask.about(route, instructions, limits, label=label)
            except UserError:
                # Picking a route the model cannot fill hands the step off, a single output type's included,
                # so there is nothing to ask about it; it still counts as a route that could be taken.
                continue
    return asks


def _scoped_keys(asks: dict[str, _Ask]) -> dict[str, dict[str, str]]:
    """Per route label, each of its question keys by the key it is asked under, `'<label>.<key>'` made unique."""
    keys: dict[str, dict[str, str]] = {}
    taken: set[str] = set()
    for label, ask in asks.items():
        keys[label] = {}
        for key in ask.questions:
            scoped = f'{label}.{key}'
            while scoped in taken:
                scoped += '_'
            taken.add(scoped)
            keys[label][scoped] = key
    return keys


_NONE_OF_THESE = 'None of these.'


def _null(schema: dict[str, Any] | bool) -> bool:
    """Whether a schema is `None`, whatever else the user wrote about it.

    Pydantic renders a bare `None` as `{'type': 'null'}`, but `Annotated[None, Field(description=...)]` — how a
    user says what returning nothing means — renders the description beside it. The type is what makes it `None`;
    the rest is the user's own words, and a route or a field is no less `None` for having some.
    """
    return isinstance(schema, dict) and schema.get('type') == 'null'


def _none_route(tool: ToolDefinition) -> bool:
    """Whether this output tool is the `None` member of a union: a route that returns nothing.

    Pydantic AI wraps a bare `None` output type in an object with one `null` property, so the route has a field
    in its schema and yet only one value that field could ever take. There is nothing to ask about it: it is one
    more option to pick, the same thing `_optional` makes of an `X | None` field one level down.
    """
    properties = list(_properties(tool.parameters_json_schema).values())
    return tool.kind == 'output' and len(properties) == 1 and _null(properties[0])


def _has_fields(tool: ToolDefinition) -> bool:
    """Whether a route has fields for the model to fill.

    It is not the `None` route or a capability to load, whose `id` `_capability_routes` fixed, and its schema has
    properties.
    """
    return not _none_route(tool) and _capability_id(tool) is None and bool(_properties(tool.parameters_json_schema))


def _route_args(tool: ToolDefinition) -> dict[str, Any]:
    """The arguments to call a route with when nothing is filled.

    None, the `None` a `None` route wraps, or the `id` of the capability a capability route loads.
    """
    if (capability_id := _capability_id(tool)) is not None:
        return {'id': capability_id}
    return {name: None for name in _properties(tool.parameters_json_schema)} if _none_route(tool) else {}


def _capability_routes(tools: list[ToolDefinition], catalog: list[DeferredCapabilityEntry]) -> list[ToolDefinition]:
    """The tools on offer, with `load_capability` as one route per capability it can still load.

    `load_capability` takes a plain string `id`, which a decision model cannot fill, so offered as it is the tool
    could only hand off. The step's catalog, in
    [`ModelRequestParameters.deferred_capabilities`][pydantic_ai.models.ModelRequestParameters.deferred_capabilities],
    says which ids it can load and what each is for, and each becomes a route of its own, described by the
    capability's description and taken on the pick alone. The route question then weighs each capability against
    the tools and output types directly, instead of a generic "load a capability" followed by a second request
    asking which. A capability already active, whether the model or code loaded it, is not offered again, since
    loading it twice is refused. The loader is found by its `tool_kind`, whatever it is called. A language model's
    `load_capability` is unchanged: the ids stay out of its schema so the tools it is sent, and the prompt cache
    behind them, do not depend on what can be loaded.
    """
    if not catalog:
        return tools
    routes: list[ToolDefinition] = []
    for tool in tools:
        if tool.tool_kind != 'capability-load':
            routes.append(tool)
            continue
        routes.extend(
            replace(
                tool,
                description=entry.description,
                parameters_json_schema={
                    'type': 'object',
                    'properties': {'id': {'const': entry.id}},
                    'required': ['id'],
                },
            )
            for entry in catalog
            if not entry.active
        )
    return routes


def _capability_id(tool: ToolDefinition) -> str | None:
    """The capability a route from `_capability_routes` loads, or `None` for any other route."""
    if tool.tool_kind != 'capability-load':
        return None
    capability_id = _properties(tool.parameters_json_schema).get('id', {}).get('const')
    return capability_id if isinstance(capability_id, str) else None


def _loads_capabilities(model_request_parameters: ModelRequestParameters) -> bool:
    """Whether the request offers a capability loader, the only thing that makes a part keyed like the catalog one.

    A capability can have the id `deferred_capabilities` too, and its instructions are only told apart from the
    catalog by the loader that comes with the catalog.
    """
    return any(tool.tool_kind == 'capability-load' for tool in model_request_parameters.function_tools)


def _catalog(part: InstructionPart) -> bool:
    """Whether an instruction part is the deferred capability catalog, which `_capability_routes` offers as routes.

    Sent as shared framing, it would repeat every capability's description on every question, fields included,
    whatever route is being asked about.
    """
    return part.id == _CATALOG_INSTRUCTION_ID


def _without_catalog_changes(messages: list[ModelMessage]) -> list[ModelMessage]:
    """`messages` without the catalog's appended changes, which `_catalog` leaves out of the framing likewise."""
    result: list[ModelMessage] = []
    for message in messages:
        if isinstance(message, ModelRequest) and any(
            isinstance(part, InstructionDeltaPart) and part.id == _CATALOG_INSTRUCTION_ID for part in message.parts
        ):
            message = replace(
                message,
                parts=[
                    part
                    for part in message.parts
                    if not (isinstance(part, InstructionDeltaPart) and part.id == _CATALOG_INSTRUCTION_ID)
                ],
            )
        result.append(message)
    return result


def _wrapped(tool: ToolDefinition) -> dict[str, Any] | None:
    """The single property Pydantic AI wraps an output type that is not object-like in, if this is one.

    A `Literal`, an `Enum`, a `Choices` set and a bare `None` all reach a model as one property of an object,
    because only an object can be a tool's arguments. What such a type says about itself is written on that
    property, since there is no class for it to be a docstring on. `outer_typed_dict_key` is the wrapping,
    named by whoever did it, so it is read rather than guessed back out of the schema's shape.
    """
    key = tool.outer_typed_dict_key
    return _properties(tool.parameters_json_schema).get(key) if key else None


def _purpose(tool: ToolDefinition) -> str | None:
    """What a route says about itself, wherever it managed to say it.

    An output type says this in its docstring, and `ToolOutput(description=...)` says it for a type that has
    no docstring to write it in. A type that is not object-like has neither: `Choices(description=...)`
    describes the set it wraps, which lands on the wrapped property rather than on the tool. It is the same
    sentence either way, so the route question reads it from there too.
    """
    if described := _described(tool):
        return described
    wrapped = _wrapped(tool)
    if wrapped is None:
        return None
    # An `Enum` is wrapped as a `$ref` to its own definition, which is where its docstring is.
    return _resolved(wrapped, tool.parameters_json_schema).get('description')


def _route_description(tool: ToolDefinition) -> str | None:
    """What a route says about itself on the route question.

    A `None` route can say nothing anywhere, so the library supplies the phrase — unless the user named the
    route themselves, which says more about what declining means on this agent than the stock phrase does.
    """
    if _none_route(tool):
        return _purpose(tool) or _NONE_OF_THESE
    return _purpose(tool) or tool.description


def _output_tools(
    model_request_parameters: ModelRequestParameters,
) -> tuple[list[ToolDefinition], list[ToolDefinition]]:
    """The output tools with fields for the model to fill, and the ones that take no arguments.

    An output function that takes nothing, or only the run context, is a hand-off the model can pick without
    filling anything. Several output types with fields are a union: the model picks which one the text calls for,
    then fills that one's fields in a second request, the same two steps a selected tool's arguments take. Text
    output is refused earlier, by the shared request preparation, on the profile's `supports_text_output`.
    """
    with_fields: list[ToolDefinition] = []
    hand_offs: list[ToolDefinition] = []
    for tool in model_request_parameters.output_tools:
        (with_fields if _has_fields(tool) else hand_offs).append(tool)
    return with_fields, hand_offs


def _schema(node: dict[str, Any] | bool) -> dict[str, Any]:
    """A schema as an object. JSON Schema allows `true` and `false` anywhere a schema goes, for anything and nothing.

    Pydantic never renders them, but a hand-written schema, as `Tool.from_schema` takes, may (see #8621). As objects
    they are `{}` and `{'not': {}}`, which ask the model nothing it can answer, so a field of either is unsupported.
    """
    if isinstance(node, bool):
        return {} if node else {'not': {}}
    return node


def _resolved(schema: dict[str, Any], root: dict[str, Any] | None = None) -> dict[str, Any]:
    """A schema through its `$ref` to `root`'s `$defs`, with what the referring schema says beside it taking precedence.

    `root` is the schema the `$defs` are on, which is `schema` itself for the top-level `$ref` Pydantic renders a
    model that refers to itself as.
    """
    if not (ref := schema.get('$ref')):
        return schema
    definition = _schema((root or schema)['$defs'][ref.removeprefix('#/$defs/')])
    return {**definition, **{k: v for k, v in schema.items() if k not in ('$ref', '$defs')}}


def _properties(schema: dict[str, Any]) -> dict[str, Any]:
    """A schema's properties, through the top-level `$ref` Pydantic renders a model that refers to itself as."""
    return _resolved(schema).get('properties', {})


@dataclass(frozen=True)
class _Fields:
    """A route's fields, flattened, and what each one sits inside.

    `properties` are the leaf fields by their dotted names, `defaulted` the nested models with a default in the
    schema, by the same names, for `_leave_out_unanswered`, and `context` each leaf's ancestor chain, for its
    question to carry.
    """

    properties: dict[str, dict[str, Any]]
    defaulted: frozenset[str]
    context: dict[str, list[str]]


def _enum_description(prop: dict[str, Any] | bool, defs: dict[str, Any]) -> str | None:
    """What an `Enum` field's own description hides: the class docstring, as `'<EnumName>: <docstring>'`.

    A field's description takes precedence over the docstring of the `Enum` it refers to, so the docstring is not
    the question; but it still says what the options are for, which the field's question rarely repeats. The
    `Enum` is reached as Pydantic renders it: a `$ref`, one beside `None` for an optional field, or the items of a
    `list`.
    """
    prop = _schema(prop)
    if not (own := prop.get('description')):
        return None
    refs = [prop.get('$ref'), _schema(prop.get('items', {})).get('$ref')]
    refs += [_schema(option).get('$ref') for option in prop.get('anyOf', [])]
    for ref in refs:
        if not ref:
            continue
        definition = _schema(defs.get(ref.removeprefix('#/$defs/'), {}))
        doc = definition.get('description')
        if 'enum' in definition and isinstance(doc, str) and doc and doc != own:
            return f'{definition.get("title") or ref.rsplit("/", 1)[-1]}: {doc}'
    return None


def _ancestor(path: str, raw: dict[str, Any], defs: dict[str, Any]) -> list[str]:
    """What a nested model field says about itself, as entries of its leaves' ancestor chain.

    The field's own description, beside its `$ref`, as `'<dotted path>: <description>'`, and the model's docstring,
    from its definition, as `'<ModelName>: <docstring>'`: the first says which of its kind this one is, and the second
    what that kind is.
    """
    entries: list[str] = []
    if isinstance(own := raw.get('description'), str) and own:
        entries.append(f'{path}: {own}')
    if ref := raw.get('$ref'):
        definition = _schema(defs[ref.removeprefix('#/$defs/')])
        if isinstance(doc := definition.get('description'), str) and doc:
            entries.append(f'{definition.get("title") or ref.rsplit("/", 1)[-1]}: {doc}')
    return entries


def _fields(output_tool: ToolDefinition) -> _Fields:
    """The output schema's fields, flattened, with `$ref`s to `$defs` (how Pydantic renders an `Enum` or a model) resolved.

    A nested model is its fields, named `outer.inner`: each question is about one value, and a field of a field is
    still one value. The answers are nested back into place by `_set`. The nested models with a default in the
    schema come back alongside, by the same names, for `_leave_out_unanswered`.

    Flattening drops what the models on the way say about themselves, which is often all that tells two leaves of
    the same name apart: `origin.city` and `destination.city` both ask "Which city?". So each leaf also gets its
    ancestor chain, root to leaf and without the route itself, which its question carries as `context`: each
    ancestor field's own description, as `'<dotted path>: <description>'`, and each nested model's docstring, as
    `'<ModelName>: <docstring>'`. An `Enum` leaf whose own description hides the `Enum`'s docstring gets that
    docstring as a last entry.
    """
    schema = output_tool.parameters_json_schema
    # Resolving a `$ref` inlines its definition into the field, so each one counts as an inlined copy.
    walk = _FieldWalk(
        schema.get('$defs', {}), InlinedValues(f'The JSON schema of {output_tool.kind} tool {output_tool.name!r}')
    )
    properties = walk.flatten(_properties(schema), '', frozenset(), [])
    return _Fields(properties, frozenset(walk.defaulted), walk.context)


@dataclass
class _FieldWalk:
    """The walk `_fields` flattens a route's schema with, and what it collects along the way."""

    defs: dict[str, Any]
    inlined: InlinedValues
    context: dict[str, list[str]] = field(default_factory=dict[str, list[str]])
    defaulted: set[str] = field(default_factory=set[str])

    def resolve(self, prop: dict[str, Any] | bool) -> dict[str, Any]:
        prop = _schema(prop)
        if ref := prop.get('$ref'):
            definition = self.defs[ref.removeprefix('#/$defs/')]
            self.inlined.add_copy(definition)
            prop = {**self.resolve(definition), **{k: v for k, v in prop.items() if k != '$ref'}}
        if 'items' in prop:
            prop = {**prop, 'items': self.resolve(prop['items'])}
        if 'anyOf' in prop:
            prop = {**prop, 'anyOf': [self.resolve(option) for option in prop['anyOf']]}
        if 'propertyNames' in prop:
            # How an `Enum`-keyed mapping names its keys, as a `$ref` to the enum's own schema.
            prop = {**prop, 'propertyNames': self.resolve(prop['propertyNames'])}
        return prop

    def flatten(
        self, properties: dict[str, Any], prefix: str, seen: frozenset[str], chain: list[str]
    ) -> dict[str, dict[str, Any]]:
        fields: dict[str, dict[str, Any]] = {}
        for name, prop in properties.items():
            if '.' in name:
                raise UserError(
                    f'Output field {prefix + name!r} is not supported by this model: a dot in a field name is how '
                    'a nested field is named. Rename it.'
                )
            raw = _schema(prop)
            ref = raw.get('$ref')
            prop = self.resolve(prop)
            if prop.get('type') == 'object' and prop.get('properties'):
                fields.update(self._flatten_model(f'{prefix}{name}', raw, ref, prop, seen, chain))
            else:
                fields[f'{prefix}{name}'] = prop
                self._add_leaf_context(f'{prefix}{name}', raw, chain)
        return fields

    def _flatten_model(
        self,
        path: str,
        raw: dict[str, Any],
        ref: str | None,
        prop: dict[str, Any],
        seen: frozenset[str],
        chain: list[str],
    ) -> dict[str, dict[str, Any]]:
        """A nested model field's leaves, named under `path`."""
        if ref is not None and ref in seen:
            # A model that contains itself with no way out is infinitely many questions, so there is no
            # depth at which to stop asking. An optional or list self-reference is refused on the field
            # itself before the walk gets here.
            raise UserError(
                f'Output field {path!r} is not supported by this model: a model that contains '
                'itself has no end to fill, and every question is asked up front. Give the field a type '
                'that does not contain itself.'
            )
        if 'default' in prop:
            self.defaulted.add(path)
        ancestors = [*chain, *_ancestor(path, raw, self.defs)]
        return self.flatten(prop['properties'], f'{path}.', seen | {ref} if ref else seen, ancestors)

    def _add_leaf_context(self, path: str, raw: dict[str, Any], chain: list[str]) -> None:
        leaf_context = [*chain]
        if enum := _enum_description(raw, self.defs):
            leaf_context.append(enum)
        if leaf_context:
            self.context[path] = leaf_context


def _set(args: dict[str, Any], name: str, value: Any) -> None:
    """Put a flattened field's answer back where it belongs, `outer.inner` under `outer`."""
    parent, leaf = _slot(args, name)
    parent[leaf] = value


def _leave_out_unanswered(
    args: dict[str, Any], properties: dict[str, dict[str, Any]], defaulted: frozenset[str], prefix: str = ''
) -> bool:
    """Leave out a nested model with a default when nothing under it was answered, and say if `args` holds an answer.

    Every field under such a model was left out for its own default to apply, and the model's default says what to
    use when there is nothing to fill it with. An empty model put in place would apply the defaults inside it
    instead. One without a default of its own stays, empty, for those inner defaults to apply in.
    """
    answered = False
    for name, value in list(args.items()):
        path = f'{prefix}{name}'
        if path in properties:
            answered = True
        elif _leave_out_unanswered(value, properties, defaulted, f'{path}.'):
            answered = True
        elif path in defaulted:
            del args[name]
    return answered


def _slot(args: dict[str, Any], name: str) -> tuple[dict[str, Any], str]:
    """Where a flattened field's answer goes: the arguments of the model it belongs to, put in place, and its name there."""
    *path, leaf = name.split('.')
    for part in path:
        args = args.setdefault(part, {})
    return args, leaf


def _optional(prop: dict[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
    """An `X | None` field as `X` plus one more option, "none of these", named and described; any other as it is.

    An explicit option lets the model say that nothing fits, which is a different thing from being unsure: reading
    `None` off low confidence would conflate the two, and the field's confidence already reports the second. What
    the user wrote about the `None` branch, `Annotated[None, Field(description=...)]`, says what picking it means
    on this field better than the stock phrase does, so it describes the option when there is one.
    """
    options = prop.get('anyOf')
    # Exactly one of the two has to be `None`, and the other one has to be something: a union of nothing but
    # `None`s has no `X` to ask about, and is refused as the unsupported field it is rather than crashing here.
    if not options or len(options) != 2 or sum(_null(option) for option in options) != 1:
        return prop, {}
    none = next(option for option in options if _null(option))
    inner = next(option for option in options if not _null(option))
    prop = {**inner, **{k: v for k, v in prop.items() if k not in ('anyOf', 'default')}}
    key = 'none'
    while key in (_options(prop) or {}):
        key += '_'
    meaning = none.get('description')
    return prop, {key: meaning if isinstance(meaning, str) and meaning else _NONE_OF_THESE}


def _list_options(name: str, prop: dict[str, Any]) -> dict[Any, str | None]:
    """The options a `list` field fans out over, or a `UserError` saying why it is not a list of them."""
    labels = _options(prop['items']) if 'items' in prop else None
    if not labels or len(labels) < 2 or not all(isinstance(label, str) for label in labels):
        raise UserError(
            f'Output field {name!r} is not supported by this model: a list must be of two or more string '
            f'options. {_UNSUPPORTED_FIELD_HINT}'
        )
    if 'maxItems' in prop or 'minItems' in prop:
        # Every option is asked about and every yes is kept, so how many come back is the model's answer rather
        # than something that can be held to a limit -- the same reason a mapping carrying one is refused. Checked
        # after the shape, so a `tuple`, which carries both intrinsically, is still told it is not a list.
        raise UserError(f'Output field {name!r} is not supported by this model. {_UNSUPPORTED_FIELD_HINT}')
    return labels


def _fan_out(name: str, ask: dict[str, JsonValue], labels: dict[Any, str | None]) -> dict[str, NoulQuestion]:
    """One yes/no per option, asked with the field's question and that option's description.

    Both a list of options and a mapping keyed by them ask this; what differs is how the answers are read back.
    """
    questions: dict[str, NoulQuestion] = {}
    for label, meaning in labels.items():
        option = f'{label}: {meaning}' if meaning else label
        questions[f'{name}.{label}'] = NoulQuestion(instructions={**ask, 'option': option})
    return questions


def _bounded(prop: dict[str, Any]) -> float | None:
    """The upper bound of a number field that asks for a probability, or `None` if it is not one.

    A probability is what a yes/no is answered with, so a number field has to be bounded to be one. The bound itself
    is only a scale: `ge=0, le=1` is the probability as it comes back, and `ge=0, le=100` the same answer as a
    percentage. What the field asks is unchanged; only the units it is written in differ.
    """
    if prop.get('type') != 'number' or prop.get('minimum') != 0:
        return None
    if 'multipleOf' in prop:
        # A probability can land anywhere between the bounds, so a field that only accepts steps along them is not
        # a probability in different units; it is a set of levels, which is what a rubric is for.
        return None
    maximum = prop.get('maximum')
    return maximum if isinstance(maximum, (int, float)) and not isinstance(maximum, bool) and maximum > 0 else None


def _mapping_options(prop: dict[str, Any]) -> dict[Any, str | None] | None:
    """The options a `dict[Literal, bool]` field is keyed by, or `None` if the field is not one.

    A mapping keyed by options and valued by yes/no is a fan-out like a list of those options. A mapping of
    anything else -- `dict[str, str]`, `dict[str, int]` -- has no options to fan out over and is not one.
    """
    if prop.get('type') != 'object' or prop.get('properties'):
        return None
    if 'maxProperties' in prop or 'minProperties' in prop:
        # Every option is asked about and every answer is kept, so there is no way to return fewer or more
        # keys than the mapping declares, and a limit on how many there may be could only be broken.
        return None
    # A plain yes/no per key and nothing else. Anything narrower -- a `const`, an `enum`, a `Literal[True]` --
    # would forbid an answer the model is free to give, and `True` rather than a schema is how `dict[str, Any]`
    # says its values are unconstrained. Matching the whole schema rather than one key of it refuses both, and
    # whatever else is put there next.
    if prop.get('additionalProperties') != {'type': 'boolean'}:
        return None
    names = prop.get('propertyNames')
    if not isinstance(names, dict):
        # `propertyNames: true` says the keys are unconstrained, so there are no options to fan out over.
        return None
    return _options(cast('dict[str, Any]', names))


def _options(prop: dict[str, Any]) -> dict[Any, str | None] | None:
    """The options of a pick-one schema, each with its description, or `None` when the schema is not one."""
    if 'enum' in prop:
        return dict.fromkeys(prop['enum'])
    if 'anyOf' in prop and all('const' in option for option in prop['anyOf']):
        return {option['const']: option.get('description') for option in prop['anyOf']}
    return None


def _pickable(options: dict[Any, str | None]) -> bool:
    """Whether every option is a string or a whole number, which is what a pick-one can offer by name."""
    # `bool` is an `int` in Python, but `True` is not a label, and a pick-one of booleans is a yes/no.
    return all(
        isinstance(option, str) or (isinstance(option, int) and not isinstance(option, bool)) for option in options
    )


def _labelled(options: dict[Any, str | None]) -> dict[str, Any]:
    """Each option of a pick-one under the label the model picks it by, in the order they are declared.

    A string is its own label, so a pick-one of strings asks exactly what it always has. A whole number is labelled
    by its digits, unless a string option already is those digits: `Literal['1', 1]` is two options, and the answer
    has to say which of them was picked, so the number becomes `1 (number)`. The answer is read back through this
    mapping rather than by converting the label, so the argument gets the option itself, with its type.
    """
    taken = {option for option in options if isinstance(option, str)}
    labelled: dict[str, Any] = {}
    for option in options:
        label = option
        if not isinstance(option, str):
            label = str(option)
            while label in taken:
                label = f'{label} (number)'
            taken.add(label)
        labelled[label] = option
    return labelled


def _rubric(options: dict[Any, str | None], limits: _Limits) -> list[str] | None:
    """A rubric's level descriptions in level order, or `None` when the options are not a rubric.

    A rubric is ordered levels starting at zero, so the levels have to be exactly that, no more of them than the
    model scores against, and every one of them has to say what it means: a rubric whose levels are unexplained is
    not a rubric. Any other whole numbers -- status codes, levels with nothing said about them, more levels than the
    model takes -- are labels, and are a pick-one instead.
    """
    if not all(isinstance(option, int) and not isinstance(option, bool) for option in options):
        return None
    levels = sorted(options)
    if levels != list(range(len(levels))) or len(levels) < 2:
        return None
    if limits.score_levels is not None and len(levels) > limits.score_levels:
        return None
    criteria = [meaning for level in levels if (meaning := options[level])]
    return criteria if len(criteria) == len(levels) else None


def _with_none(
    name: str, options: dict[Any, str | None] | None, none_option: dict[str, str], limits: _Limits
) -> dict[Any, str | None]:
    """An optional field's options with "none of these" as one more, or a `UserError` saying why it cannot be one."""
    if options is not None and _rubric(options, limits) is not None:
        raise UserError(
            f'Output field {name!r} is a rubric, and a rubric cannot be optional: its levels are ordered and '
            f'`None` is not one of them.'
        )
    if options is None or not _pickable(options):
        raise UserError(
            f'Output field {name!r} is not supported by this model: only a pick-one of strings or whole '
            f'numbers can be optional, since `None` is one more option to pick. {_UNSUPPORTED_FIELD_HINT}'
        )
    return {**options, **none_option}


_INSTRUCTIONS_KEY = 'background'
"""The label the agent's `instructions` go under inside a question's labelled parts.

Not `instructions`, which is the wire field those parts are sent in, and not `context`, which is a field's ancestor
chain: three things, three names.
"""

_CONTEXT_KEY = 'context'
"""The label a nested field's ancestor chain goes under, from `_fields`."""

_PREMISE = "If the user's request calls for {label}"


def _premise(tool: ToolDefinition, label: str) -> str:
    """The route a field belongs to, as the condition its question is asked under.

    A field is asked about a route before the route is taken, or in the request that fills it once it is: either
    way the answer only means something if that route is the one the text calls for, so the question says so,
    naming the route by its label on the route question and saying what the route is for.
    """
    described = _described(tool)
    return f'{_PREMISE.format(label=label)}: {described}' if described else f'{_PREMISE.format(label=label)}.'


def _ask(
    name: str,
    prop: dict[str, Any],
    output_tool: ToolDefinition,
    instructions: str | None,
    *,
    label: str | None,
    context: list[str],
) -> dict[str, JsonValue]:
    """What a field asks, as labelled parts: its field, route, ancestors, question, and shared framing.

    `label` is the route's name on the route question when there is one, which makes the route a premise the
    question is asked under; without a route question, the route's docstring is the goal of every question.
    """
    # Only what the user wrote goes to the model. A bare `bool` output is wrapped in a field named `response`
    # by Pydantic AI, and the output tool has a stock description; neither says anything about the question.
    ask: dict[str, JsonValue] = {}
    # A field's name says what is being asked about, which is not the same as asking something, so it
    # goes under `field` and leaves `question` for a question. The wrapper field Pydantic AI puts around
    # a bare output is named `response` and says nothing about anything, so it is not sent at all.
    if name != output_tool.outer_typed_dict_key:
        ask['field'] = name
    if label is not None:
        ask['premise'] = _premise(output_tool, label)
    if context:
        ask[_CONTEXT_KEY] = cast('list[JsonValue]', context)
    if description := prop.get('description'):
        ask['question'] = description
    if label is None and (described := _described(output_tool)):
        ask['goal'] = described
    if instructions:
        # With no field to describe, a bare output's whole question is what the agent was instructed to
        # ask, so it goes where a question goes. Alongside fields of its own it is shared framing.
        ask['question' if 'question' not in ask and 'field' not in ask else _INSTRUCTIONS_KEY] = instructions

    return ask


@dataclass(frozen=True)
class _Ask:
    """One route's fields as questions, and how to read their answers back.

    `_fields` and `_questions` are derived from the same route, and `_answers` needs both of them again to
    make sense of what comes back, so the three travel together rather than being rebuilt side by side at
    every call site. A turn that picks a route and then fills it builds one of these per request, and what
    a question carries about its route is decided in one place instead of once per caller.
    """

    properties: dict[str, dict[str, Any]]
    questions: dict[str, DecisionQuestion]
    defaulted: frozenset[str]

    @classmethod
    def about(cls, tool: ToolDefinition, instructions: str | None, limits: _Limits, *, label: str | None) -> _Ask:
        """The questions this route's fields become, or a `UserError` if the model cannot express one of them.

        `label` is the route's name on the route question, for a route asked about beside that question or filled
        after it; `None` for the one output type asked when there is no route question.
        """
        fields = _fields(tool)
        questions = _questions(fields, tool, instructions, limits, label=label)
        return cls(fields.properties, questions, fields.defaulted)

    @classmethod
    def to_fill(cls, tool: ToolDefinition, instructions: str | None, limits: _Limits, *, label: str) -> _Ask | None:
        """The questions a picked route's fields become in the request that fills them, or `None` to hand it off.

        `None` means the model cannot express one of the fields or their questions exceed the request cap,
        so the route is raised as [`UnfillableRoute`][pydantic_ai.models.decision.UnfillableRoute]
        before anything is sent to fill it.
        """
        try:
            ask = cls.about(tool, instructions, limits, label=label)
        except UserError:
            return None
        if limits.questions is not None and len(ask.questions) > limits.questions:
            return None
        return ask

    def answers(
        self, response: DecisionResponse, boolean_threshold: float
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, float]]:
        return self.read(response.answers, boolean_threshold)

    def read(
        self, answers: Mapping[str, object], boolean_threshold: float
    ) -> tuple[dict[str, Any], dict[str, Any], dict[str, float]]:
        return _answers(answers, self.properties, self.questions, boolean_threshold, self.defaulted)


def _questions(
    fields: _Fields,
    output_tool: ToolDefinition,
    instructions: str | None,
    limits: _Limits,
    *,
    label: str | None,
) -> dict[str, DecisionQuestion]:
    """One question per output field, or one per option for a field that fans out."""
    questions: dict[str, DecisionQuestion] = {}
    for name, prop in fields.properties.items():
        ask = _ask(name, prop, output_tool, instructions, label=label, context=fields.context.get(name, []))
        questions.update(_field_questions(name, prop, ask, limits))
    return questions


def _field_questions(
    name: str, prop: dict[str, Any], ask: dict[str, JsonValue], limits: _Limits
) -> Mapping[str, DecisionQuestion]:
    """The questions one output field becomes, keyed as `_questions` returns them."""
    prop, none_option = _optional(prop)
    options = _field_options(name, prop, none_option, limits)

    # A single value needs no label, so it is sent bare; the object form earns its keys only once there is
    # more than one thing in it.
    asked: JsonValue | None = next(iter(ask.values())) if len(ask) == 1 else (ask or None)
    if asked is None and limits.requires_instructions:
        # Only a question whose options say what it asks gets this far without anything to ask: a plain yes/no
        # is refused below, and a field that fans out asks about each option by name.
        asked = _DEFAULT_QUESTION

    if prop.get('type') == 'array':
        # Several options at once is one yes/no per option, all in the same request: does this option apply,
        # asked with the field's question and the option's description.
        return _fan_out(name, ask, _list_options(name, prop))
    if options is not None:
        return {name: _option_question(name, options, asked, limits)}
    if keys := _mapping_options(prop):
        # A mapping from options to yes/no asks the same thing per option a list of them does; what
        # differs is the answer, which keeps every option rather than only the ones that came back yes.
        if len(keys) < 2:
            # A key of a JSON object is a string by construction, so only how many there are is in doubt.
            raise UserError(
                f'Output field {name!r} is not supported by this model: a mapping must be keyed by two or '
                f'more options. {_UNSUPPORTED_FIELD_HINT}'
            )
        return _fan_out(name, ask, keys)
    if prop.get('type') == 'boolean' or _bounded(prop) is not None:
        if not ask:
            raise UserError(_ASKS_NOTHING.format(name=name))
        return {name: NoulQuestion(instructions=asked)}
    raise UserError(f'Output field {name!r} is not supported by this model. {_UNSUPPORTED_FIELD_HINT}')


def _field_options(
    name: str, prop: dict[str, Any], none_option: dict[str, str], limits: _Limits
) -> dict[Any, str | None] | None:
    """The options a field picks from, with "none of these" for an optional one, or `None` if it has none."""
    options = _options(prop)
    if options and all(isinstance(option, bool) for option in options) and not any(options.values()):
        # `Literal[True, False]` spells out the two values a `bool` already has and says nothing about
        # either, so there is nothing to pick between that a yes/no does not ask, and the schema says
        # `boolean` too. Two booleans that *are* described are that same yes/no with criteria, below.
        options = None
    if none_option:
        options = _with_none(name, options, none_option, limits)
    return options


def _option_question(
    name: str, options: dict[Any, str | None], asked: JsonValue | None, limits: _Limits
) -> DecisionQuestion:
    """The question a field with options becomes: a rubric to score, a yes/no, or a choice."""
    if (criteria := _rubric(options, limits)) is not None:
        return ScoreQuestion(instructions=asked, criteria=cast('list[JsonValue]', criteria))
    if len(options) == 2 and all(isinstance(option, bool) for option in options):
        # `True` and `False` are the two options a yes/no already has, so an `Enum` or `Literal` of
        # exactly those is that same question, with somewhere to say what each answer means.
        return _noul_question(cast('dict[bool, str | None]', options), asked)
    if len(options) < 2 or not _pickable(options):
        raise UserError(
            f'Output field {name!r} is not supported by this model: its options are not two or more strings '
            f'or whole numbers. {_UNSUPPORTED_FIELD_HINT}'
        )
    if limits.choice_options is not None and len(options) > limits.choice_options:
        raise UserError(
            f'Output field {name!r} is not supported by this model: it picks from at most '
            f'{limits.choice_options} options, and this one has {len(options)}.'
        )
    return ChoiceQuestion(
        instructions=asked,
        criteria={label: options[option] for label, option in _labelled(options).items()},
    )


_OUTPUT_ROUTE_LABEL = 'output'
"""The label of a single output type that has no name of its own: a bare `bool` or `Literal` that Pydantic AI wraps."""

_OUTPUT_LABEL_SUFFIX = ' (output)'

_CAPABILITY_LABEL_SUFFIX = ' (capability)'

_CATALOG_INSTRUCTION_ID = InstructionId(CapabilityInstructionSource(DEFERRED_CAPABILITY_CATALOG_ID))
"""The id of the deferred capability catalog's instruction part, which the loader keys so its changes are appended."""


def _output_route_label(tool: ToolDefinition, output_name: str | None) -> str:
    """The name an output route goes by on the route question, before collisions with other routes are settled.

    The output tool's name is the library's, not the user's: `final_result` for a single output type and
    `final_result_<Member>` for a member of a union, neither of which says anything to the model. So a route is
    labelled by the name the user gave it, wherever that is:

    - a name given with `ToolOutput(name=...)`, which is the tool's name as it stands;
    - a union member's own name, which follows the prefix: `Refund`, `None`, or an output function's name;
    - a single output type's own name, `output_name`: the name of a model or an `Enum`, or of an output function,
      which its tool has nowhere to carry. It comes from the request's `output_object`, which Pydantic AI fills in for
      an output type given without `ToolOutput` and a model prepares away in tool output mode;
    - failing that, a single output type's schema `title`, which is how `ToolOutput(Ticket)` without a name still
      goes by `Ticket`; or `output` for a type that has no name worth offering, a bare `bool`, `Literal` or `list`
      that Pydantic AI wraps in an object, since `bool` says nothing about the route. A wrapped type with a class
      of its own, an `Enum`, is a `$ref` to its definition, and that is how it is told apart.
    """
    if tool.name == DEFAULT_OUTPUT_TOOL_NAME:
        wrapped = _wrapped(tool)
        if output_name and (wrapped is None or '$ref' in wrapped):
            return output_name
        title = _resolved(tool.parameters_json_schema).get('title')
        return title if isinstance(title, str) and title else _OUTPUT_ROUTE_LABEL
    return tool.name.removeprefix(f'{DEFAULT_OUTPUT_TOOL_NAME}_') or _OUTPUT_ROUTE_LABEL


def _route_labels(
    output_tools: list[ToolDefinition], tools: list[ToolDefinition], output_name: str | None
) -> dict[str, ToolDefinition]:
    """Every route on offer under the one label the model knows it by, in the order the route question offers them.

    The label is the option key on the route question and the `chosen` of the fill that follows, so one route has
    one name across both requests. A function tool is labelled by its own name. An output route, including an
    output function that takes no arguments and the `None` member of a union, is labelled by
    `_output_route_label`, and a capability to load by its id. Two routes can come out with the same label, as a
    tool named `Refund` beside an output type `Refund` does: the function tool keeps its name, and the output route
    gets ` (output)` appended until the label is free, as a capability gets ` (capability)`. Function tool names are
    unique among themselves, so only the other routes are ever renamed, and in the order they are offered, so the
    same routes always get the same labels.

    The model's answer is read back through this mapping, never by parsing a label.
    """
    routes = [*output_tools, *tools]
    taken = {tool.name for tool in routes if tool.kind != 'output' and _capability_id(tool) is None}
    labels: list[str] = []
    for tool in routes:
        capability_id = _capability_id(tool)
        if tool.kind == 'output':
            label, suffix = _output_route_label(tool, output_name), _OUTPUT_LABEL_SUFFIX
        elif capability_id is not None:
            label, suffix = capability_id, _CAPABILITY_LABEL_SUFFIX
        else:
            labels.append(tool.name)
            continue
        while label in taken:
            label += suffix
        taken.add(label)
        labels.append(label)
    return dict(zip(labels, routes))


def _described(tool: ToolDefinition) -> str | None:
    """What the user wrote about a tool, without the stock description generated for an output tool."""
    description = tool.description
    if not description or (tool.kind == 'output' and description.endswith(DEFAULT_OUTPUT_TOOL_DESCRIPTION)):
        return None
    return description


def _tools_left(messages: list[ModelMessage], tools: list[ToolDefinition]) -> tuple[list[ToolDefinition], bool]:
    """The tools still on offer, and whether the agent loop has acted this turn: a tool returned or a retry was sent.

    A tool whose result is already in the turn is not offered again. A decision model judges the text in front of it
    and has no notion of having made a call: with a call and its result in view, the text still calls for the tool, so
    left on offer it is picked again until the usage limit, even with the result set apart under `done`. That goes for
    a call made by a model behind this one too, since this model would propose it again on the same text. A call whose
    result asked for a retry (`outcome='retried'`) leaves the tool on offer. The turn is everything since the
    last user prompt, which is the nearest thing to a run boundary the history has: a result from an earlier turn does
    not withhold the tool, but a judged history that ends in another agent's call to a tool of the same name does.

    A capability to load is exempt: `_capability_routes` already leaves out the active ones, and
    loading one is no reason to withhold the others.
    """
    returned: set[str] = set()
    retried = False
    for message in messages:
        if not isinstance(message, ModelRequest):
            continue
        for part in message.parts:
            if isinstance(part, UserPromptPart):
                # A new prompt starts a turn, and a result that arrived before it in the same request is the
                # previous turn's.
                returned.clear()
                retried = False
            elif isinstance(part, ToolReturnPart) and part.outcome != 'retried':
                returned.add(part.tool_name)
            elif isinstance(part, ToolReturnPart | RetryFeedbackPart):
                retried = True
    return (
        [tool for tool in tools if tool.name not in returned or _capability_id(tool) is not None],
        bool(returned) or retried,
    )


_ROUTE_QUESTION = 'Which of these does this call for?'


def _route_question(
    questions: dict[str, DecisionQuestion],
    routes: dict[str, ToolDefinition],
    output_tools: list[ToolDefinition],
    tools: list[ToolDefinition],
    instructions: str | None,
    limits: _Limits,
) -> str:
    """With tools attached, one more question: which route the text calls for, the output types among them.

    The question is keyed `route`, which no field can take, since every field asked beside it is keyed under its
    route's label as `'<label>.<field>'`; each option is a route's label from `routes`. It asks what the situation
    calls for, not what the user asked for: naming the user's request tilts the pick toward doing what was literally
    asked, and away from a route like an escalation that nobody asks for. It carries the agent's instructions beside
    it like a field's question does.

    The fields of the routes the model can fill are asked beside it, or, past `_Speculation`'s size cutoff, a picked
    route's fields are asked in a second request; an unsupported argument leaves the call to a model behind it. The
    output types are the first options, described by what the agent is for, so that filling the output is an action
    weighed against the others. Asking instead whether the model *can* answer would be a question about the question
    rather than about the text, and invites a hand-off on everything. Only what the user wrote describes an output: the
    output type's docstring, or failing that the agent's instructions; the stock output tool description says nothing a
    tool could be weighed against.
    """
    if not output_tools and len(tools) < 2:
        raise UserError(
            'An `output_type` with no fields is not supported by this model; there is nothing to ask the model. '
            'Give it fields, or more than one tool to pick between.'
        )
    criteria: dict[str, JsonValue] = {}
    for label, route in routes.items():
        if route not in output_tools:
            criteria[label] = _route_description(route)
            continue
        described = _purpose(route)
        if not (described or (instructions and len(output_tools) == 1)):
            # With one output type the agent's instructions can say what filling it is for. With several, only
            # each type's own docstring can tell them apart: one instruction cannot describe two different routes.
            raise UserError(
                f'A decision model weighs each route by what it is for, and {label!r} says nothing about itself. '
                'Give the output type a docstring that says what filling it does'
                + ('.' if len(output_tools) > 1 else ', or the agent `instructions`.')
            )
        criteria[label] = described or instructions
    if limits.choice_options is not None and len(criteria) > limits.choice_options:
        raise UserError(
            f'This model picks from at most {limits.choice_options} options, and it is being offered '
            f'{len(criteria)} routes: each output type counts as one beside the tools. Attach fewer tools, or '
            'withhold some of them until they are needed.'
        )
    # The agent's instructions frame the pick as they frame every field, under the same label.
    asked: JsonValue = (
        {'question': _ROUTE_QUESTION, _INSTRUCTIONS_KEY: instructions} if instructions else _ROUTE_QUESTION
    )
    questions['route'] = ChoiceQuestion(instructions=asked, criteria=criteria)
    return 'route'


def _noul_question(options: dict[bool, str | None], asked: JsonValue | None) -> NoulQuestion:
    """A yes/no from an `Enum` or `Literal` of `True` and `False`, with what each answer means.

    A bare `bool` asks the same question and says nothing about its answers, because a `bool` has nowhere to
    write it down. Two described options do, and they become the yes/no's criteria. Only one of the two need be
    described; what is written is sent, and a pair that describes neither never gets here — it is collapsed to a
    plain yes/no by `_questions`, which is also what raises when there is nothing to ask.
    """
    return NoulQuestion(
        instructions=asked,
        criteria=NoulCriteria(true=options[True], false=options[False]),
    )


def _image_label(item: MultiModalContent, images: list[BinaryContent | ImageUrl], context: str) -> str:
    if not isinstance(item, (BinaryContent, ImageUrl)) or (isinstance(item, BinaryContent) and not item.is_image):
        raise UserError(f'{context} contains an unsupported file: this model accepts text and images only.')
    images.append(item)
    return f'<image {len(images)}>'


def _structured_prompt(parts: Sequence[UserPromptPart]) -> StructuredContent | None:
    """The structured item a prompt consists of, when it has nothing else, to be judged as the value it holds.

    A prompt that mixes it with text or other items is judged as the text it renders to, like any other text.
    """
    items = [
        item
        for part in parts
        for item in ([part.content] if isinstance(part.content, str) else part.content)
        if not isinstance(item, CachePoint)
    ]
    return items[0] if len(items) == 1 and isinstance(items[0], StructuredContent) else None


def _prompt_text(part: UserPromptPart, images: list[BinaryContent | ImageUrl] | None) -> str:
    texts: list[str] = []
    for item in [part.content] if isinstance(part.content, str) else part.content:
        if isinstance(item, str):
            texts.append(item)
        elif isinstance(item, TextContent):
            texts.append(item.content)
        elif isinstance(item, CachePoint):
            pass  # A marker for models that cache a prompt prefix; there is nothing in it to send.
        elif images is not None and is_multi_modal_content(item):
            texts.append(_image_label(item, images, 'A user prompt'))
        else:
            raise UserError(
                'Files are not supported by this model: it judges text, so images, audio, video and documents '
                'cannot be sent to it.'
            )
    return '\n\n'.join(texts)


def _labelled_tool_return_text(part: BaseToolReturnPart, labelled: Iterable[object]) -> str:
    """The text of `part` with its files replaced by the labels in `labelled`, each item serialized as it is alone.

    An errored return is wrapped as `model_response_str` wraps a list: a retry's array as it is, a failed return's
    array as a string. Calling `model_response_str()` on a relabelled copy instead would dump the list whole, a level
    deeper, and put a retry's items through `dump_python`, which drops their own serializer settings.
    """
    text = _tool_return_items_json(labelled)
    if part.outcome not in ERROR_OUTCOMES:
        return text
    error = text if part.outcome == 'retried' else tool_return_ta.dump_json(text).decode()
    return f'{{"error":{error}}}'


def _tool_return_entry(part: BaseToolReturnPart, images: list[BinaryContent | ImageUrl] | None) -> JsonValue:
    """A tool result as history, preserving file positions and failed-result wrapping."""
    if part.files:
        if images is None:
            raise UserError('Files are not supported by this model: a file in a tool result cannot be sent to it.')
        labelled = [
            _image_label(item, images, 'A tool result') if is_multi_modal_content(item) else item
            for item in part.content_items()
        ]
        return {'tool_return': {'name': part.tool_name, 'content': _labelled_tool_return_text(part, labelled)}}
    return {'tool_return': {'name': part.tool_name, 'content': part.model_response_str()}}


def _request_entry(part: ModelRequestPart, images: list[BinaryContent | ImageUrl] | None) -> JsonValue:
    """A request part as a history entry: a user prompt as what the user said, the rest as what they are."""
    if isinstance(part, SystemPromptPart):
        # Whoever wrote it, a system prompt is something that was said in the conversation, so it is
        # material to judge and not a question to ask. What the model is asked comes from `instructions`.
        return {'system': part.content}
    elif isinstance(part, UserPromptPart):
        structured = _structured_prompt([part])
        return {'user': _prompt_text(part, images) if structured is None else to_jsonable_python(structured.value)}
    elif isinstance(part, ToolReturnPart):
        return _tool_return_entry(part, images)
    elif isinstance(part, RetryFeedbackPart):
        return {'retry': part.model_response()}
    # TODO(v3): remove `RetryPromptPart`
    elif isinstance(part, RetryPromptPart):  # pyright: ignore[reportDeprecated]
        # A direct `request()` skips `prepare_messages`; judge the deprecated part as what it always meant.
        return _request_entry(_translate_legacy_retry_part(part), images)
    elif isinstance(part, (InstructionBaselinePart, InstructionDeltaPart)):  # pragma: no cover
        raise _unprojected_instruction_delta_error()
    elif isinstance(part, CompactionPart):
        # A summary standing in for earlier turns: the same entry a response-side summary gets.
        return {'summary': part.content or ''}
    elif isinstance(part, _UnpreparedPart):  # pragma: no cover
        raise _unprepared_part_error(part)
    elif isinstance(part, SpeechPart):  # pragma: no cover
        # `Model.prepare_messages` turns realtime speech into `UserPromptPart`s before this runs.
        raise _unconverted_speech_part_error()
    else:
        assert_never(part)


def _response_entries(message: ModelResponse, images: list[BinaryContent | ImageUrl] | None) -> list[JsonValue]:
    """Map a response to history entries, in the order the model produced them."""
    entries: list[JsonValue] = []
    for part in message.parts:
        match part:
            case TextPart():
                entries.append({'assistant': part.content})
            case ThinkingPart():
                # What a model thought is part of what it did: a judgment can be about the reasoning itself, and a
                # conversation continued from the history should see it as the model that wrote it would.
                # Thinking a provider only returned encrypted, as a `signature` with no text, has nothing to show.
                if part.content:
                    entries.append({'thinking': part.content})
            case ToolCallPart() | NativeToolCallPart():
                entries.append({'tool_call': {'name': part.tool_name, 'args': part.args_as_dict()}})
            case NativeToolReturnPart():
                entries.append(_tool_return_entry(part, images))
            case CompactionPart():
                if part.content:
                    entries.append({'summary': part.content})
            case FilePart():
                entries.append(_file_part_entry(part, images))
            case SpeechPart():  # pragma: no cover
                raise _unconverted_speech_part_error()
            case _:
                assert_never(part)
    return entries


def _file_part_entry(part: FilePart, images: list[BinaryContent | ImageUrl] | None) -> JsonValue:
    """Map a file the model produced to a history entry."""
    if images is None:
        raise UserError('Files are not supported by this model: a file in the message history cannot be sent to it.')
    return {'assistant': _image_label(part.content, images, 'An assistant response')}


def _map_messages(
    messages: list[ModelMessage], *, turn: bool, images: list[BinaryContent | ImageUrl] | None
) -> JsonValue:
    """The state to judge.

    The latest user text on its own is the whole state, sent as the plain text it is. With a conversation behind
    it there are two parts to keep apart, so they get named: the text under judgement and the `history` before it.

    With `turn`, a tool has returned or a retry was sent since the latest user prompt, and the state splits at that
    prompt into three: the `history` before it, the prompt itself as `text`, and what has been done since under `done`
    — the calls, their results, the retries, and anything else in the turn — so the request stays the text being
    judged while the steps taken for it are told apart from it. Every entry lands in exactly one of the three,
    however the messages arrived: a run's own, or a `message_history` passed in that ends partway through a turn.

    A prompt that is a single `StructuredContent` is judged as the value it holds, in place of text: the whole state
    on its own, otherwise under `state` where the text would be under `text`, and as the `user` entry in `history`.
    """
    if turn and any(isinstance(part, UserPromptPart) for message in messages for part in message.parts):
        return _map_turn(messages, images)
    history, prompts, prompt_parts = _history_and_prompts(messages, images)

    if (structured := _structured_prompt(prompts)) is not None:
        value = to_jsonable_python(structured.value)
        return {'history': history, 'state': value} if history else value
    text = '\n\n'.join(prompt_parts)
    if not (text or history):
        raise UserError('A request without user text is not supported by this model: it needs text to judge.')
    if not history:
        return text
    state: dict[str, JsonValue] = {'history': history}
    if text:
        state['text'] = text
    return state


def _history_and_prompts(
    messages: list[ModelMessage], images: list[BinaryContent | ImageUrl] | None
) -> tuple[list[JsonValue], list[UserPromptPart], list[str]]:
    """The history entries, and the last message's user prompts with their text, for `_map_messages`."""
    history: list[JsonValue] = []
    prompts: list[UserPromptPart] = []
    prompt_parts: list[str] = []
    for message in messages:
        match message:
            case ModelRequest():
                for part in message.parts:
                    if isinstance(part, UserPromptPart) and message is messages[-1]:
                        prompts.append(part)
                        prompt_parts.append(_prompt_text(part, images))
                    else:
                        history.append(_request_entry(part, images))
            case ModelResponse():
                history.extend(_response_entries(message, images))
            case _:
                assert_never(message)
    return history, prompts, prompt_parts


def _map_turn(messages: list[ModelMessage], images: list[BinaryContent | ImageUrl] | None) -> JsonValue:
    """The state split at the latest user prompt, for `_map_messages`."""
    latest = max(
        index
        for index, message in enumerate(messages)
        if isinstance(message, ModelRequest) and any(isinstance(part, UserPromptPart) for part in message.parts)
    )
    request = messages[latest]
    assert isinstance(request, ModelRequest)
    history = _message_entries(messages[:latest], images)
    earlier, prompts, prompt_parts, later = _split_at_last_prompt(request, images)
    history.extend(earlier)
    done = [*later, *_message_entries(messages[latest + 1 :], images)]
    state: dict[str, JsonValue] = {'history': history} if history else {}
    if (structured := _structured_prompt(prompts)) is not None:
        state['state'] = to_jsonable_python(structured.value)
    else:
        state['text'] = '\n\n'.join(prompt_parts)
    return {**state, 'done': done}


def _message_entries(
    messages: Sequence[ModelMessage], images: list[BinaryContent | ImageUrl] | None
) -> list[JsonValue]:
    """Whole messages as history entries, in order, for `_map_turn`."""
    entries: list[JsonValue] = []
    for message in messages:
        if isinstance(message, ModelResponse):
            entries.extend(_response_entries(message, images))
            continue
        assert isinstance(message, ModelRequest)
        entries.extend(_request_entry(part, images) for part in message.parts)
    return entries


def _split_at_last_prompt(
    request: ModelRequest, images: list[BinaryContent | ImageUrl] | None
) -> tuple[list[JsonValue], list[UserPromptPart], list[str], list[JsonValue]]:
    """The request holding the latest prompt, split at its last prompt, for `_map_turn`.

    What came before its last prompt is the previous turn's, and what came after it is this one's. Its prompts are
    the text, as they are when it is the last message.
    """
    last_prompt = max(i for i, part in enumerate(request.parts) if isinstance(part, UserPromptPart))
    earlier: list[JsonValue] = []
    prompts: list[UserPromptPart] = []
    prompt_parts: list[str] = []
    later: list[JsonValue] = []
    for i, part in enumerate(request.parts):
        if isinstance(part, UserPromptPart):
            prompts.append(part)
            prompt_parts.append(_prompt_text(part, images))
        else:
            (earlier if i < last_prompt else later).append(_request_entry(part, images))
    return earlier, prompts, prompt_parts, later
