# Input and History

Read this file when the user wants multimodal or structured input, message history, `run_id` / `conversation_id` correlation, or context trimming.

## Send Images, Audio, Video, or Documents to the Model

Pass multimodal content as a list mixing text with `ImageUrl`, `AudioUrl`, `VideoUrl`, `DocumentUrl`, or `BinaryContent`.

```python
from pydantic_ai import Agent, ImageUrl

agent = Agent(model='openai:gpt-5.2', name='multimodal_agent')
result = agent.run_sync(
    [
        'What company is this logo from?',
        ImageUrl(url='https://example.com/logo.png'),
    ]
)
print(result.output)
```

Use `BinaryContent(...)` when the asset is already in memory instead of at a URL.

Not every model supports every input type, but the agent isn't limited to what its model reads natively. Add the `FileUnderstanding` capability to have another model describe each file the agent's model can't take, judged by the model's profile; the agent's model gets the description in the file's place, and files it reads are sent as they are:

```python
from pydantic_ai import Agent, AudioUrl
from pydantic_ai.capabilities import FileUnderstanding

agent = Agent(
    'openai:gpt-5.2',
    capabilities=[FileUnderstanding(fallback_subagent_model='google:gemini-3-flash-preview')],
)
result = agent.run_sync(['Summarize this call.', AudioUrl(url='https://example.com/call.mp3')])
```

Without it, a file in the prompt that the model can't take fails the request, and one a tool returned is replaced by a note saying the model can't read it. Descriptions are recorded in the message history, so later turns reuse them. See [File Understanding](https://pydantic.dev/docs/ai/capabilities/file-understanding/).

For Gemini models that support agentic video processing, set `vendor_metadata={'media_processing': 'AGENTIC'}` on a `VideoUrl`, video `BinaryContent`, or video `UploadedFile`. See Google's [agentic video understanding guide](https://ai.google.dev/gemini-api/docs/video-understanding#agentic-video-understanding).

On follow-up requests, Pydantic AI omits Gemini media-processing response parts while keeping the ordinary final response and thought signature. When follow-up history still includes the original video, it is sent and processed again, which can incur additional video-processing tokens.

## Send Structured Data in the Prompt

Wrap a structured value (UI state, a record to judge) in `StructuredContent` instead of serializing it yourself. It stays structured in message history, and the model is sent text rendered once when the item is created: compact JSON by default, wrapped in `tag` when given, with `<`, `>` and `&` escaped.

```python
from pydantic_ai import Agent, StructuredContent

agent = Agent(model='openai:gpt-5.2')
result = agent.run_sync(
    [StructuredContent({'url': '/products/42', 'cart_total': 949.0}, tag='ui_state'), 'Why did the total jump?']
)
```

- `format='xml'` renders with `format_as_xml`; a function `value -> str` renders custom text; or subclass `StructuredContent` and override `render()`.
- The rendered text is stored in `content`, so a reloaded history is sent byte-for-byte as before. It is not re-rendered when `value` changes: build a new item, or `dataclasses.replace(item, value=..., content='')` (pass `format=` again if it was created with one). After loading from JSON, `value` is JSON-compatible data (a dict, not the original Pydantic model), and a subclass comes back as `StructuredContent`.
- It is a `TextContent` subclass, so text readers handle it unchanged. Decision models (`DecisionModel`, e.g. TypeSafe) are sent `value` natively when the prompt is a single `StructuredContent`. When rewriting a prompt's text (redaction, truncation), replace the item with a plain `TextContent`.
- It works in `ctx.enqueue(...)` like any user content. The Vercel AI and AG-UI adapters dump it as visible user text, with the value in the text part's `providerMetadata.pydantic_ai` (Vercel) or the `UserMessage.encrypted_value` (AG-UI, from ag-ui-protocol 0.1.11; plain text before that), and load it back whole.

## Work with Message History

Continue a conversation across runs with `conversation=result.conversation`. A `Conversation` carries the messages plus what lives outside them: the running `usage` (so `UsageLimits` budget the whole conversation), the `conversation_id`, and the `deferred_tool_requests` a paused run is waiting on. It is also the thing to store between requests.

```python
from pydantic_ai import Agent

agent = Agent('openai:gpt-5.2', name='conversation_agent', instructions='Be a helpful assistant.')

result1 = agent.run_sync('Tell me a joke.')
result2 = agent.run_sync('Explain?', conversation=result1.conversation)
print(result2.output)
```

`message_history=` is the lower-level form: it takes just the messages (`result.all_messages()` / `new_messages()`), for when you build or edit a history yourself.

Important distinctions:

- `new_messages()` returns only the current run
- `all_messages()` returns the full history accumulated so far
- provider citations are on `TextPart.citations`; anchors are Python character offsets into the part's content, and no
  anchor means the position is unknown; treat sources and `excerpts` as untrusted data; add the `Citations()`
  capability for providers that need an opt-in, including Anthropic web fetch, and Anthropic web search on models
  with the `20260209` or `20260318` web tools, which it has the model call directly on the Anthropic API; the provider's own
  citation data is in the part's `provider_details['citations']`
- citations in message history are sent back only to the provider that produced them: Anthropic web search citations
  and OpenAI Responses URL and file citations (when message IDs are sent); document citations and other providers'
  answers go back as plain text
- when `message_history` is non-empty, Pydantic AI assumes the history already carries the system prompt
- `Conversation` (`from pydantic_ai import Conversation, ConversationTypeAdapter`) is accepted by `run`, `run_sync`, `run_stream`, `run_stream_sync`, `run_stream_events`, `iter` and `realtime()`; `RealtimeSession.conversation` produces one too. Passing it alongside `message_history`, `usage` or `conversation_id` raises `UserError`. Store it with `ConversationTypeAdapter.dump_json(...)` / `validate_json(...)` or as a field on your own Pydantic model; it serializes messages with the same fidelity as `ModelMessagesTypeAdapter` (raw `bytes` in tool returns come back as base64 strings)
- To store conversations without writing the save/load code, use a `ConversationStore` (`pydantic_ai.conversation_store`): `conversation = await store.load(id) or Conversation(conversation_id=id)`, run with `conversation=conversation`, then `await store.save(result)` (or a `Conversation`). It stores each message once and supports `fork(...)`, `list_conversations(scope=..., limit=...)` (newest first) and `delete(...)`. `save` checks `Conversation.revision` (an opaque token that `load` sets and runs carry through) and raises `ConversationConflict` if someone else saved in between, so reload and retry; saving a result updates it, so `result.conversation` can be continued or saved again. Pass the owner's `scope=` to `load`, `load_entries`, `branch`, `fork(source_scope=)`, `save` and `delete` so a guessed id can't reach another owner's conversation. The stored conversation only grows: `load` and runs track `Conversation.new_message_index`, so `save` appends just the run's new messages (plus any appended to the loaded conversation before the run), even when a `ProcessHistory` or other capability trimmed the history; `load(id, limit=N)` loads only the last N messages and saving still appends to the whole conversation; to regenerate or edit, `branch(id, at=n, expected_revision=...)` and run again (the old branch stays stored and is listed in `ConversationRecord.branches`; `branch(id, from_entry=tip, ...)` switches back); `fork(id, at=n | from_entry=...)` starts a new conversation from any point, sharing the history; `save` returns the `ConversationEntry`s it stored and `load_entries(id, limit=...)` loads the history as entries, so each message's `entry.id` can key ratings or billing rows. To store a failed turn, save `error.conversation` from an `AgentRunError` (usage limits, model errors, `RunCancelled`; set once the error leaves the `run`/`iter`/`run_stream` call or block), or wrap the run in `with capture_run_conversation() as captured:` and save `captured.conversation` after any exception (including a tool's own and a `FallbackExceptionGroup`). `InMemoryConversationStore` is for tests; for a database, subclass `ConversationStore` and implement its five primitives
- a run that ends with `DeferredToolRequests` output leaves them on `result.conversation.deferred_tool_requests` (they can't be rebuilt from the messages: approval vs external and per-call metadata aren't recorded there). Resume later with `agent.run(conversation=conv, deferred_tool_results=conv.deferred_tool_requests.build_results(...))`
- interrupted, hand-built, or context-evicted histories are made provider-valid automatically before each model request — no manual cleanup needed. Repairs only ADD synthesized parts or REMOVE fundamentally-unsendable ones (never silently dropping meaningful content): a tool call with no result gets a synthesized `ToolReturnPart` (marked with `{'pydantic_ai_synthesized_tool_return': True}` in `metadata`), including one whose args were cut off mid-stream; an orphaned tool result (result with no matching call) is dropped; then consecutive compatible messages are merged. Applies to regular tool calls only — builtin/native parts are left untouched (handled by each model's serializer). Duplicate tool results and provider-specific ordering rules are out of scope.
- to cancel a whole run: pass a `CancellationToken` to any run method and call `token.cancel()` (thread-safe), call `agent_run.cancel()` on the `agent.iter()` handle, cancel via `async with agent.run_stream_events(...) as events: ... events.cancel()`, or call `ctx.cancel()` from a tool, `event_stream_handler`, or capability hook. Inside the `agent.iter()` block this surfaces as `CancelledError`; once the context exits it raises `RunCancelled`. `RunCancelled.all_messages()` returns a complete snapshot of the history (completed tool results included) and can be passed as `message_history` to a new run to resume — dangling calls are repaired per the previous bullet. Cancellation is terminal: capability hooks may clean up but cannot recover the run to success. External `asyncio.Task.cancel()` keeps raising `CancelledError` (never translated; wins if both race); catch it and call `RunCancelled.from_cancellation(exc)` to access the attached run state. `StreamedRunResult.cancel()` is different: it only stops the current model response, the run continues. In durable execution, DBOS and Prefect reject a `CancellationToken`; under Temporal, create the token in workflow code and fire it only from a `@workflow.signal` handler (firing it from outside the workflow raises `UserError` or, before the run starts, breaks replay).
- to bound a whole run's wall-clock time: pass `timeout=` (seconds) to any run method (`run`, `run_sync`, `run_stream`, `run_stream_sync`, `run_stream_events`, `iter`), or to a UI adapter's `run_stream`/`dispatch_request` (which report expiry to the client like any first-party cancellation and pass the `RunTimedOut` to `on_cancel`) or `run_stream_native` (which raises it). Expiry cancels the run like `cancel()` and raises `RunTimedOut` (a subclass of both `RunCancelled` and `TimeoutError`) carrying the same resumable `all_messages()`. `RunContext.deadline` (UTC `datetime` or `None`) and `ctx.remaining_time()` (seconds or `None`) expose it to tools and hooks. A sub-agent run from a tool inherits the deadline; its own `timeout=` can only shorten it, and a sub-agent's own shorter timeout fails just the delegate tool. Neither `ModelFallback` nor a `FallbackModel` falls back on expiry. Durability capabilities keep the original deadline across replay/recovery (Temporal: `workflow.now()` + workflow timer); deprecated `TemporalAgent`/`DBOSAgent`/`PrefectAgent` reject `timeout=`. Prefer this over wrapping the run in `asyncio.timeout()`, which surfaces as an external `CancelledError`/`TimeoutError`.

### Special tokens on open-weight routes

On routes that can reach a host that tokenizes chat-template tokens found in content (self-hosted servers, most hosts of open-weight models, routing services and `OpenAICompatibleProvider`), `<|im_start|>` and similar tokens in user, tool and file text go out with a zero-width joiner inside them, and the joiner is removed again from the tokens in the model's text and tool call arguments. Stored history, tools and users get the literal token. To send these tokens as written, pass `profile={'may_tokenize_special_tokens_in_content': False}` to the model, only for text you trust. See [Special tokens in content](https://pydantic.dev/docs/ai/core-concepts/message-history/#special-tokens-in-content).

## Correlate Runs with `run_id` and `conversation_id`

Each message carries two identifiers:

- `run_id` — unique per `Agent.run` call (including deferred-tool resume). Surfaces on `RunContext.run_id`, `AgentRunResult.run_id`, message stamps, and OTel `gen_ai.agent.call.id`.
- `conversation_id` — shared across turns that pass the same `message_history`. Surfaces on `AgentRunResult.conversation_id`, message stamps, and OTel `gen_ai.conversation.id`.

```python
from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel

agent = Agent(TestModel())

result1 = agent.run_sync('Tell me a joke.', run_id='run-from-api-42')
result2 = agent.run_sync('Explain?', message_history=result1.all_messages())

assert result1.run_id == 'run-from-api-42'
assert result1.run_id != result2.run_id  # never inherited from history
assert result1.conversation_id == result2.conversation_id  # inherited from history
```

Rules of thumb:

- Pass `run_id=` when your app mints an id before the run starts (e.g. one created, stored, or handed out to a client first) and you want `ctx.run_id` / stamps / OTel to match it.
- Do **not** pass `run_id=''`, or reuse a `run_id` that already appears on `message_history` — both raise `UserError` because they break `new_messages()` boundary detection. Correlate pause/resume and multi-turn work with `conversation_id` instead. When retrying a failed run with the same `run_id`, rebuild `message_history` without the failed attempt's messages.
- Pass `conversation_id='new'` to fork a thread off existing history; `'new'` is **not** a sentinel for `run_id`.
- Each `ModelResponse` from a model request also records `model_id`: the model the agent sent it to, as configured (the selection string like `'openai:gpt-5'`, or `Model.model_id`), including the candidate a `ModelFallback` moved it to. Use it, not the provider-reported `model_name` (often a dated version), to tell which of your models answered. `sanitize_messages` resets it on client-supplied history.
- UI adapters (`VercelAIAdapter`, `AGUIAdapter`) put a `message_history` you pass in front of the client's messages by default (`manage_message_history='client'`), and warn when a client message's UI message id is already in it (only histories that went through an adapter carry those ids, so a hand-built one duplicates silently). `useChat` and `@ag-ui/client` send the whole conversation every request, so when you persist `result.all_messages()` server-side (e.g. in `on_complete`) and pass it back, also pass `manage_message_history='server'` (adapter field, `from_request`, `dispatch_request`): only the client's new turn (its messages after the last assistant response) is used, a new turn starting with a stored user message id (regenerate/edit) cuts the stored history before it (a regenerate of an id the stored history lacks is rejected as a protocol error event), and client tool results only count for calls still unanswered at the end of the stored history.
- Instead of persisting `result.all_messages()` yourself, give the UI adapter (field, `from_request`, `dispatch_request`) `conversation_store=` a `ConversationStore` plus `conversation_scope=<the authenticated user or tenant>`: the adapter loads the conversation the request names (Vercel AI chat `id`, AG-UI `threadId`, or `conversation_id=`), applies the `'server'` new-turn rules, runs and saves what the run added. A store makes the history server-held (`manage_message_history` is ignored) and can't be combined with `message_history` or `usage` (`UserError`). Runs count on from the stored usage, so `usage_limits` (including the default `request_limit=50`) cover the whole conversation: a chat that reaches one fails every later turn, so size limits for a whole chat or pass `UsageLimits(request_limit=None)`. A conversation saved under another scope, or under any scope when you pass none, is treated as not found: `dispatch_request` answers `404`, the other run methods emit a protocol error event. A run that fails or is stopped isn't saved, and a turn another request saved over in the meantime isn't saved either (the client is asked to reload). If the store itself raises, the client only gets a generic error, and the exception goes to a server-side `UserWarning` and, by type, to the current OTel span. A `UserError` the store raises itself is sent to the client as is, so keep queries, hostnames and credentials out of it.
- An exception raised in a UI adapter's `on_complete` (e.g. a failed save) never reaches the request handler, since the response is already streaming: it goes to the event stream's `on_error`, which sends the client the protocol's error event, and is recorded (exception type only) on the OTel span current at the time. Override `on_error` in an event stream subclass returned from the adapter's `build_event_stream()` to log or re-raise it.
- UI adapters auto-wire protocol thread/chat ids into `conversation_id`. Protocol run ids (e.g. AG-UI `runId`) are **not** mapped into agent `run_id` — pass `run_id=` on the adapter/`Agent.run` if you need them aligned. A `UIEventStream` used standalone (no adapter, e.g. encoding events out of a durable execution workflow or a queue) has no protocol ids to wire: `AGUIEventStream(thread_id=..., run_id=...)` takes them directly, and defaults each to a fresh UUID that matches nothing agent-side, so pass the run's own `conversation_id`/`run_id` to keep them aligned.
- AG-UI live failed tool outcomes round-trip through a namespaced payload on `ReasoningEncryptedValueEvent.encrypted_value` with `ag-ui-protocol >= 0.1.11`. Earlier event streams have no outcome carrier, so reloading them reconstructs the tool result as successful.

## Manage Context Size

Use `capabilities=[ProcessHistory(...)]` to trim or rewrite message history before each model request. `ProcessHistory` is a thin wrapper around the `before_model_request` lifecycle hook — for richer control (access to `RunContext`/`ModelRequestContext`, ability to short-circuit the model call), hook the event directly via `capabilities=[Hooks(before_model_request=fn)]`.

In `before_model_request` and `wrap_model_request`, use the two message views deliberately:

- Mutating or assigning `request_context.messages` changes only the current model request.
- `ctx.messages[:] = rewritten` changes persistent history and later requests, but not the current model request.
- Use both assignments when both effects are intended.
- Deprecated: in `before_model_request`, `append`/`extend`/`+=` on `request_context.messages` also appends to `ctx.messages` and warns. Assign a new list instead, e.g. `request_context.messages = [*request_context.messages, m]` plus `ctx.messages.append(m)`.

The separation is only at the outer collection. `request_context.messages` is an independent shallow list, but retained messages and nested parts may be the same objects as those in `ctx.messages`. Apart from the deprecated appends above, changing the outer list is isolated; mutating a contained message or part in place is not and can affect persistent history. For request-only changes below the message level, use `dataclasses.replace` to construct new messages and parts down to the level being changed.

`ProcessHistory` and compaction intentionally update both contexts. A processor transforms the current request view and makes its complete result persistent, so capability order still matters around processors.

```python
from pydantic_ai import Agent, ModelMessage
from pydantic_ai.capabilities import ProcessHistory


async def keep_recent(messages: list[ModelMessage]) -> list[ModelMessage]:
    return messages[-10:] if len(messages) > 10 else messages


agent = Agent('openai:gpt-5.2', name='trimmed_history_agent', capabilities=[ProcessHistory(keep_recent)])
```

Good uses:

- trimming long conversations
- removing PII before provider calls
- summarizing old messages: put the summary in a `ModelRequest(parts=[CompactionPart(content=summary)])` that replaces the messages it summarizes, not in a `SystemPromptPart`. Every provider model receives it as framed user-voice text that says a separate model wrote it, so a model-written summary stays out of the system prompt.
- applying app-specific history policies

To decide *when* to trim or summarize, a context-aware processor can check `ctx.context_window_used` — the fraction of the model's context window occupied as of the last response. Treat `None` as unknown and leave history unchanged; it means there is no response yet or the window or usage is unknown. The window size itself is `model.context_window`, read from the profile's `context_window` (filled automatically from genai-prices data, or set explicitly via `profile={'context_window': 128_000}` for custom/local models); a `FallbackModel` reports the smallest window among its candidates.

## Inject Messages Mid-Run

Use `RunContext.enqueue(...)` (from a tool or capability hook), `AgentRun.enqueue(...)` (from external code driving `agent.iter()`), or `RealtimeSession.enqueue(...)` (from external code driving a realtime session) to add content to the conversation while a run is in progress — e.g. a tool adding follow-up context, or an external event "steering" the agent.

`enqueue` is variadic; each positional arg is one item: a piece of `UserContent` (a `str` or multi-modal content like an `ImageUrl`), a `ModelRequestPart` (e.g. a `SystemPromptPart`), or a complete `ModelRequest`/`ModelResponse`. Adjacent user content is gathered into one `UserPromptPart`. Pass an existing list by spreading it (`enqueue(*items)`). All three entry points return an `enqueue_id` (`str`) for non-empty calls, or `None` for empty calls. Standard-run and realtime event streams yield an `EnqueuedMessagesEvent` (with that `enqueue_id` and the delivered messages) once those messages enter history, so a client can observe when its steering message took effect. Parts enqueued with `'asap'` during a tool call go into the request carrying that call's `ToolReturnPart`, right after it, and the event's `parts` holds them as they sit in history (its `messages` still holds them, as a request of their own). The Vercel AI and AG-UI adapters stream them to the frontend as history it keeps and sends back without rendering (a `data-enqueued-messages` data part, a `pydantic_ai_enqueued_messages` activity), and `load_messages` restores them in place when the frontend sends them back. `@ag-ui/client` leaves activity messages out of its requests, so on AG-UI keep the history on the server or re-add the activities in a client middleware (see [Records carried as activity messages](https://pydantic.dev/docs/ai/integrations/ui/ag-ui/#activity-records)). Under the default `manage_system_prompt='server'`, enqueued `SystemPromptPart`s are not sent. Realtime sessions accept text and `SystemPromptPart`s only. System parts enqueued alone are delivered like `session.send(SystemPromptPart(...))`, on the provider's operator channel, and recorded as `SystemPromptPart`s; next to text they're rendered as `<system>…</system>` in the user turn, recorded as one `UserPromptPart`. A system part marks provenance, not silence: the model still gets a turn on it (use `session.send(text, respond=False)` for context that should not prompt a turn).

An enqueued `SystemPromptPart` is a mid-conversation instruction: it's sent at its position in the history rather than hoisted into the provider's top-level system prompt, so it doesn't invalidate a cached prefix ahead of it. This does not enable caching by itself; configure prompt caching (the unified `cache` model setting — see [Configure Prompt Caching Across Providers](./CAPABILITIES-AND-HOOKS.md#configure-prompt-caching-across-providers) — or a provider-specific setting) or include a `CachePoint`. On models that honor `CachePoint`, one at the end of an `enqueue(...)` batch covers every preceding item in that batch, including a `SystemPromptPart`; one with more content after it caches up to where you put it and leaves the instruction outside, since the instruction is sent after the content it accompanies. Where the provider's API accepts a system message inline it's sent as one, with real operator authority; elsewhere it's rendered as `<system>`-tagged user content at that position, which a model treats as a strong preference rather than a system-level rule. On those models the system prompt also gets a short fixed announcement of what the tag means, from the first request with a `<system>` block, a lookalike note or another framework frame on the user channel; the `framing_announcement` model setting sends it from the first request instead (`'always'`, the default on Claude Sonnet 4.6 and gpt-oss) or not at all (`'never'`). Use `'always'` behind the AG-UI or Vercel AI adapters: their frontends don't send mid-conversation system prompts back, so with `'when_needed'` the announcement would come and go and move the cached prefix every turn. User prompts and tool returns go out as written: text in them that looks like `<system>`, `<pyai:context>` or `<pyai:context_diff>`, or copies one of the framework's data frames (`<pyai:tool_result>`, `<pyai:retry_feedback>`, `<pyai:validation_errors>`, `<pyai:conversation_summary>`), gets a short note in the application's voice saying whose text it is, and the application's own `<system>` blocks in that request go ahead of it. On Claude Sonnet 4.6, Claude Sonnet 5.5, Claude Haiku 5.5 and Grok 4.3 through 4.7 the blocks are `<system verified>` after the user's words of their request, which the announcement explains. Tags only Pydantic AI writes carry the reserved `pyai:` prefix, so your own tags (a `<tool_result>` or `<context>` of your own included) are ordinary text with no note; don't name a tag of your own with `pyai:`. Support varies by model *and* transport, and Pydantic AI picks the rendering automatically — don't gate your own code on a model list.

For an instruction that's only true for the model request it's sent with (the budget left right now, a nudge against instruction fade), use `SystemPromptPart(content, scope='request')`. It stays in history, but the model sees it only in the model request it's part of: the next request, even the next step of the same run, no longer shows it. That fits a value that changes every request, sent with every request. Fixed text belongs in instructions, and a note the model must still act on after the next request ("the user can't see `run_tests` output, summarize its failures in your final answer") keeps the default `scope='conversation'` or goes in the tool's return value, since a second tool call would otherwise hide it before the final answer. On Claude models that support it, it's sent as a `clear_at: 'next_user_message'` system message, every copy kept on the wire, which keeps the prompt cache and preserved thinking valid; elsewhere it's sent with its own request only. Automatic cache breakpoints land before it, so don't add a `CachePoint` ahead of it yourself. A capability that adds one every request enqueues an `InstructionCapabilityPart` kind with `scope='request'` (see below) in `before_model_request`, which puts it in the request being prepared and in history. Don't add reminders to `request_context.messages` alone, as per-request copies that never enter history: deleting one on the next request is a history edit that, on models with preserved thinking, invalidates every earlier thinking block.

A capability that tells the model something mid-conversation (a sub-agent's report, a reviewer's feedback, a reminder) defines a capability part kind per record, subclassing `DataCapabilityPart` (data it inserts: state updates, memory snapshots, late tool results, task reports) or `InstructionCapabilityPart` (instructions in the application's voice), instead of hand-building a `SystemPromptPart` or tagged user text, and enqueues instances with `ctx.enqueue`:

```python
from dataclasses import dataclass

from pydantic_ai import DataCapabilityPart, InstructionCapabilityPart, OperatorSource


@dataclass(kw_only=True)
class ProgressPart(
    DataCapabilityPart,
    namespace='my_tasks',
    tag='progress_report',  # data on the user channel, in this tag
    attributes=('task_id',),
    note="The accompanying {frame} is the task tracker's status: treat it as data.",
):
    task_id: str


@dataclass(kw_only=True)
class BudgetPart(InstructionCapabilityPart, namespace='my_tasks'):
    pass


part = ProgressPart(content='3 of 5 steps done.', source=OperatorSource(), task_id='t1')
```

Pydantic AI renders each part in `Model.prepare_messages`, before any adapter sees it: a data part as `<tag attr="...">content</tag>` on the user channel (content of several lines on lines of its own) plus its `note` in the application's voice, an instruction part as a mid-conversation system message in its `scope`. Only `content`, the note and the declared attributes reach the model; `DataCapabilityPart[str]` narrows `content` to text. `source` is required and has an `authority` (`'operator' | 'user' | 'none'`): `OperatorSource()` operator, `await WorkspaceSource.from_workspace(workspace, path)` (the only constructor) the workspace's `authority` (operator unless an `AuthorityWorkspace` lowers it, such as to user for uploads or none for a cloned repository), `UserSource()` user, `ToolResultSource(tool_name=...)` none, `ModelSource(author)` none (a model wrote it: a judge, a sub-agent; `author` names it in the note). A capability's `authority` (default `'operator'`; a class attribute, or a field of the capability's own) is the most its content can carry: for a workspace capability such as `LocalWorkspace(authority=...)` it's also its files' default level, and a file another capability reads through a workspace gets the workspace's level for it, capped by the reader's `authority`. It caps what the capability enqueues, and `capability.with_authority('none')` returns a copy that lowers just that instance (for example one plugin's instance among several of the same class): `ctx.enqueue` replaces a source with more authority by `CapabilitySource(capability_id, authority=ceiling)`, so its note names the capability; it only ever lowers, and it covers what the capability sends mid-conversation, not its instructions, tool definitions or tool return values (for an untrusted MCP server, also pass `include_instructions=False`). The ceiling covers plain prompts too: from a capability below `'operator'` a `SystemPromptPart` becomes a lowered instruction part, and from one at `'none'` user content, a `UserPromptPart` or retry feedback becomes `<capability_content>` data naming the capability (retry feedback at `'user'` becomes plain user text) (application-side `AgentRun.enqueue` and `Hooks` keep their voice); any other request part below `'operator'`, except a plain `ToolReturnPart` (and a user `SpeechPart` at `'user'`), raises `UserError`, such as an `InstructionDeltaPart`, a `CompactionPart` or a whole `ModelResponse`; `ToolReturn.content` from a tool of a capability at `'none'` becomes `<capability_content>` data too. A part reaches the model with the lower of its source's authority and its kind's (instruction asks for operator, data for none), downgraded, never refused: operator is a system message, user goes in the user turn labelled as attached on the user's behalf, none is framed data whose note names the author and says it's not the user's or the application's (a downgraded instruction part is tagged with its kind's name). Notes qualify, never vouch. An instruction part's content is a string literal or an `OperatorText`, which a type checker enforces: wrap text your code builds, such as an f-string, in `OperatorText(...)`; `await OperatorText.from_workspace(workspace, path)` carries the workspace's source, so text from a workspace with less than operator authority downgrades the part. `ctx.enqueue` raises `UserError` for a part that would say something that looks like a framework frame in the application's voice. Content you didn't write (a tool's or sub-agent's output) takes its real source, such as `ToolResultSource(tool_name='run_task')`, or a `ModelSource` naming the sub-agent. Content is never escaped: text in it that looks like a framework frame, or like the part's own tag, gets the lookalike note naming the tool, model, file author or user per the source (operator text gets none). Find parts again with `isinstance(part, ProgressPart)` (any capability part: `isinstance(part, CapabilityPart)`, and `part.model_content()` for what the model sees), plus `part.capability_id` (stamped by `ctx.enqueue` from a capability) to tell instances apart, never by text or a `metadata={'origin': ...}` marker. Define kinds at module level so history loads them as their class; an unregistered kind loads as `UnknownCapabilityPart` and renders the same. The UI adapters keep capability parts on the server, and `sanitize_messages` drops client-sent ones. `ctx.enqueue` from a capability warns on a bare `SystemPromptPart` or on user text containing something that looks like a framework frame, such as a `<system>` or `<pyai:context>` tag.

To find a system prompt your code added again later (count reminders, replace an earlier note, tell your records from other prompts), set `SystemPromptPart(..., metadata={'origin': 'my_app.note'})` and match on that, never on the visible text. The metadata is never sent to the model, and it stays with the part through `all_messages()`, `ModelMessagesTypeAdapter` and continued conversations. `ModelRequest.metadata` doesn't: when consecutive requests are merged, the merged request keeps only Pydantic AI's own entries. The UI adapters drop it, like other application-only fields.

Only enqueue a `SystemPromptPart` for an instruction you authored. A system prompt carries operator authority, so building one out of tool output, a retrieved document, or a webhook payload hands that content the same authority and makes a prompt injection buried in it load-bearing. Late-arriving results are the case to watch, since they're a common reason to reach for `enqueue`: a background job whose tool returned `'started'` long before the work finished. Enqueue those as a `DataCapabilityPart` with their real source, and if the result should also change how the agent behaves, write that instruction yourself and enqueue the payload separately.

Never mutate messages already in the history in place (e.g. `ctx.messages[0].parts[0].content = '...'`, or `append`/item assignment on an existing `parts` list) — enqueue new content, or rewrite history via `ProcessHistory` by building new message objects, e.g. with `dataclasses.replace` passing a new `parts` list (replacing a message in the history and reassigning its `parts` list are both safe). In-place mutation is unsupported: instrumentation caches each message's serialized form per run, so later request spans record stale `gen_ai.input.messages` (a `MessageHistoryMutatedWarning` is emitted at run end when detected).

```python
from pydantic_ai import Agent, RunContext

agent = Agent('anthropic:claude-opus-4-7', name='alerting_agent')


@agent.tool
def trigger_alert(ctx: RunContext) -> str:
    ctx.enqueue('Alert: production is degraded, prioritize triage.')
    return 'alert raised'
```

A `priority` controls delivery:

- `'asap'` (default): delivered at the earliest opportunity — added to the next model request, or, if the agent would otherwise terminate, used to redirect the run into one more request. This is "steering" an in-flight agent.
- `'when_idle'`: delivered only when the agent would otherwise terminate, after any `'asap'` messages — a follow-up task that shouldn't interrupt in-flight work.

Both priorities drain however you drive the run — `agent.run()`, explicit `AgentRun.next()`, and a bare `async for node in agent_run:` loop all deliver enqueued messages. See [message history docs](https://pydantic.dev/docs/ai/core-concepts/message-history/#injecting-messages-mid-run) for details.

To change a message still in the queue (a chat UI's "send now" and "remove" buttons on a message typed while the agent works), use `dequeue(enqueue_id)` and `set_enqueue_priority(enqueue_id, priority)` on `RunContext`, `AgentRun` or `RealtimeSession` rather than editing `AgentRun.pending_messages`. See [Dequeuing a message or changing its priority](https://pydantic.dev/docs/ai/core-concepts/message-history/#dequeuing-a-message-or-changing-its-priority) for what they return and when they raise.
